#!/bin/bash

# Docker container rebuild script for alpha-webhook
# This script stops, rebuilds, and restarts the alpha-webhook container

set -e  # Exit on any error

CONTAINER_NAME="alpha-webhook-container"
IMAGE_NAME="alpha-webhook"
PORT="3001"

echo "🔄 Starting rebuild process for $CONTAINER_NAME..."

# Step 1: Stop and remove existing container
echo "🛑 Stopping and removing existing container..."
if docker ps -q -f name=$CONTAINER_NAME | grep -q .; then
    docker stop $CONTAINER_NAME
    echo "✅ Container stopped"
else
    echo "ℹ️  Container was not running"
fi

if docker ps -aq -f name=$CONTAINER_NAME | grep -q .; then
    docker rm $CONTAINER_NAME
    echo "✅ Container removed"
else
    echo "ℹ️  Container did not exist"
fi

# Step 2: Rebuild the Docker image
echo "🔨 Rebuilding Docker image..."
docker build -t $IMAGE_NAME .
echo "✅ Image rebuilt successfully"

# Step 3: Start new container
echo "🚀 Starting new container..."
docker run -d \
    --name $CONTAINER_NAME \
    -p $PORT:$PORT \
    $IMAGE_NAME

echo "✅ Container started successfully"

# Step 4: Show container status
echo "📊 Container status:"
docker ps | grep $CONTAINER_NAME || echo "❌ Container not found in running processes"

# Step 5: Wait a moment and show logs
echo "📝 Recent logs (waiting 3 seconds for startup):"
sleep 3
docker logs --tail 10 $CONTAINER_NAME

# Step 6: Test endpoint availability
echo "🧪 Testing endpoint availability..."
sleep 2
if curl -s -f http://127.0.0.1:$PORT/health > /dev/null 2>&1; then
    echo "✅ Health endpoint is responding"
elif curl -s http://127.0.0.1:$PORT/ > /dev/null 2>&1; then
    echo "✅ Server is responding on port $PORT"
else
    echo "⚠️  Server might still be starting up. Check logs with: docker logs $CONTAINER_NAME"
fi

echo "🎉 Rebuild process completed!"
echo "📋 Useful commands:"
echo "   View logs: docker logs -f $CONTAINER_NAME"
echo "   Test endpoint: curl -X POST http://127.0.0.1:$PORT/process-new-listing -H 'Content-Type: application/json' -d '{\"symbol\": \"TEST\", \"name\": \"Test Token\"}'"
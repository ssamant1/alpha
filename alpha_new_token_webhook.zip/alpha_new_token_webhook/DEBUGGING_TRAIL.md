# Token Matching Debugging Trail & Analysis Guide

## Overview

This document chronicles the debugging process for fixing critical logical errors in the token matching system and provides guidance for future analysis and debugging.

## Problem Discovery

### Initial Issues Identified

1. **Case-Sensitivity Problems**: Matching failed when token symbols had different casing
   - Example: `"PIPPIN"` (search term) vs `"pippin"` (Dexscreener symbol)
   - Result: `no_exact_baseToken_match` despite having valid pairs

2. **Whitespace Issues**: Trailing/leading spaces caused exact matches to fail
   - Example: `"RCSAG"` (search term) vs `"RCSAG "` (with trailing space)
   - Result: False negatives on otherwise perfect matches

3. **Combined Issues**: Both problems occurring together
   - Example: `"FARTCOIN"` vs `"Fartcoin "` (case + whitespace)
   - Result: High-volume, high-liquidity pairs being rejected

### Sample Failing Records

#### RCSAG Example
```json
{
  "symbol": "RCSAG",
  "dexscreener": {
    "status": "no_match",
    "reason": "no_exact_baseToken_match",
    "raw": {
      "pairs": [{
        "baseToken": {
          "symbol": "RCSAG ",  // Note trailing space
          "name": "Right Click Save As Guy "
        },
        "volume": { "h24": 11.87 },
        "liquidity": { "usd": 30749.42 }
      }]
    }
  }
}
```

#### PIPPIN Example
```json
{
  "symbol": "PIPPIN",
  "dexscreener": {
    "status": "thresholds_not_met_or_no_fdv",
    "raw": {
      "pairs": [{
        "baseToken": {
          "symbol": "pippin",  // lowercase vs uppercase search
          "name": "Pippin"
        },
        "volume": { "h24": 283448.14 },    // Well above $10K threshold
        "liquidity": { "usd": 2924299.41 } // Well above $10K threshold
      }]
    }
  }
}
```

#### FARTCOIN Example
```json
{
  "symbol": "FARTCOIN",
  "dexscreener": {
    "status": "thresholds_not_met_or_no_fdv",
    "raw": {
      "pairs": [{
        "baseToken": {
          "symbol": "Fartcoin ",  // Case difference + trailing space
          "name": "Fartcoin "
        },
        "volume": { "h24": 2410073.91 },    // $2.4M volume
        "liquidity": { "usd": 24009759.33 } // $24M liquidity
      }]
    }
  }
}
```

## Root Cause Analysis

### Code Issues Found

1. **`utils.js:173` - isExactBaseMatch Function**
   ```javascript
   // BEFORE (problematic)
   return p.baseToken.symbol === base || p.baseToken.name === base;

   // AFTER (fixed)
   const normalizeString = (str) => {
     if (typeof str !== 'string') return '';
     return str.trim().toLowerCase();
   };
   const normalizedBase = normalizeString(base);
   const normalizedSymbol = normalizeString(p.baseToken.symbol);
   const normalizedName = normalizeString(p.baseToken.name);
   return normalizedSymbol === normalizedBase || normalizedName === normalizedBase;
   ```

2. **Case-Sensitive Logic Throughout**
   - `rankPairs()` function used manual comparison instead of `isExactBaseMatch()`
   - `selectTopExactPair()` inherited the case-sensitivity issue

### Impact Assessment

- **High Impact**: Legitimate, high-volume pairs were being rejected
- **False Negatives**: Records marked as `no_match` when they should have succeeded
- **Data Quality**: Significant number of missed opportunities for token enrichment

## Solution Implementation

### 1. Fixed Matching Logic (`utils.js`)

**Enhanced `isExactBaseMatch()` Function:**
- Case-insensitive comparison using `.toLowerCase()`
- Whitespace trimming using `.trim()`
- Robust string validation and normalization

**Updated `rankPairs()` Function:**
- Now uses the improved `isExactBaseMatch()` for consistency
- Eliminated duplicate matching logic

**Enhanced `extractBaseToken()` Function:**
- Added documentation about whitespace trimming
- Ensured consistent string handling

### 2. Created Debug Analysis Endpoint

**`GET /debug/failed-matches`**
- Analyzes failed records using improved logic
- Identifies records that should have matched
- Provides detailed statistics and sample problems

**`GET /debug/failed-matches?fix=true`**
- Performs analysis + automatic fixing
- Updates records with correct token data
- Preserves original error information for audit trail

### 3. Audit Trail Implementation

Fixed records maintain complete history:
```json
{
  "dexscreener": {
    "status": "ok_fixed",
    "fixedAt": "2025-01-17T15:30:45.123Z",
    "fixedFrom": "no_exact_baseToken_match",
    "originalError": {
      "status": "no_match",
      "reason": "no_exact_baseToken_match",
      "checkedAt": "2025-01-17T14:30:45.123Z",
      "note": "This record was originally missed due to case-sensitivity/whitespace issues but has been corrected"
    },
    // ... correct token data
  }
}
```

## How to Perform Analysis

### 1. Initial Health Check

```bash
# Check overall matching success rate
curl http://localhost:3001/analyze/matching
```

### 2. Debug Failed Records

```bash
# Analyze without fixing
curl http://localhost:3001/debug/failed-matches

# Analyze and fix issues
curl "http://localhost:3001/debug/failed-matches?fix=true"
```

### 3. MongoDB Queries for Analysis

#### Find All Fixed Records
```javascript
db.test_announcement.find({"dexscreener.status": "ok_fixed"})
```

#### Count Fixes by Original Error Type
```javascript
db.test_announcement.aggregate([
  { $match: {"dexscreener.status": "ok_fixed"} },
  { $group: { _id: "$dexscreener.originalError.reason", count: { $sum: 1 } } }
])
```

#### Find Records Fixed from Specific Error
```javascript
db.test_announcement.find({"dexscreener.fixedFrom": "no_exact_baseToken_match"})
```

#### Find High-Volume Pairs That Were Initially Missed
```javascript
db.test_announcement.find({
  "dexscreener.status": "ok_fixed",
  "dexscreener.volumeUsd": { $gt: 100000 },
  "dexscreener.liquidityUsd": { $gt: 100000 }
})
```

#### Get Success Rate After Fixes
```javascript
db.test_announcement.aggregate([
  {
    $group: {
      _id: null,
      total: { $sum: 1 },
      successful: {
        $sum: {
          $cond: [
            { $in: ["$dexscreener.status", ["ok", "ok_fixed", "ok_name_symbol", "ok_exact_base", "ok_from_new_listing_match"]] },
            1,
            0
          ]
        }
      }
    }
  },
  {
    $project: {
      total: 1,
      successful: 1,
      successRate: { $multiply: [{ $divide: ["$successful", "$total"] }, 100] }
    }
  }
])
```

### 4. Performance Impact Analysis

#### Before vs After Comparison
```javascript
// Count original failures that were fixed
db.test_announcement.countDocuments({
  "dexscreener.status": "ok_fixed",
  "dexscreener.originalError.reason": { $in: ["no_exact_baseToken_match", "thresholds_not_met_or_no_fdv"] }
})

// Total volume/liquidity recovered
db.test_announcement.aggregate([
  { $match: {"dexscreener.status": "ok_fixed"} },
  {
    $group: {
      _id: null,
      totalVolumeRecovered: { $sum: "$dexscreener.volumeUsd" },
      totalLiquidityRecovered: { $sum: "$dexscreener.liquidityUsd" },
      averageFdvRecovered: { $avg: "$dexscreener.fdv" },
      recordsFixed: { $sum: 1 }
    }
  }
])
```

## Testing Verification

### Manual Test Cases

Test the fixed logic with known problem cases:

```javascript
// Test case 1: Case sensitivity
import { isExactBaseMatch } from './utils.js';

const testPair = {
  baseToken: { symbol: "pippin", name: "Pippin" }
};
console.log(isExactBaseMatch(testPair, "PIPPIN")); // Should return true

// Test case 2: Whitespace
const testPair2 = {
  baseToken: { symbol: "RCSAG ", name: "Right Click Save As Guy " }
};
console.log(isExactBaseMatch(testPair2, "RCSAG")); // Should return true
```

### Integration Testing

1. **Run backfill with fixed logic**:
   ```bash
   curl http://localhost:3001/backfill/announcements
   ```

2. **Compare before/after statistics**:
   - Note improvement in success rates
   - Verify high-volume pairs are now captured

## Future Debugging Guidelines

### When New Issues Arise

1. **Check the debug endpoint first**:
   ```bash
   curl http://localhost:3001/debug/failed-matches
   ```

2. **Look for patterns in failed records**:
   - Common symbols or names causing issues
   - Specific data format problems
   - API response variations

3. **Sample individual records**:
   - Examine the raw Dexscreener data
   - Test matching logic manually
   - Check for edge cases

### Monitoring Recommendations

1. **Regular Health Checks**:
   - Run `/analyze/matching` weekly
   - Monitor success rate trends
   - Alert on significant drops

2. **Audit Trail Reviews**:
   - Monthly review of fixed records
   - Identify recurring patterns
   - Update logic proactively

3. **Volume Impact Tracking**:
   - Track total volume/liquidity of processed tokens
   - Measure impact of missed opportunities
   - Cost-benefit analysis of improvements

## Key Learnings

1. **String Handling is Critical**: Always normalize strings before comparison
2. **Preserve History**: Keep audit trails for debugging and analysis
3. **Test with Real Data**: Use actual problematic records for testing
4. **Monitor Continuously**: Regular analysis prevents issues from accumulating
5. **Fail-Safe Design**: When in doubt, err on the side of inclusion rather than exclusion

## Files Modified

- `utils.js`: Core matching logic improvements
- `index.js`: Debug endpoint and fixing capabilities
- `DEBUGGING_TRAIL.md`: This documentation

## Related Endpoints

- `GET /health`: Basic service health
- `GET /analyze/matching`: Overall matching statistics
- `GET /debug/failed-matches`: Detailed failure analysis
- `GET /debug/failed-matches?fix=true`: Analysis + automatic fixing
- `GET /backfill/announcements`: Full reprocessing of announcements

---

*Last Updated: January 17, 2025*
*Next Review: February 17, 2025*
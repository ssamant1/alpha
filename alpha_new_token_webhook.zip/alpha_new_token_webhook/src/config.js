// src/config.js
import * as dotenv from 'dotenv';

dotenv.config();

export const config = {
  // Database configuration
  mongodb: {
    uri: process.env.DATABASE_URL,
    dbName: process.env.DB_NAME || 'block_circle',
  },

  // Server configuration
  server: {
    port: process.env.PORT || 3001,
  },

  // Target collections for change stream monitoring
  collections: {
    targets: (process.env.TARGET_COLLECTIONS &&
      process.env.TARGET_COLLECTIONS.split(',')
        .map((s) => s.trim())
        .filter(Boolean)) || [
      'announcements',
      'alpha_hunter_new_tokens_tier_1',
      'alpha_hunter_new_tokens',
    ],
  },

  // Dexscreener API configuration
  dexscreener: {
    minGapMs: Number(process.env.DEXSCREENER_MIN_GAP_MS ?? 500),
    timeoutMs: 10_000,
  },

  // Token matching thresholds
  thresholds: {
    volumeMinUsd: Number(process.env.VOLUME_MIN_USD ?? 10_000),
    liquidityMinUsd: Number(process.env.LIQ_MIN_USD ?? 10_000),
  },
};
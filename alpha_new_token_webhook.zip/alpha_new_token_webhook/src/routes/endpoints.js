// src/routes/endpoints.js
import express from 'express';
import { performDebugAnalysis } from '../core/analyzers.js';
import { getCollectionMatchingStats } from '../core/analyzers.js';
import { processCollectionRecords } from '../core/processors.js';
import { processAnnouncementsBackfill } from '../core/backfill-processor.js';
import { testEnhancedMatching } from '../services/enhanced-matching.js';
import {
  findNewListingMatches,
  findNewListingMatchWithContract,
  getNewListingMatchDetails,
  pickNameCandidates,
  extractProjectName,
} from '../services/new-listings.js';
import { getCollection } from '../core/database.js';

const router = express.Router();

/**
 * Health check endpoint
 */
router.get('/health', (_req, res) => {
  res.json({
    ok: true,
    watching: process.env.TARGET_COLLECTIONS?.split(',') || ['announcements'],
    timestamp: new Date().toISOString(),
  });
});

/**
 * Matching analysis endpoint
 * Provides comprehensive statistics about token matching performance
 */
router.get('/analyze/matching', async (req, res) => {
  try {
    const collectionName = req.query.collection || 'test_announcement';
    const stats = await getCollectionMatchingStats(collectionName);
    res.json(stats);
  } catch (error) {
    console.error('Matching analysis endpoint error:', error);
    res.status(500).json({
      ok: false,
      error: error.message,
    });
  }
});

/**
 * Debug failed matches endpoint
 * Analyzes and optionally fixes records with matching issues
 */
router.get('/debug/failed-matches', async (req, res) => {
  try {
    const collectionName = req.query.collection || 'test_announcement';
    const shouldFix = req.query.fix === 'true';

    console.log(
      `Debug analysis for ${collectionName}, fix mode: ${
        shouldFix ? 'ENABLED' : 'DISABLED'
      }`,
    );

    const results = await performDebugAnalysis(collectionName, shouldFix);
    res.json(results);
  } catch (error) {
    console.error('Debug failed matches endpoint error:', error);
    res.status(500).json({
      ok: false,
      error: error.message,
    });
  }
});

/**
 * Backfill announcements endpoint with new_listings integration
 * Process existing announcements records with sophisticated multi-stage matching
 */
router.get('/backfill/announcements', async (req, res) => {
  try {
    const targetCollection = req.query.collection || 'test_announcement_2';
    const limit = parseInt(req.query.limit) || null;
    const offset = parseInt(req.query.offset) || 0;

    console.log(`Starting announcements backfill to ${targetCollection}`);
    console.log(`Options: limit=${limit || 'unlimited'}, offset=${offset}`);

    const useEnhanced = req.query.enhanced === 'true' || true;
    const options = { limit, offset, useEnhancedMatching: useEnhanced };
    const results = await processAnnouncementsBackfill(targetCollection, options);

    // Log detailed summary
    console.log('\n=== BACKFILL COMPLETE ===');
    console.log(`📊 Scanned: ${results.stats.scanned} records`);
    console.log(
      `✅ Total successful: ${
        results.stats.ok + results.stats.ok_from_new_listing_match
      }`,
    );
    console.log(`   - Direct matches: ${results.stats.ok}`);
    console.log(`   - New listing matches: ${results.stats.ok_from_new_listing_match}`);
    console.log(`❌ No matches: ${results.stats.no_match}`);
    console.log(
      `⚠️  No pairs for new listing contract: ${results.stats.no_pair_for_new_listing_contract}`,
    );
    console.log(
      `⏭️  Skipped (already complete): ${results.stats.skipped_existing_fields}`,
    );
    console.log(`💥 Errors: ${results.stats.error}`);
    console.log('\n🔗 New Listings Integration:');
    console.log(`   - Found matches: ${results.stats.matching.foundNewListingMatch}`);
    console.log(
      `   - Successful processing: ${results.stats.matching.successfulMatches}`,
    );
    console.log(
      `   - Missing contracts: ${results.stats.matching.matchedButMissingContract}`,
    );
    console.log(`   - No matchable data: ${results.stats.matching.noMatchableData}`);
    console.log(`\n📈 Success Rate: ${results.summary.successRate}`);
    console.log('========================\n');

    res.json(results);
  } catch (error) {
    console.error('Backfill announcements endpoint error:', error);
    res.status(500).json({
      ok: false,
      error: error.message,
      stack: process.env.NODE_ENV === 'development' ? error.stack : undefined,
    });
  }
});

/**
 * Test enhanced new_listings matching with similarity ranking
 * GET /test/similarity-matching?symbol=MORPHO&name=Morpho (MORPHO)
 */
router.get('/test/similarity-matching', async (req, res) => {
  try {
    const { symbol, name } = req.query;

    if (!symbol) {
      return res.status(400).json({
        ok: false,
        error: 'Symbol parameter is required',
      });
    }

    // Extract name candidates (simulate announcement record)
    const nameCandidates = name ? [name] : [];
    const extractedName = name ? extractProjectName({ name }) : null;

    console.log(`🧪 Testing similarity matching for: "${symbol}" / "${extractedName}"`);

    // Get detailed matching information
    const details = await getNewListingMatchDetails(symbol, nameCandidates);

    // Get best match with contract
    const bestMatchWithContract = await findNewListingMatchWithContract(
      symbol,
      nameCandidates,
      {
        maxResults: 5,
        similarityThreshold: 0.3,
        requireContract: true,
      },
    );

    // Get all ranked matches
    const allMatches = await findNewListingMatches(symbol, nameCandidates, {
      maxResults: 10,
      similarityThreshold: 0.1,
    });

    const response = {
      ok: true,
      testInput: {
        symbol,
        originalName: name,
        extractedName,
        nameCandidates,
      },
      results: {
        totalMatches: details.totalMatches,
        matchesWithContract: details.matchesWithContract,
        bestMatchWithContract: bestMatchWithContract
          ? {
              document: {
                id: bestMatchWithContract.document._id,
                name: bestMatchWithContract.projectName,
                exchange: bestMatchWithContract.document.exchange,
                symbol: bestMatchWithContract.document.symbol,
                announced_at: bestMatchWithContract.document.announced_at,
              },
              contractAddress: bestMatchWithContract.contractAddress,
              similarity: bestMatchWithContract.similarity,
              matchType: bestMatchWithContract.matchType,
              rank: bestMatchWithContract.rank,
            }
          : null,
        allMatches: allMatches.map((match) => ({
          id: match.document._id,
          projectName: match.projectName,
          similarity: match.similarity,
          matchType: match.matchType,
          matchedAgainst: match.matchedAgainst,
          hasContract: match.hasContract,
          contractAddress: match.contractAddress,
          rank: match.rank,
          exchange: match.document.exchange,
        })),
      },
      summary: {
        hasMatches: details.totalMatches > 0,
        hasContractMatches: details.matchesWithContract > 0,
        bestSimilarity: allMatches.length > 0 ? allMatches[0].similarity : 0,
        recommendedMatch: bestMatchWithContract
          ? bestMatchWithContract.document._id
          : null,
      },
    };

    res.json(response);
  } catch (error) {
    console.error('Test similarity matching endpoint error:', error);
    res.status(500).json({
      ok: false,
      error: error.message,
    });
  }
});

/**
 * Test enhanced matching endpoint
 * GET /test/enhanced-matching?symbol=SNS&name=Solana Name Service
 */
router.get('/test/enhanced-matching', async (req, res) => {
  try {
    const { symbol, name } = req.query;

    if (!symbol) {
      return res.status(400).json({
        ok: false,
        error: 'Symbol parameter is required',
      });
    }

    console.log(
      `🧪 Testing enhanced matching for: "${symbol}" / "${name || 'no name provided'}"`,
    );

    // Use the test helper function
    const testResults = await testEnhancedMatching(symbol, name);

    const response = {
      ok: true,
      testInput: testResults.input,
      enhancedResult: testResults.result,
      recommendation: testResults.contractRecommendation,
      summary: {
        hasNewListingsMatches: testResults.result.newListingsMatches.length > 0,
        hasDexscreenerPairs: testResults.result.dexscreenerPairs.length > 0,
        hasRecommendation: !!testResults.contractRecommendation,
        financialSummary: testResults.result.financialSummary,
      },
      metadata: {
        newListingsCount: testResults.result.newListingsMatches.length,
        dexscreenerCount: testResults.result.dexscreenerPairs.length,
        totalProcessingTime: 'Not tracked',
        dbOperationsNeeded: testResults.result.metadata.dbOperationTodo,
      },
    };

    res.json(response);
  } catch (error) {
    console.error('Test enhanced matching endpoint error:', error);
    res.status(500).json({
      ok: false,
      error: error.message,
    });
  }
});

/**
 * Test backfill logic for a specific record
 * GET /test/backfill-record?id=RECORD_ID&enhanced=true&collection=announcements
 */
router.get('/test/backfill-record', async (req, res) => {
  try {
    const { id, enhanced, collection } = req.query;

    if (!id) {
      return res.status(400).json({
        ok: false,
        error: 'Record ID parameter is required',
      });
    }

    const sourceCollection = collection || 'announcements';
    const targetCollection = 'test_announcement_single'; // Use a test collection
    const useEnhanced = enhanced === 'true';

    console.log(`🧪 Testing backfill logic for record: ${id}`);
    console.log(`   Source collection: ${sourceCollection}`);
    console.log(`   Enhanced mode: ${useEnhanced ? 'ENABLED' : 'DISABLED'}`);

    // Get the specific record
    const sourceCol = getCollection(sourceCollection);

    // Try to find the record using different ID formats
    let record = null;
    console.log(`🔍 Searching for record with ID: ${id}`);

    try {
      // First try with ObjectId conversion (for MongoDB ObjectId format)
      const { ObjectId } = await import('mongodb');
      if (ObjectId.isValid(id)) {
        record = await sourceCol.findOne({ _id: new ObjectId(id) });
        console.log(`   Tried ObjectId format: ${record ? 'FOUND' : 'NOT FOUND'}`);
      }
    } catch (error) {
      console.log(`   ObjectId conversion failed: ${error.message}`);
    }

    // If not found with ObjectId, try as string
    if (!record) {
      record = await sourceCol.findOne({ _id: id });
      console.log(`   Tried string format: ${record ? 'FOUND' : 'NOT FOUND'}`);
    }

    // If still not found, try to search by any field that might contain the ID
    if (!record) {
      console.log(`   Trying alternative searches...`);

      // Check if there are any records in the collection at all
      const totalCount = await sourceCol.countDocuments({});
      console.log(`   Total records in ${sourceCollection}: ${totalCount}`);

      // Try to find a sample record to understand the ID format
      const sampleRecord = await sourceCol.findOne({});
      if (sampleRecord) {
        console.log(`   Sample record _id type: ${typeof sampleRecord._id}`);
        console.log(`   Sample record _id value: ${sampleRecord._id}`);
      }
    }

    if (!record) {
      return res.status(404).json({
        ok: false,
        error: `Record with ID ${id} not found in collection ${sourceCollection}`,
        debug: {
          searchedId: id,
          idType: typeof id,
          idLength: id.length,
          collection: sourceCollection,
          totalRecordsInCollection: await sourceCol.countDocuments({}),
        },
      });
    }

    console.log(
      `✅ Found record: ${
        record.name || record.Project_name || record.title || 'Unknown'
      }`,
    );

    // Import the processing functions
    const { processBackfillRecord, processRecordWithEnhancedMatching } = await import(
      '../core/backfill-processor.js'
    );

    // Create test statistics object
    const stats = {
      scanned: 0,
      ok: 0,
      ok_from_new_listing_match: 0,
      no_match: 0,
      skipped_existing_fields: 0,
      error: 0,
      no_pair_for_new_listing_contract: 0,
      new_listing_no_match: 0,
      matching: {
        foundNewListingMatch: 0,
        noMatchableData: 0,
        matchedButMissingContract: 0,
        successfulMatches: 0,
        matchedRecordIds: [],
        unmatchedRecordIds: [],
      },
    };

    // Process the record using the appropriate method
    const startTime = Date.now();
    const result = useEnhanced
      ? await processRecordWithEnhancedMatching(
          record,
          sourceCollection,
          targetCollection,
          stats,
        )
      : await processBackfillRecord(record, sourceCollection, targetCollection, stats);
    const processingTime = Date.now() - startTime;

    console.log(`⏱️  Processing completed in ${processingTime}ms`);
    console.log(`📊 Result: ${result.status} (${result.action})`);

    const response = {
      ok: true,
      testInput: {
        recordId: id,
        sourceCollection,
        targetCollection,
        enhancedMode: useEnhanced,
        processingTimeMs: processingTime,
      },
      record: {
        _id: record._id,
        name: record.name || record.Project_name || record.title,
        symbol: record.symbol,
        blockchain: record.blockchain,
        hasExistingData: !!(record.blockchain && record.contract_address),
      },
      result: {
        ...result,
        processingTimeMs: processingTime,
      },
      stats: {
        ...stats,
        summary: {
          processed: 1,
          successful: result.success,
          status: result.status,
          action: result.action,
        },
      },
      metadata: {
        note: 'This is a test run - no actual database updates were performed',
        targetCollection,
        enhancedMatching: useEnhanced,
      },
    };

    // If enhanced matching was used and we have the enhanced result, include it
    if (useEnhanced && result.enhancedResult) {
      response.enhancedDetails = {
        newListingsMatches: result.enhancedResult.newListingsMatches?.length || 0,
        dexscreenerPairs: result.enhancedResult.dexscreenerPairs?.length || 0,
        recommendation: result.enhancedResult.recommendation
          ? {
              contractAddress:
                result.enhancedResult.recommendation.contractAddress ||
                result.enhancedResult.recommendation.pair?.baseToken?.address,
              blockchain: result.enhancedResult.recommendation.pair?.chainId,
              source: result.enhancedResult.recommendation.source,
              financials: result.enhancedResult.recommendation.financials,
            }
          : null,
        financialSummary: result.enhancedResult.financialSummary,
      };
    }

    res.json(response);
  } catch (error) {
    console.error('Test backfill record endpoint error:', error);
    res.status(500).json({
      ok: false,
      error: error.message,
      stack: process.env.NODE_ENV === 'development' ? error.stack : undefined,
    });
  }
});

/**
 * Process specific collection endpoint
 * Manually trigger processing for a collection
 */
router.post('/process/:collection', async (req, res) => {
  try {
    const collectionName = req.params.collection;
    const { query = {}, options = {} } = req.body;

    console.log(`Manual processing triggered for ${collectionName}`);

    const results = await processCollectionRecords(collectionName, query, {
      limit: 50, // Lower limit for manual processing
      ...options,
    });

    res.json({
      ok: true,
      collectionName,
      results,
    });
  } catch (error) {
    console.error('Manual processing endpoint error:', error);
    res.status(500).json({
      ok: false,
      error: error.message,
    });
  }
});

export default router;
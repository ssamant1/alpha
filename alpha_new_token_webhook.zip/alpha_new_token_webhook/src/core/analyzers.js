// src/core/analyzers.js
import { analyzeFailedMatches, generateRecordFix } from '../services/matching.js';
import { findFailedRecords, applyRecordFix, getMatchingStatistics } from './database.js';

/**
 * Analysis and debugging functionality
 * Handles analysis of failed matches and fixing logic
 */

/**
 * Analyze failed matches in a collection
 * @param {string} collectionName - Collection to analyze
 * @param {Array} targetStatuses - Status reasons to analyze
 * @returns {Promise<Object>} Analysis results
 */
export async function analyzeFailedMatchesInCollection(collectionName, targetStatuses = ['no_exact_baseToken_match', 'thresholds_not_met_or_no_fdv']) {
  console.log(`Finding failed records in ${collectionName}...`);

  const failedRecords = await findFailedRecords(collectionName, targetStatuses);

  console.log(`Found ${failedRecords.length} failed records to analyze`);

  if (failedRecords.length === 0) {
    return {
      totalAnalyzed: 0,
      byReason: {},
      detectedIssues: [],
      sampleProblems: [],
    };
  }

  return analyzeFailedMatches(failedRecords);
}

/**
 * Fix failed matches in a collection
 * @param {string} collectionName - Collection to fix
 * @param {Array} targetStatuses - Status reasons to fix
 * @returns {Promise<Object>} Fix results
 */
export async function fixFailedMatchesInCollection(collectionName, targetStatuses = ['no_exact_baseToken_match', 'thresholds_not_met_or_no_fdv']) {
  console.log(`Finding fixable records in ${collectionName}...`);

  const failedRecords = await findFailedRecords(collectionName, targetStatuses);

  const fixes = {
    enabled: true,
    totalFixed: 0,
    byReason: {},
    fixedRecords: [],
    errors: [],
  };

  // Initialize counters
  targetStatuses.forEach((reason) => {
    fixes.byReason[reason] = {
      attempted: 0,
      successful: 0,
      failed: 0,
    };
  });

  console.log(`Attempting to fix ${failedRecords.length} records...`);

  for (const record of failedRecords) {
    const reason = record.dexscreener.reason;

    if (!fixes.byReason[reason]) {
      continue; // Skip reasons we're not handling
    }

    fixes.byReason[reason].attempted++;

    try {
      const fixUpdate = generateRecordFix(record);

      if (fixUpdate) {
        await applyRecordFix(collectionName, record._id, fixUpdate);

        // Check if this was a reclassification or an actual fix
        const isReclassification = fixUpdate.$set['dexscreener.status'] === 'no_match';

        if (isReclassification) {
          // This was a reclassification, not a successful fix
          fixes.byReason[reason].successful++; // Still count as successful operation
          const newReason = fixUpdate.$set['dexscreener.reason'];

          fixes.fixedRecords.push({
            recordId: record._id,
            symbol: record.symbol,
            originalReason: reason,
            newReason: newReason,
            action: 'reclassified',
            fixedAt: new Date()
          });

          console.log(`↻ Reclassified record ${record._id}: ${record.symbol} (${reason} → ${newReason})`);
        } else {
          // This was an actual successful fix
          fixes.byReason[reason].successful++;
          fixes.totalFixed++;

          fixes.fixedRecords.push({
            recordId: record._id,
            symbol: record.symbol,
            reason: reason,
            action: 'fixed',
            fixedAt: new Date()
          });

          console.log(`✓ Fixed record ${record._id}: ${record.symbol} (${reason})`);
        }
      } else {
        fixes.byReason[reason].failed++;
        fixes.errors.push({
          recordId: record._id,
          symbol: record.symbol,
          reason: reason,
          error: 'No exact matches found or pairs failed volume/liquidity thresholds'
        });
      }
    } catch (fixError) {
      fixes.byReason[reason].failed++;
      fixes.errors.push({
        recordId: record._id,
        symbol: record.symbol,
        reason: reason,
        error: fixError.message
      });
      console.error(`✗ Failed to fix record ${record._id}:`, fixError.message);
    }
  }

  console.log(`Fix operation complete: ${fixes.totalFixed} records fixed`);

  return fixes;
}

/**
 * Perform comprehensive debug analysis
 * @param {string} collectionName - Collection to analyze
 * @param {boolean} shouldFix - Whether to apply fixes
 * @returns {Promise<Object>} Complete debug results
 */
export async function performDebugAnalysis(collectionName, shouldFix = false) {
  const targetStatuses = ['no_exact_baseToken_match', 'thresholds_not_met_or_no_fdv'];

  // Perform analysis
  const analysis = await analyzeFailedMatchesInCollection(collectionName, targetStatuses);

  let fixes = {
    enabled: shouldFix,
    totalFixed: 0,
    byReason: {},
    fixedRecords: [],
    errors: [],
  };

  // Initialize fix counters
  targetStatuses.forEach((reason) => {
    fixes.byReason[reason] = {
      attempted: 0,
      successful: 0,
      failed: 0,
    };
  });

  // Apply fixes if requested
  if (shouldFix && analysis.totalAnalyzed > 0) {
    console.log('Fix mode enabled, attempting to fix records...');
    fixes = await fixFailedMatchesInCollection(collectionName, targetStatuses);
  }

  // Calculate summary statistics
  const totalIssuesFound = Object.values(analysis.byReason)
    .reduce((sum, reason) => sum + reason.shouldHaveMatched + reason.shouldHavePassedThresholds, 0);

  return {
    ok: true,
    summary: {
      totalRecordsAnalyzed: analysis.totalAnalyzed,
      potentialIssuesFound: totalIssuesFound,
      fixMode: shouldFix,
      totalFixed: fixes.totalFixed,
      thresholds: {
        volumeMinUsd: 10000, // Could be imported from config
        liquidityMinUsd: 10000,
      },
    },
    analysis,
    fixes,
  };
}

/**
 * Get comprehensive matching statistics for a collection
 * @param {string} collectionName - Collection to analyze
 * @returns {Promise<Object>} Statistics and analysis
 */
export async function getCollectionMatchingStats(collectionName) {
  console.log(`Analyzing matching statistics for ${collectionName}...`);

  // Get basic statistics
  const stats = await getMatchingStatistics(collectionName);

  // Calculate percentages and derive insights
  const successful = (stats.byStatus.ok || 0) +
                   (stats.byStatus.ok_fixed || 0) +
                   (stats.byStatus.ok_name_symbol || 0) +
                   (stats.byStatus.ok_exact_base || 0) +
                   (stats.byStatus.ok_from_new_listing_match || 0);

  const failed = stats.byStatus.no_match || 0;
  const errors = stats.byStatus.error || 0;
  const alreadyComplete = stats.byStatus.already_complete || 0;

  const processed = successful + failed + errors;
  const matchableRecords = processed; // Records that could potentially be matched

  const overallMatchRate = stats.total > 0 ? ((successful / stats.total) * 100).toFixed(1) : '0.0';
  const matchableMatchRate = matchableRecords > 0 ? ((successful / matchableRecords) * 100).toFixed(1) : '0.0';

  return {
    ok: true,
    collectionName,
    summary: {
      totalRecords: stats.total,
      successfulMatches: successful,
      failedMatches: failed,
      errorRecords: errors,
      alreadyCompleteRecords: alreadyComplete,
      overallMatchRate: `${overallMatchRate}%`,
      matchableRecordsMatchRate: `${matchableMatchRate}%`,
    },
    detailedStats: {
      byStatus: stats.byStatus,
      byReason: stats.byReason,
    },
    breakdown: {
      totalProcessed: processed,
      matchableRecords: matchableRecords,
      alreadyCompleteRecords: alreadyComplete,
      recordsWithoutMatchableData: stats.total - processed - alreadyComplete,
    },
    newListingsIntegration: {
      fromNewListingMatch: stats.byStatus.ok_from_new_listing_match || 0,
      noMatchForNewListingContract: stats.byStatus.no_match_for_new_listing_contract || 0,
      nameSymbolMatches: stats.byStatus.ok_name_symbol || 0,
      exactBaseMatches: stats.byStatus.ok_exact_base || 0,
    },
  };
}
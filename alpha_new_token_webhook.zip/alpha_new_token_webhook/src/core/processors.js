// src/core/processors.js
import { extractBaseToken } from '../../utils.js';
import { searchDexscreener } from '../services/dexscreener.js';
import { analyzeTokenMatch, extractEnrichmentData } from '../services/matching.js';
import { updateRecordWithEnrichment, isRecordComplete } from './database.js';

/**
 * Core token processing logic
 * Handles the main enrichment workflow for token records
 */

/**
 * Process a single token record for enrichment
 * @param {Object} record - Database record to process
 * @param {string} collectionName - Collection name for updates
 * @returns {Promise<Object>} Processing result
 */
export async function processTokenRecord(record, collectionName) {
  const result = {
    recordId: record._id,
    success: false,
    status: null,
    reason: null,
    error: null,
    enrichmentData: null
  };

  try {
    console.log(`Processing record ${record._id}...`);

    // Check if record already has complete data
    if (isRecordComplete(record)) {
      result.status = 'already_complete';
      result.reason = 'has_blockchain_and_contract';
      result.success = true;
      console.log(`Record ${record._id} already has complete data, skipping`);
      return result;
    }

    // Extract base token symbol
    const baseToken = extractBaseToken(record);
    if (!baseToken) {
      result.status = 'no_match';
      result.reason = 'no_base_token_extracted';
      console.log(`Record ${record._id}: No base token could be extracted`);

      // Update with no match status
      await updateRecordWithEnrichment(collectionName, record._id, {
        status: 'no_match',
        reason: 'no_base_token_extracted',
        baseToken: null,
        raw: null
      });

      return result;
    }

    console.log(`Record ${record._id}: Extracted base token "${baseToken}"`);

    // Fetch data from Dexscreener
    const dexData = await searchDexscreener(baseToken);
    console.log(`Record ${record._id}: Dexscreener returned ${dexData?.pairs?.length || 0} pairs`);

    // Analyze the match
    const matchResult = analyzeTokenMatch(dexData, baseToken);
    result.status = matchResult.status;
    result.reason = matchResult.reason;

    if (matchResult.status === 'ok') {
      // Extract enrichment data
      const enrichmentData = extractEnrichmentData(matchResult);

      if (enrichmentData) {
        // Update the database record
        await updateRecordWithEnrichment(collectionName, record._id, {
          ...enrichmentData,
          baseToken,
          raw: dexData
        });

        result.success = true;
        result.enrichmentData = enrichmentData;

        console.log(`✓ Record ${record._id} successfully enriched: ${enrichmentData.baseSymbol} (${enrichmentData.chainId})`);
      } else {
        throw new Error('Failed to extract enrichment data from successful match');
      }
    } else {
      // Update with failure status
      await updateRecordWithEnrichment(collectionName, record._id, {
        status: matchResult.status,
        reason: matchResult.reason,
        baseToken,
        raw: dexData
      });

      console.log(`✗ Record ${record._id} failed: ${matchResult.reason}`);
    }

    return result;

  } catch (error) {
    result.error = error.message;
    console.error(`Error processing record ${record._id}:`, error.message);

    // Try to update with error status
    try {
      await updateRecordWithEnrichment(collectionName, record._id, {
        status: 'error',
        reason: 'processing_error',
        error: error.message,
        baseToken: extractBaseToken(record),
        raw: null
      });
    } catch (updateError) {
      console.error(`Failed to update record ${record._id} with error status:`, updateError.message);
    }

    return result;
  }
}

/**
 * Process multiple token records with rate limiting
 * @param {Array} records - Array of database records
 * @param {string} collectionName - Collection name for updates
 * @param {Object} options - Processing options
 * @returns {Promise<Object>} Batch processing results
 */
export async function processTokenRecordsBatch(records, collectionName, options = {}) {
  const {
    maxConcurrent = 1, // Process one at a time due to rate limiting
    delayBetweenBatches = 100
  } = options;

  const results = {
    total: records.length,
    processed: 0,
    successful: 0,
    failed: 0,
    errors: 0,
    byStatus: {},
    details: []
  };

  console.log(`Starting batch processing of ${records.length} records...`);

  // Process records in chunks to respect rate limits
  for (let i = 0; i < records.length; i += maxConcurrent) {
    const batch = records.slice(i, i + maxConcurrent);

    // Process batch
    const batchResults = await Promise.all(
      batch.map(record => processTokenRecord(record, collectionName))
    );

    // Aggregate results
    for (const result of batchResults) {
      results.processed++;
      results.details.push(result);

      if (result.success) {
        results.successful++;
      } else if (result.error) {
        results.errors++;
      } else {
        results.failed++;
      }

      // Track status counts
      if (result.status) {
        results.byStatus[result.status] = (results.byStatus[result.status] || 0) + 1;
      }
    }

    // Progress logging
    console.log(`Processed ${results.processed}/${results.total} records...`);

    // Delay between batches to be gentle on APIs
    if (i + maxConcurrent < records.length && delayBetweenBatches > 0) {
      await new Promise(resolve => setTimeout(resolve, delayBetweenBatches));
    }
  }

  console.log(`Batch processing complete: ${results.successful} successful, ${results.failed} failed, ${results.errors} errors`);

  return results;
}

/**
 * Process records from a specific collection
 * @param {string} collectionName - Collection to process
 * @param {Object} query - MongoDB query to filter records
 * @param {Object} options - Processing options
 * @returns {Promise<Object>} Processing results
 */
export async function processCollectionRecords(collectionName, query = {}, options = {}) {
  const { findRecords } = await import('./database.js');

  console.log(`Finding records in ${collectionName} collection...`);
  const records = await findRecords(collectionName, query, options);

  if (records.length === 0) {
    console.log(`No records found in ${collectionName} matching query`);
    return {
      total: 0,
      processed: 0,
      successful: 0,
      failed: 0,
      errors: 0,
      byStatus: {},
      details: []
    };
  }

  return await processTokenRecordsBatch(records, collectionName, options);
}
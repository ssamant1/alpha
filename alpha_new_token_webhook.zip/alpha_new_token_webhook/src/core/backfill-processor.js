// src/core/backfill-processor.js
import { extractBaseToken, pickBlockchain } from '../../utils.js';
import { searchDexscreener } from '../services/dexscreener.js';
import {
  selectPairByContract,
  extractEnrichmentData,
  createNoMatchEnrichmentData,
} from '../services/matching.js';
import {
  findNewListingMatch,
  findNewListingMatchWithContract,
  pickNameCandidates,
  pickContractLoose,
  pickChainLoose,
  getNewListingsCount,
  extractProjectName,
} from '../services/new-listings.js';
import {
  performEnhancedMatching,
  extractRecommendedContract,
} from '../services/enhanced-matching.js';
import {
  updateRecordWithEnrichment,
  isRecordComplete,
  getCollection,
} from './database.js';

/**
 * Backfill processor with new_listings integration
 * Implements the sophisticated multi-stage matching from original backfill logic
 */

/**
 * Process a single record for backfill with new_listings integration
 * @param {Object} record - Database record to process
 * @param {string} sourceCollection - Source collection name
 * @param {string} targetCollection - Target collection name
 * @param {Object} stats - Statistics object to update
 * @returns {Promise<Object>} Processing result
 */
export async function processBackfillRecord(
  record,
  sourceCollection,
  targetCollection,
  stats,
) {
  const result = {
    recordId: record._id,
    success: false,
    status: null,
    action: null,
    error: null,
  };

  try {
    console.log(`Processing backfill record ${record._id}...`);

    // Check if record already has blockchain and contract
    if (isRecordComplete(record)) {
      const enrichmentData = {
        status: 'skipped_existing_fields',
        reason: 'document_already_has_blockchain_and_contract',
        blockchain: pickBlockchain(record),
        checkedAt: new Date(),
      };

      await updateBackfillRecord(
        targetCollection,
        record,
        extractBaseToken(record),
        enrichmentData,
      );

      stats.skipped_existing_fields += 1;
      stats.matching.unmatchedRecordIds.push(record._id);

      result.success = true;
      result.status = 'skipped_existing_fields';
      result.action = 'skipped';

      console.log(`Record ${record._id} already has complete data, skipping`);
      return result;
    }

    // Step 1: Try to match against new_listings
    const baseToken = extractBaseToken(record);
    const nameCandidates = pickNameCandidates(record);
    let newListingDoc = null;

    // Check if we have data to match on
    if (!baseToken || !nameCandidates.length) {
      stats.matching.noMatchableData += 1;
      stats.matching.unmatchedRecordIds.push(record._id);
      console.log(
        `Record ${record._id}: No symbol or names to match against new_listings`,
      );
    } else {
      // Extract announcement project name for better logging
      const announcementProjectName = extractProjectName(record);
      console.log(
        `🔍 Searching for: symbol="${baseToken}", project="${announcementProjectName}"`,
      );

      // Attempt to find match in new_listings using enhanced similarity ranking
      const enhancedMatch = await findNewListingMatchWithContract(
        baseToken,
        nameCandidates,
        {
          maxResults: 5,
          similarityThreshold: 0.3,
          requireContract: false, // Allow matches without contracts for now
        },
      );

      if (enhancedMatch) {
        newListingDoc = enhancedMatch.document;
        stats.matching.foundNewListingMatch += 1;
        stats.matching.matchedRecordIds.push(record._id);

        console.log(`✓ Enhanced match for ${record._id}:`);
        console.log(
          `   📊 Similarity: ${enhancedMatch.similarity.toFixed(3)} (${
            enhancedMatch.matchType
          })`,
        );
        console.log(
          `   📝 "${announcementProjectName}" ↔ "${enhancedMatch.projectName}"`,
        );
        console.log(`   🔗 Contract: ${enhancedMatch.contractAddress || 'none'}`);
        console.log(`   🏆 Rank: ${enhancedMatch.rank}/${enhancedMatch.totalMatches}`);

        // Store enhanced match details for later use
        record._enhancedMatch = enhancedMatch;
      } else {
        stats.matching.unmatchedRecordIds.push(record._id);
        console.log(
          `✗ No new_listings match found for ${record._id} (symbol: ${baseToken})`,
        );
      }
    }

    // Step 2: Process with new_listing contract if available
    if (newListingDoc) {
      const nlContract = pickContractLoose(newListingDoc);
      const nlChain = pickChainLoose(newListingDoc);

      if (nlContract) {
        // Query Dexscreener by symbol, then locate the pair for nlContract
        console.log(
          `🔍 Querying Dexscreener for symbol: "${baseToken}" (with contract: ${nlContract})`,
        );
        let data;
        try {
          data = await searchDexscreener(baseToken);
        } catch (dexError) {
          console.error(
            `❌ Dexscreener API failed for "${baseToken}":`,
            dexError.message,
          );

          // Create enrichment data for dexscreener failure
          const enrichmentData = createNoMatchEnrichmentData({
            status: 'no_match',
            reason: `dexscreener_api_error: ${dexError.message}`,
            newListingMatchId: newListingDoc._id,
            matchedContract: nlContract,
            preferredChain: nlChain,
            rawData: null,
          });

          await updateBackfillRecord(targetCollection, record, baseToken, enrichmentData);

          stats.error += 1;
          result.success = true;
          result.status = 'no_match';
          result.action = 'dexscreener_api_error';

          console.log(`⚠️ Recorded Dexscreener API error for record ${record._id}`);
          return result;
        }
        const matchResult = selectPairByContract(data, {
          symbol: baseToken,
          names: nameCandidates,
          contract: nlContract,
          preferredChain: nlChain,
        });

        if (matchResult.pair) {
          stats.matching.successfulMatches += 1;

          const enrichmentData = extractEnrichmentData(matchResult, {
            projectName:
              matchResult.pair?.baseToken?.name ||
              nameCandidates[0] ||
              matchResult.pair?.baseToken?.symbol,
            matchedFrom: matchResult.source,
            newListingMatchId: newListingDoc._id,
            matchedContract: nlContract,
            preferredChain: nlChain,
            rawData: data,
          });

          await updateBackfillRecord(targetCollection, record, baseToken, enrichmentData);

          stats.ok_from_new_listing_match += 1;
          result.success = true;
          result.status = enrichmentData.status;
          result.action = 'matched_via_new_listing';

          console.log(
            `✓ Matched via new_listing: ${record._id} -> ${matchResult.pair?.baseToken?.symbol} (${matchResult.pair?.chainId})`,
          );
          return result;
        } else {
          // Found new_listing match but no Dexscreener pairs for the contract
          const enrichmentData = createNoMatchEnrichmentData({
            status: 'no_match_for_new_listing_contract',
            reason: 'dexscreener_no_pair_for_contract',
            newListingMatchId: newListingDoc._id,
            matchedContract: nlContract,
            preferredChain: nlChain,
            rawData: data,
          });

          await updateBackfillRecord(targetCollection, record, baseToken, enrichmentData);

          stats.no_pair_for_new_listing_contract += 1;
          result.success = true;
          result.status = 'no_match_for_new_listing_contract';
          result.action = 'no_dex_pairs_for_contract';

          console.log(
            `⚠ Found new_listing match but no Dexscreener pairs for contract: ${record._id}`,
          );
          return result;
        }
      } else {
        stats.matching.matchedButMissingContract += 1;
        console.log(
          `⚠ Found new_listings match for ${record._id} but missing contract in new_listing record ${newListingDoc._id}`,
        );
      }
    }

    // Mark as no match if we didn't already handle via new_listings
    if (!newListingDoc && baseToken && nameCandidates.length) {
      stats.new_listing_no_match += 1;
    }

    // Step 3: Fallback to original pipeline (symbol → Dexscreener → exact + thresholds + FDV)
    if (!baseToken) {
      const enrichmentData = createNoMatchEnrichmentData({
        status: 'no_match',
        reason: 'no_base_token_extracted',
        rawData: null,
      });

      await updateBackfillRecord(targetCollection, record, baseToken, enrichmentData);

      stats.no_match += 1;
      result.success = true;
      result.status = 'no_match';
      result.action = 'no_base_token';

      console.log(`Record ${record._id}: No base token could be extracted`);
      return result;
    }

    // Query Dexscreener with fallback logic
    const preferredChain = pickBlockchain(record);
    console.log(
      `🔍 Querying Dexscreener for symbol: "${baseToken}" (type: ${typeof baseToken})`,
    );

    let data;
    try {
      data = await searchDexscreener(baseToken);
    } catch (dexError) {
      console.error(`❌ Dexscreener API failed for "${baseToken}":`, dexError.message);

      // Create enrichment data for dexscreener failure
      const enrichmentData = createNoMatchEnrichmentData({
        status: 'no_match',
        reason: `dexscreener_api_error: ${dexError.message}`,
        rawData: null,
      });

      await updateBackfillRecord(targetCollection, record, baseToken, enrichmentData);

      stats.error += 1;
      result.success = true;
      result.status = 'no_match';
      result.action = 'dexscreener_api_error';

      console.log(`⚠️ Recorded Dexscreener API error for record ${record._id}`);
      return result;
    }

    // Use the enhanced selectPairByContract for fallback with empty contract
    const matchResult = selectPairByContract(data, {
      symbol: baseToken,
      names: nameCandidates,
      contract: '',
      preferredChain: preferredChain,
    });

    if (matchResult.pair) {
      const enrichmentData = extractEnrichmentData(matchResult, {
        projectName:
          matchResult.pair?.baseToken?.name ||
          matchResult.pair?.baseToken?.symbol ||
          nameCandidates[0],
        matchedFrom: matchResult.source,
        preferredChain: preferredChain,
        rawData: data,
      });

      await updateBackfillRecord(targetCollection, record, baseToken, enrichmentData);

      stats.ok += 1;
      result.success = true;
      result.status = enrichmentData.status;
      result.action = 'matched_via_symbol';

      console.log(
        `✓ Matched via symbol: ${record._id} -> ${matchResult.pair?.baseToken?.symbol} (${matchResult.pair?.chainId})`,
      );
      return result;
    } else {
      const enrichmentData = createNoMatchEnrichmentData({
        status: 'no_match',
        reason: matchResult.reason,
        rawData: data,
      });

      await updateBackfillRecord(targetCollection, record, baseToken, enrichmentData);

      stats.no_match += 1;
      result.success = true;
      result.status = 'no_match';
      result.action = 'no_dex_match';

      console.log(`✗ No match found: ${record._id} (${matchResult.reason})`);
      return result;
    }
  } catch (error) {
    console.error(`Error processing backfill record ${record._id}:`, error);
    stats.error += 1;

    result.success = false;
    result.error = error.message;
    result.status = 'error';
    result.action = 'error';

    return result;
  }
}

/**
 * Update backfill record in target collection
 * @param {string} targetCollection - Target collection name
 * @param {Object} originalRecord - Original record
 * @param {string} symbol - Extracted symbol
 * @param {Object} enrichmentData - Enrichment data
 */
async function updateBackfillRecord(
  targetCollection,
  originalRecord,
  symbol,
  enrichmentData,
) {
  const collection = getCollection(targetCollection);

  // Extract root-level fields from enrichment data
  const updateFields = {
    sourceCollection: 'announcements',
    symbol: symbol || null,
    blockchain: enrichmentData.chainId || pickBlockchain(originalRecord) || null,
    dexscreener: enrichmentData,
  };

  // Add contract address and financials to root level if available
  if (enrichmentData.contractAddress) {
    updateFields.contract_address = enrichmentData.contractAddress;
  }

  if (enrichmentData.volumeUsd !== null && enrichmentData.volumeUsd !== undefined) {
    updateFields.volumeUsd = enrichmentData.volumeUsd;
  }

  if (enrichmentData.liquidityUsd !== null && enrichmentData.liquidityUsd !== undefined) {
    updateFields.liquidityUsd = enrichmentData.liquidityUsd;
  }

  if (enrichmentData.fdv !== null && enrichmentData.fdv !== undefined) {
    updateFields.fdv = enrichmentData.fdv;
  }

  if (enrichmentData.marketCap !== null && enrichmentData.marketCap !== undefined) {
    updateFields.marketCap = enrichmentData.marketCap;
  }

  if (enrichmentData.priceUsd !== null && enrichmentData.priceUsd !== undefined) {
    updateFields.priceUsd = enrichmentData.priceUsd;
  }

  await collection.updateOne(
    { _id: originalRecord._id },
    { $set: updateFields },
    { upsert: true },
  );
}

/**
 * Process a single record using enhanced matching (new approach)
 * @param {Object} record - Database record to process
 * @param {string} sourceCollection - Source collection name
 * @param {string} targetCollection - Target collection name
 * @param {Object} stats - Statistics object to update
 * @returns {Promise<Object>} Processing result
 */
export async function processRecordWithEnhancedMatching(
  record,
  sourceCollection,
  targetCollection,
  stats,
) {
  const result = {
    recordId: record._id,
    success: false,
    status: null,
    action: null,
    error: null,
    enhancedResult: null,
  };

  try {
    console.log(`Processing enhanced record ${record._id}...`);

    // Extract base token first (needed for all database operations)
    const baseToken = extractBaseToken(record);

    // Check if record already has blockchain and contract
    if (isRecordComplete(record)) {
      const enrichmentData = {
        status: 'skipped_existing_fields',
        reason: 'document_already_has_blockchain_and_contract',
        blockchain: pickBlockchain(record),
        checkedAt: new Date(),
      };

      // Update record with skip status
      await updateBackfillRecord(targetCollection, record, baseToken, enrichmentData);
      console.log(`Enhanced: Record ${record._id} already has complete data, skipping`);

      stats.skipped_existing_fields += 1;
      result.success = true;
      result.status = 'skipped_existing_fields';
      result.action = 'skipped';
      return result;
    }

    if (!baseToken) {
      const enrichmentData = {
        status: 'no_match',
        reason: 'no_base_token_extracted',
        checkedAt: new Date(),
      };

      // Update record with no match status
      await updateBackfillRecord(targetCollection, record, baseToken, enrichmentData);
      console.log(`Enhanced: Record ${record._id}: No base token could be extracted`);

      stats.no_match += 1;
      result.success = true;
      result.status = 'no_match';
      result.action = 'no_base_token';
      return result;
    }

    // Perform enhanced matching that combines new_listings + Dexscreener
    console.log(`🚀 Enhanced matching for ${record._id} with symbol: ${baseToken}`);
    const enhancedResult = await performEnhancedMatching(baseToken, record, {
      maxNewListingResults: 5,
      similarityThreshold: 0.3,
      financialThresholds: {
        volumeMin: 10000,
        marketCapMin: 10000,
      },
    });

    result.enhancedResult = enhancedResult;

    // Check if we got a recommendation
    if (enhancedResult.recommendation) {
      const contractInfo = extractRecommendedContract(enhancedResult);

      if (contractInfo) {
        console.log(`✅ Enhanced recommendation found for ${record._id}:`);
        console.log(`   Contract: ${contractInfo.contractAddress}`);
        console.log(`   Blockchain: ${contractInfo.blockchain}`);
        console.log(`   Volume: $${contractInfo.financials.volumeUsd?.toLocaleString()}`);
        console.log(
          `   MarketCap: $${contractInfo.financials.marketCap?.toLocaleString()}`,
        );
        console.log(`   Source: ${contractInfo.source}`);
        console.log(`   Project name: ${contractInfo.projectName}`);

        // Create enrichment data from enhanced result
        const enrichmentData = {
          status: 'ok_enhanced_matching',
          reason: 'enhanced_matching_success',
          projectName: contractInfo.projectName,
          chainId: contractInfo.blockchain,
          contractAddress: contractInfo.contractAddress,
          pairAddress: contractInfo.pairAddress,
          pairUrl: contractInfo.pairUrl,
          baseSymbol: baseToken,
          baseName: contractInfo.projectName,
          priceUsd: enhancedResult.recommendation.pair?.priceUsd || null,
          fdv: contractInfo.financials.fdv,
          marketCap: contractInfo.financials.marketCap,
          volumeUsd: contractInfo.financials.volumeUsd,
          liquidityUsd: contractInfo.financials.liquidityUsd,
          matchedFrom: contractInfo.source,
          similarity: contractInfo.similarity,
          matchType: contractInfo.matchType,
          enhancedMatchingMetadata: {
            newListingsMatches: enhancedResult.newListingsMatches.length,
            dexscreenerPairs: enhancedResult.dexscreenerPairs.length,
            financialSummary: enhancedResult.financialSummary,
          },
          checkedAt: new Date(),
          raw: enhancedResult,
        };

        // Update record with enhanced enrichment data
        await updateBackfillRecord(targetCollection, record, baseToken, enrichmentData);
        console.log(`✅ Updated record ${record._id} with enhanced enrichment data`);

        stats.ok_from_new_listing_match += 1; // Count as enhanced success
        result.success = true;
        result.status = 'ok_enhanced_matching';
        result.action = 'enhanced_match';
        return result;
      }
    }

    // No recommendation found
    console.log(
      `❌ Enhanced matching found no suitable recommendation for ${record._id}`,
    );

    const enrichmentData = {
      status: 'no_match',
      reason: 'enhanced_matching_no_recommendation',
      enhancedMatchingMetadata: {
        newListingsMatches: enhancedResult.newListingsMatches.length,
        dexscreenerPairs: enhancedResult.dexscreenerPairs.length,
        financialSummary: enhancedResult.financialSummary,
        error: enhancedResult.metadata.error || enhancedResult.metadata.warning,
      },
      checkedAt: new Date(),
      raw: enhancedResult,
    };

    // Update record with no match status
    await updateBackfillRecord(targetCollection, record, baseToken, enrichmentData);
    console.log(`❌ Updated record ${record._id} with no match status`);

    stats.no_match += 1;
    result.success = true;
    result.status = 'no_match';
    result.action = 'enhanced_no_match';
    return result;
  } catch (error) {
    console.error(`Error in enhanced processing for record ${record._id}:`, error);
    stats.error += 1;

    result.success = false;
    result.error = error.message;
    result.status = 'error';
    result.action = 'error';
    return result;
  }
}

/**
 * Process announcements collection for backfill with new_listings integration
 * @param {string} targetCollection - Target collection (default: test_announcement)
 * @param {Object} options - Processing options
 * @param {number} options.limit - Limit number of records
 * @param {number} options.offset - Skip number of records
 * @param {boolean} options.useEnhancedMatching - Use enhanced matching instead of legacy approach
 * @returns {Promise<Object>} Complete processing results with statistics
 */
export async function processAnnouncementsBackfill(
  targetCollection = 'test_announcement',
  options = {},
) {
  const { limit, offset, useEnhancedMatching = false } = options;

  console.log(`Starting announcements backfill to ${targetCollection}...`);
  console.log(`Enhanced matching mode: ${useEnhancedMatching ? 'ENABLED' : 'DISABLED'}`);

  const sourceCollection = getCollection('announcements');
  const newListingsCount = await getNewListingsCount();
  const totalAnnouncements = await sourceCollection.countDocuments({});

  console.log(
    `Source announcements: ${totalAnnouncements}, New listings: ${newListingsCount}`,
  );

  // Build query and cursor
  let cursor = sourceCollection.find({});

  if (typeof offset === 'number' && offset > 0) {
    cursor = cursor.skip(offset);
  }

  if (typeof limit === 'number' && limit > 0) {
    cursor = cursor.limit(limit);
  }

  const stats = {
    // Collection totals
    totalAnnouncementsCount: totalAnnouncements,
    totalNewListingsCount: newListingsCount,

    // Processing stats
    scanned: 0,
    ok: 0,
    ok_from_new_listing_match: 0,
    no_match: 0,
    skipped_existing_fields: 0,
    error: 0,
    no_pair_for_new_listing_contract: 0,
    new_listing_no_match: 0,

    // Cross-collection matching statistics
    matching: {
      foundNewListingMatch: 0,
      noMatchableData: 0,
      matchedButMissingContract: 0,
      successfulMatches: 0,
      matchedRecordIds: [],
      unmatchedRecordIds: [],
    },

    // Processing details
    processedRecords: [],
    errors: [],
  };

  for await (const record of cursor) {
    stats.scanned += 1;
    console.log(`\n--- Processing record ${stats.scanned}: ${record._id} ---`);

    // Choose processing method based on enhanced matching flag
    const result = useEnhancedMatching
      ? await processRecordWithEnhancedMatching(
          record,
          'announcements',
          targetCollection,
          stats,
        )
      : await processBackfillRecord(record, 'announcements', targetCollection, stats);

    stats.processedRecords.push({
      recordId: result.recordId,
      status: result.status,
      action: result.action,
      success: result.success,
    });

    if (result.error) {
      stats.errors.push({
        recordId: result.recordId,
        error: result.error,
      });
    }

    // Progress logging
    if (stats.scanned % 10 === 0) {
      console.log(`\n📊 Progress: ${stats.scanned} records processed`);
      console.log(
        `   ✓ OK: ${stats.ok}, New listing matches: ${stats.ok_from_new_listing_match}`,
      );
      console.log(`   ✗ No match: ${stats.no_match}, Errors: ${stats.error}`);
    }
  }

  // Calculate final statistics
  const totalProcessed =
    stats.ok +
    stats.ok_from_new_listing_match +
    stats.no_match +
    stats.skipped_existing_fields;
  const successRate =
    totalProcessed > 0
      ? (((stats.ok + stats.ok_from_new_listing_match) / totalProcessed) * 100).toFixed(2)
      : '0.00';

  console.log(`\n🎯 Backfill Complete!`);
  console.log(
    `   📈 Success rate: ${successRate}% (${
      stats.ok + stats.ok_from_new_listing_match
    }/${totalProcessed})`,
  );
  console.log(
    `   🔗 New listing integration: ${stats.matching.foundNewListingMatch} matches found`,
  );

  return {
    ok: true,
    stats,
    summary: {
      totalScanned: stats.scanned,
      totalProcessed,
      successRate: `${successRate}%`,
      newListingMatches: stats.matching.foundNewListingMatch,
      errors: stats.error,
    },
  };
}

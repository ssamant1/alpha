// src/core/handlers.js
import mongoose from 'mongoose';
import { config } from '../config.js';
import { processTokenRecord } from './processors.js';

/**
 * Change stream and event handlers
 * Handles MongoDB change streams and coordinates processing
 */

/**
 * Handle a single insert event from change stream
 * @param {Object} change - MongoDB change stream event
 * @returns {Promise<void>}
 */
export async function handleInsertEvent(change) {
  try {
    const collectionName = change?.ns?.coll;
    const document = change?.fullDocument;

    if (!collectionName || !document) {
      console.warn('Invalid change event received:', {
        collectionName,
        hasDocument: !!document,
      });
      return;
    }

    console.log(`Processing insert in ${collectionName}: ${document._id}`);

    // Process the inserted record
    const result = await processTokenRecord(document, collectionName);

    if (result.success) {
      console.log(`✓ Successfully processed ${document._id} in ${collectionName}`);
    } else {
      console.log(
        `✗ Failed to process ${document._id} in ${collectionName}: ${result.reason}`,
      );
    }
  } catch (error) {
    console.error('Error in handleInsertEvent:', error.message);
    // Don't throw - we want the change stream to continue
  }
}

// Global variables for reconnection logic
let currentChangeStream = null;
let reconnectAttempts = 0;
let isReconnecting = false;
const MAX_RECONNECT_DELAY = 30000; // 30 seconds max delay
const BASE_RECONNECT_DELAY = 1000; // Start with 1 second

/**
 * Calculate exponential backoff delay for reconnection attempts
 * @param {number} attempt - Current attempt number
 * @returns {number} Delay in milliseconds
 */
function calculateReconnectDelay(attempt) {
  const delay = Math.min(
    BASE_RECONNECT_DELAY * Math.pow(2, attempt),
    MAX_RECONNECT_DELAY,
  );
  return delay + Math.random() * 1000; // Add jitter
}

/**
 * Start MongoDB change stream monitoring with robust reconnection logic
 * @param {Array} targetCollections - Collections to monitor
 * @returns {Promise<Object>} The change stream object
 */
export async function startChangeStreamMonitoring(
  targetCollections = config.collections.targets,
) {
  if (isReconnecting) {
    console.log('Reconnection already in progress, skipping...');
    return currentChangeStream;
  }

  try {
    console.log(
      `Starting change stream monitoring for collections: ${targetCollections.join(
        ', ',
      )}`,
    );

    // Close existing stream if any
    if (currentChangeStream) {
      try {
        await currentChangeStream.close();
      } catch (err) {
        console.warn('Error closing existing change stream:', err.message);
      }
    }

    // Check MongoDB connection
    if (mongoose.connection.readyState !== 1) {
      console.log('MongoDB not connected, waiting for connection...');
      await new Promise((resolve, reject) => {
        if (mongoose.connection.readyState === 1) {
          resolve();
          return;
        }

        const timeout = setTimeout(() => {
          reject(new Error('MongoDB connection timeout'));
        }, 10000);

        mongoose.connection.once('connected', () => {
          clearTimeout(timeout);
          resolve();
        });

        mongoose.connection.once('error', (err) => {
          clearTimeout(timeout);
          reject(err);
        });
      });
    }

    const changeStream = mongoose.connection.db.watch(
      [
        {
          $match: {
            'ns.coll': { $in: targetCollections },
            operationType: 'insert',
          },
        },
      ],
      {
        fullDocument: 'updateLookup',
        resumeAfter: null, // Will use automatic resume token handling
      },
    );

    currentChangeStream = changeStream;

    changeStream.on('change', async (change) => {
      try {
        await handleInsertEvent(change);
        // Reset reconnect attempts on successful processing
        reconnectAttempts = 0;
      } catch (error) {
        console.error('Error processing change event:', error.message);
        // Don't close stream for processing errors
      }
    });

    changeStream.on('error', async (error) => {
      console.error(
        `Change stream error (attempt ${reconnectAttempts + 1}):`,
        error.message,
      );

      // Close the current stream
      try {
        if (!changeStream.closed) {
          await changeStream.close();
        }
      } catch (closeErr) {
        console.warn('Error closing change stream after error:', closeErr.message);
      }

      currentChangeStream = null;

      // Start reconnection process
      await scheduleReconnection(targetCollections);
    });

    changeStream.on('close', async () => {
      console.log('Change stream closed unexpectedly');
      currentChangeStream = null;

      // Only reconnect if not already reconnecting and not during shutdown
      if (!isReconnecting && !process.exitCode) {
        await scheduleReconnection(targetCollections);
      }
    });

    changeStream.on('resumeTokenChanged', () => {
      // console.log('Change stream resume token updated');
    });

    console.log('Change stream monitoring started successfully');
    reconnectAttempts = 0; // Reset on successful start

    return changeStream;
  } catch (error) {
    console.error('Failed to start change stream:', error.message);
    currentChangeStream = null;

    // Schedule reconnection
    await scheduleReconnection(targetCollections);
    throw error;
  }
}

/**
 * Schedule reconnection with exponential backoff
 * @param {Array} targetCollections - Collections to monitor
 */
async function scheduleReconnection(targetCollections) {
  if (isReconnecting) {
    return;
  }

  isReconnecting = true;
  reconnectAttempts++;

  const delay = calculateReconnectDelay(reconnectAttempts);

  console.log(
    `Scheduling change stream reconnection in ${Math.round(
      delay / 1000,
    )}s (attempt ${reconnectAttempts})`,
  );

  setTimeout(async () => {
    try {
      isReconnecting = false;

      // Check if MongoDB is still connected
      if (mongoose.connection.readyState !== 1) {
        console.log('MongoDB disconnected, waiting for reconnection...');
        await new Promise((resolve) => {
          if (mongoose.connection.readyState === 1) {
            resolve();
            return;
          }
          mongoose.connection.once('connected', resolve);
        });
      }

      console.log('Attempting to restart change stream...');
      await startChangeStreamMonitoring(targetCollections);
      console.log('Change stream reconnected successfully');
    } catch (error) {
      console.error('Reconnection failed:', error.message);
      isReconnecting = false;

      // Continue trying to reconnect
      if (reconnectAttempts < 100) {
        // Prevent infinite growth
        await scheduleReconnection(targetCollections);
      } else {
        console.error('Maximum reconnection attempts reached, stopping retries');
      }
    }
  }, delay);
}

/**
 * Graceful shutdown handler
 * @returns {Promise<void>}
 */
export async function shutdownHandler() {
  console.log('Shutting down gracefully...');

  // Stop reconnection attempts
  isReconnecting = false;

  if (currentChangeStream) {
    try {
      await currentChangeStream.close();
      console.log('Change stream closed');
    } catch (error) {
      console.warn('Error closing change stream during shutdown:', error.message);
    }
    currentChangeStream = null;
  }

  try {
    await mongoose.connection.close();
    console.log('Database connection closed');
  } catch (error) {
    console.warn('Error closing database connection:', error.message);
  }

  process.exit(0);
}

/**
 * Setup process signal handlers for graceful shutdown
 */
export function setupShutdownHandlers() {
  process.on('SIGINT', () => shutdownHandler());
  process.on('SIGTERM', () => shutdownHandler());
  process.on('uncaughtException', (error) => {
    console.error('Uncaught exception:', error);
    shutdownHandler();
  });
  process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled rejection at:', promise, 'reason:', reason);
    shutdownHandler();
  });
}

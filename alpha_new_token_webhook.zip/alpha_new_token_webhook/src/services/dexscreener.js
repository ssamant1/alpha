// src/services/dexscreener.js
import { config } from '../config.js';

/**
 * Dexscreener API service with rate limiting
 * Uses functional approach with closure for state management
 */

// Private state for rate limiting
let queue = Promise.resolve();
let lastCallTs = 0;

/**
 * Fetch Dexscreener search results with rate limiting
 * @param {string} query - Token symbol or address to search
 * @returns {Promise<Object>} Dexscreener API response
 */
export async function searchDexscreener(query) {
  return queue = queue.then(async () => {
    const elapsed = Date.now() - lastCallTs;
    const waitMs = Math.max(0, config.dexscreener.minGapMs - elapsed);

    if (waitMs > 0) {
      await new Promise(resolve => setTimeout(resolve, waitMs));
    }

    lastCallTs = Date.now();
    return fetchDexscreenerData(query);
  });
}

/**
 * Internal function to fetch data from Dexscreener API
 * @param {string} query - Search query
 * @returns {Promise<Object>} API response
 */
async function fetchDexscreenerData(query) {
  // Validate and clean the query
  if (!query || typeof query !== 'string') {
    throw new Error(`Invalid query: ${query} (type: ${typeof query})`);
  }

  const cleanQuery = query.trim();
  if (!cleanQuery) {
    throw new Error(`Empty query after trimming: "${query}"`);
  }

  // Additional validation for Dexscreener API requirements
  if (cleanQuery.length < 2) {
    throw new Error(`Query too short (${cleanQuery.length} chars): "${cleanQuery}". Minimum 2 characters required.`);
  }

  // Check for problematic characters that might cause 400 errors
  const problematicChars = /[<>{}[\]\\^`|]/;
  if (problematicChars.test(cleanQuery)) {
    console.warn(`⚠️ Query contains potentially problematic characters: "${cleanQuery}"`);
  }

  const url = `https://api.dexscreener.com/latest/dex/search?q=${encodeURIComponent(cleanQuery)}`;
  console.log(`🌐 Dexscreener API call: ${url}`);

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), config.dexscreener.timeoutMs);

  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: { Accept: '*/*' },
      signal: controller.signal,
    });

    console.log(`📡 Dexscreener response: ${response.status} ${response.statusText}`);

    if (!response.ok) {
      let errorDetails = '';
      try {
        const errorText = await response.text();
        errorDetails = errorText ? ` - ${errorText}` : '';
      } catch (e) {
        // Ignore error text parsing failures
      }

      throw new Error(`Dexscreener HTTP ${response.status}${errorDetails} for query: "${cleanQuery}"`);
    }

    const data = await response.json();
    console.log(`✅ Dexscreener success: ${data.pairs?.length || 0} pairs found for "${cleanQuery}"`);
    return data;
  } catch (error) {
    console.error(`❌ Dexscreener error for query "${cleanQuery}":`, error.message);
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}

/**
 * Reset rate limiting state (useful for testing)
 */
export function resetDexscreenerRateLimit() {
  queue = Promise.resolve();
  lastCallTs = 0;
}
// src/services/enhanced-matching.js
import { searchDexscreener } from './dexscreener.js';
import {
  findNewListingMatches,
  pickNameCandidates,
  extractProjectName,
} from './new-listings.js';
import { calculateSimilarity } from '../utils/string-similarity.js';
import {
  getVolumeUsd,
  getLiquidityUsd,
  VOLUME_MIN_USD,
  LIQ_MIN_USD,
} from '../../utils.js';

/**
 * Enhanced matching service that combines new_listings ranking with Dexscreener financial filtering
 * Implements the complete flow: new_listings → Dexscreener → financial ranking → best match
 */

const FINANCIAL_THRESHOLDS = {
  volumeMin: 10000, // $10k minimum volume
  marketCapMin: 10000, // $10k minimum market cap
};

/**
 * Rank Dexscreener pairs by project name similarity
 * @param {Array} pairs - Array of Dexscreener pairs
 * @param {Array} nameCandidates - Project name candidates from announcement
 * @param {Object} options - Ranking options
 * @returns {Array} Ranked pairs with similarity scores
 */
function rankDexscreenerPairsBySimilarity(pairs, nameCandidates = [], options = {}) {
  const { similarityThreshold = 0.3 } = options;

  if (!pairs.length || !nameCandidates.length) {
    // If no name candidates, return pairs without similarity ranking
    return pairs.map((pair, index) => ({
      pair,
      similarity: 0,
      matchType: 'symbol_only',
      rank: index + 1,
      projectName: pair.baseToken?.name || pair.baseToken?.symbol || 'Unknown',
    }));
  }

  const scoredPairs = [];

  for (const pair of pairs) {
    const dexProjectName = pair.baseToken?.name || pair.baseToken?.symbol;
    if (!dexProjectName) continue;

    let maxSimilarity = 0;
    let bestMatchName = null;

    // Compare against all announcement name candidates
    for (const announcementName of nameCandidates) {
      const similarity = calculateSimilarity(announcementName, dexProjectName, {
        caseSensitive: false,
        trimWhitespace: true,
        normalizeSpaces: true,
      });

      if (similarity > maxSimilarity) {
        maxSimilarity = similarity;
        bestMatchName = announcementName;
      }
    }

    // Only include pairs above similarity threshold
    if (maxSimilarity >= similarityThreshold) {
      scoredPairs.push({
        pair,
        similarity: maxSimilarity,
        matchType: maxSimilarity >= 0.9 ? 'exact_name' : 'similar_name',
        projectName: dexProjectName,
        matchedAgainst: bestMatchName,
        rank: 0, // Will be set after sorting
      });
    }
  }

  // Sort by similarity score (highest first)
  scoredPairs.sort((a, b) => b.similarity - a.similarity);

  // Assign ranks
  return scoredPairs.map((scoredPair, index) => ({
    ...scoredPair,
    rank: index + 1,
  }));
}

/**
 * Apply financial thresholds and rank by FDV
 * @param {Array} rankedPairs - Pairs ranked by similarity
 * @param {Object} thresholds - Financial thresholds
 * @returns {Array} Pairs that pass thresholds, ranked by FDV descending
 */
export function applyFinancialFiltering(rankedPairs, thresholds = FINANCIAL_THRESHOLDS) {
  const { volumeMin, marketCapMin } = thresholds;

  const pairsWithFinancials = rankedPairs.map((rankedPair) => {
    const pair = rankedPair.pair;
    const volumeUsd = getVolumeUsd(pair.volume);
    const liquidityUsd = getLiquidityUsd(pair.liquidity);
    const marketCap = typeof pair.marketCap === 'number' ? pair.marketCap : 0;
    const fdv = typeof pair.fdv === 'number' && Number.isFinite(pair.fdv) ? pair.fdv : 0;

    return {
      ...rankedPair,
      financials: {
        volumeUsd,
        liquidityUsd,
        marketCap,
        fdv,
      },
      passesThresholds: volumeUsd >= volumeMin && marketCap >= marketCapMin,
    };
  });

  // Filter pairs that pass financial thresholds
  const qualifiedPairs = pairsWithFinancials.filter((p) => p.passesThresholds);

  if (qualifiedPairs.length === 0) {
    console.log(
      `No pairs pass financial thresholds (volume >= $${volumeMin}, marketCap >= $${marketCapMin})`,
    );
    return [];
  }

  // Rank qualified pairs by FDV descending
  qualifiedPairs.sort((a, b) => b.financials.fdv - a.financials.fdv);

  return qualifiedPairs;
}

/**
 * Find contract address in Dexscreener pairs by address matching
 * @param {Array} pairs - Dexscreener pairs
 * @param {string} contractAddress - Contract address to find
 * @param {string} blockchain - Optional blockchain filter
 * @returns {Object|null} Matching pair or null
 */
function findContractInDexscreenerPairs(pairs, contractAddress, blockchain = '') {
  if (!contractAddress) return null;

  const normalizedContract = contractAddress.toLowerCase();
  const normalizedBlockchain = blockchain.toLowerCase();

  for (const pair of pairs) {
    const pairContract = pair.baseToken?.address?.toLowerCase();
    const pairChain = pair.chainId?.toLowerCase();

    // Match by contract address
    if (pairContract === normalizedContract) {
      // If blockchain is specified, ensure it matches
      if (blockchain && pairChain !== normalizedBlockchain) {
        continue;
      }
      return pair;
    }
  }

  return null;
}

/**
 * Enhanced matching that combines new_listings with Dexscreener financial ranking
 * @param {string} symbol - Token symbol to search for
 * @param {Object} announcementRecord - Announcement record with project names
 * @param {Object} options - Matching options
 * @returns {Promise<Object>} Complete matching result with rankings and financials
 */
export async function performEnhancedMatching(symbol, announcementRecord, options = {}) {
  const {
    maxNewListingResults = 30,
    similarityThreshold = 0.3,
    financialThresholds = FINANCIAL_THRESHOLDS,
  } = options;

  console.log(`🔍 Starting enhanced matching for symbol: ${symbol}`);

  // Extract name candidates from announcement
  const nameCandidates = pickNameCandidates(announcementRecord);
  const announcementProjectName = extractProjectName(announcementRecord);

  console.log(`📝 Announcement project: "${announcementProjectName}"`);
  console.log(`📋 Name candidates: ${nameCandidates.join(', ')}`);

  const result = {
    symbol,
    announcementProjectName,
    nameCandidates,
    newListingsMatches: [],
    dexscreenerPairs: [],
    contractMatchResult: null,
    fallbackMatchResult: null,
    recommendation: null,
    financialSummary: {},
    metadata: {},
  };

  try {
    // Step 1: Get ranked matches from new_listings
    console.log(`\n🔗 Step 1: Searching new_listings for symbol "${symbol}"`);
    const newListingsMatches = await findNewListingMatches(symbol, nameCandidates, {
      maxResults: maxNewListingResults,
      similarityThreshold,
    });

    result.newListingsMatches = newListingsMatches;
    console.log(`   Found ${newListingsMatches.length} new_listings matches`);

    // Step 2: Get Dexscreener data for the symbol
    console.log(`\n📊 Step 2: Fetching Dexscreener data for symbol "${symbol}"`);
    const dexscreenerData = await searchDexscreener(symbol);
    const dexPairs = Array.isArray(dexscreenerData?.pairs) ? dexscreenerData.pairs : [];

    console.log(`   Found ${dexPairs.length} Dexscreener pairs`);

    if (dexPairs.length === 0) {
      result.metadata.error = 'No Dexscreener pairs found for symbol';
      return result;
    }

    // Step 3: Rank Dexscreener pairs by project name similarity
    console.log(`\n📈 Step 3: Ranking Dexscreener pairs by name similarity`);
    const rankedDexPairs = rankDexscreenerPairsBySimilarity(dexPairs, nameCandidates, {
      similarityThreshold,
    });

    result.dexscreenerPairs = rankedDexPairs;
    console.log(`   Ranked ${rankedDexPairs.length} pairs by similarity`);

    // Step 4: Check if we have contract address from new_listings matches
    const bestNewListingMatch =
      newListingsMatches.length > 0 ? newListingsMatches[0] : null;

    if (bestNewListingMatch && bestNewListingMatch.contractAddress) {
      console.log(`\n🎯 Step 4a: Contract address available from new_listings`);
      console.log(`   Contract: ${bestNewListingMatch.contractAddress}`);
      console.log(
        `   Blockchain: ${bestNewListingMatch.document.blockchain || 'unknown'}`,
      );

      // Find this specific contract in Dexscreener pairs
      const contractMatch = findContractInDexscreenerPairs(
        dexPairs,
        bestNewListingMatch.contractAddress,
        bestNewListingMatch.document.blockchain,
      );

      if (contractMatch) {
        console.log(`   ✅ Found contract match in Dexscreener`);
        const volumeUsd = getVolumeUsd(contractMatch.volume);
        const marketCap =
          typeof contractMatch.marketCap === 'number' ? contractMatch.marketCap : 0;
        const fdv =
          typeof contractMatch.fdv === 'number' && Number.isFinite(contractMatch.fdv)
            ? contractMatch.fdv
            : 0;

        result.contractMatchResult = {
          pair: contractMatch,
          contractAddress: bestNewListingMatch.contractAddress,
          blockchain: contractMatch.chainId,
          financials: {
            volumeUsd,
            marketCap,
            fdv,
            liquidityUsd: getLiquidityUsd(contractMatch.liquidity),
          },
          passesThresholds:
            volumeUsd >= financialThresholds.volumeMin &&
            marketCap >= financialThresholds.marketCapMin,
          source: 'contract_match_from_new_listings',
        };

        console.log(
          `   💰 Volume: $${volumeUsd.toLocaleString()}, MarketCap: $${marketCap.toLocaleString()}, FDV: $${fdv.toLocaleString()}`,
        );

        // If this contract match passes thresholds, use it as recommendation
        if (result.contractMatchResult.passesThresholds) {
          result.recommendation = result.contractMatchResult;
          console.log(`   🏆 Contract match passes thresholds - using as recommendation`);
        } else {
          console.log(`   ⚠️ Contract match fails financial thresholds`);

          // Find alternative pairs that pass thresholds
          const qualifiedPairs = applyFinancialFiltering(
            rankedDexPairs,
            financialThresholds,
          );
          if (qualifiedPairs.length > 0) {
            result.fallbackMatchResult = {
              ...qualifiedPairs[0],
              source: 'best_financial_alternative',
            };
            result.recommendation = result.fallbackMatchResult;
            console.log(`   🔄 Using best financial alternative as recommendation`);
          }
        }
      } else {
        console.log(`   ❌ Contract not found in Dexscreener pairs`);

        // Fall back to financial ranking without contract matching
        const qualifiedPairs = applyFinancialFiltering(
          rankedDexPairs,
          financialThresholds,
        );
        if (qualifiedPairs.length > 0) {
          result.fallbackMatchResult = {
            ...qualifiedPairs[0],
            source: 'best_financial_no_contract_match',
          };
          result.recommendation = result.fallbackMatchResult;
          console.log(`   🔄 No contract match - using best financial pair`);
        }
      }
    } else {
      console.log(
        `\n📊 Step 4b: No contract address from new_listings - using financial ranking`,
      );

      // Apply financial filtering and ranking
      const qualifiedPairs = applyFinancialFiltering(rankedDexPairs, financialThresholds);

      if (qualifiedPairs.length > 0) {
        result.fallbackMatchResult = {
          ...qualifiedPairs[0],
          source: 'best_financial_no_new_listings_contract',
        };
        result.recommendation = result.fallbackMatchResult;

        const best = qualifiedPairs[0];
        console.log(`   🏆 Best financial match: "${best.projectName}"`);
        console.log(
          `   💰 Volume: $${best.financials.volumeUsd.toLocaleString()}, MarketCap: $${best.financials.marketCap.toLocaleString()}, FDV: $${best.financials.fdv.toLocaleString()}`,
        );
      } else {
        console.log(`   ❌ No pairs pass financial thresholds`);
        result.metadata.warning = 'No pairs meet financial requirements';
      }
    }

    // Generate financial summary
    const allPassingPairs = applyFinancialFiltering(rankedDexPairs, financialThresholds);
    result.financialSummary = {
      totalDexscreenerPairs: dexPairs.length,
      pairsWithSimilarity: rankedDexPairs.length,
      pairsPassingThresholds: allPassingPairs.length,
      volumeThreshold: financialThresholds.volumeMin,
      marketCapThreshold: financialThresholds.marketCapMin,
      hasRecommendation: !!result.recommendation,
    };

    console.log(`\n📋 Summary:`);
    console.log(
      `   - Total Dexscreener pairs: ${result.financialSummary.totalDexscreenerPairs}`,
    );
    console.log(
      `   - Pairs with name similarity: ${result.financialSummary.pairsWithSimilarity}`,
    );
    console.log(
      `   - Pairs passing financial thresholds: ${result.financialSummary.pairsPassingThresholds}`,
    );
    console.log(
      `   - Has recommendation: ${
        result.financialSummary.hasRecommendation ? 'Yes' : 'No'
      }`,
    );

    // TODO: Add database operations to persist results
    result.metadata.dbOperationTodo =
      'Database operations to persist enhanced matching results need to be implemented';

    return result;
  } catch (error) {
    console.error('Enhanced matching error:', error);
    result.metadata.error = error.message;
    return result;
  }
}

/**
 * Extract contract and blockchain from enhanced matching recommendation
 * @param {Object} enhancedResult - Result from performEnhancedMatching
 * @returns {Object|null} Contract info or null if no recommendation
 */
export function extractRecommendedContract(enhancedResult) {
  if (!enhancedResult.recommendation) {
    return null;
  }

  const rec = enhancedResult.recommendation;
  const pair = rec.pair;

  return {
    contractAddress: rec.contractAddress || pair.baseToken?.address || null,
    blockchain: pair.chainId || null,
    projectName: rec.projectName || pair.baseToken?.name || pair.baseToken?.symbol,
    financials: rec.financials,
    source: rec.source,
    similarity: rec.similarity || 0,
    matchType: rec.matchType || 'financial_ranking',
    pairAddress: pair.pairAddress,
    pairUrl: pair.url,
  };
}

/**
 * Test endpoint helper for enhanced matching
 * @param {string} symbol - Token symbol
 * @param {string} name - Project name (optional)
 * @returns {Promise<Object>} Test results
 */
export async function testEnhancedMatching(symbol, name = '') {
  // Create mock announcement record
  const mockRecord = {
    name: name || symbol,
    Project_name: name || symbol,
    project_name: name || symbol,
    title: name || symbol,
  };

  const result = await performEnhancedMatching(symbol, mockRecord);

  return {
    input: { symbol, name },
    result,
    contractRecommendation: extractRecommendedContract(result),
  };
}

const MIN_AGE_HOURS = 6;

export function applyFinancialFilterSingle(
  rankedPairs,
  thresholds = FINANCIAL_THRESHOLDS,
) {
  const { volumeMin, marketCapMin } = thresholds;

  const now = Date.now();
  const minAgeMs = MIN_AGE_HOURS * 60 * 60 * 1000;

  const pairsWithFinancials = rankedPairs.map((pair) => {
    // const pair = rankedPair.pair;
    const volumeUsd = getVolumeUsd(pair.volume);
    const liquidityUsd = getLiquidityUsd(pair.liquidity);
    const marketCap = typeof pair.marketCap === 'number' ? pair.marketCap : 0;
    const fdv = typeof pair.fdv === 'number' && Number.isFinite(pair.fdv) ? pair.fdv : 0;

    const createdAtMs =
      typeof pair.pairCreatedAt === 'number' && Number.isFinite(pair.pairCreatedAt)
        ? pair.pairCreatedAt
        : null;

    const passesAge = createdAtMs !== null ? now - createdAtMs >= minAgeMs : false; // exclude if missing/invalid

    return {
      ...pair,
      financials: {
        volumeUsd,
        liquidityUsd,
        marketCap,
        fdv,
      },
      passesThresholds: volumeUsd >= volumeMin && marketCap >= marketCapMin && passesAge,
    };
  });

  // Filter pairs that pass financial thresholds
  const qualifiedPairs = pairsWithFinancials.filter((p) => p.passesThresholds);

  if (qualifiedPairs.length === 0) {
    console.log(
      `No pairs pass financial thresholds (volume >= $${volumeMin}, marketCap >= $${marketCapMin})`,
    );
    return [];
  }

  // Rank qualified pairs by FDV descending
  qualifiedPairs.sort((a, b) => b.financials.fdv - a.financials.fdv);

  return qualifiedPairs;
}

class AlphaProjectMatcher {
  constructor() {
    this.minMarketCap = 10000;
    this.minVolume = 10000;
  }

  findBestAlphaProject(dbRecord, dexScreenerPairs) {
    // Step 1: Filter by exact symbol match (case-insensitive)
    const searchSymbol = dbRecord.symbol.toLowerCase().trim();
    const symbolMatches = dexScreenerPairs.filter(
      (pair) => pair.baseToken.symbol.toLowerCase().trim() === searchSymbol,
    );

    // If no symbol matches found, return null
    if (symbolMatches.length === 0) {
      console.log(`No matches found for symbol: ${dbRecord.symbol}`);
      return null;
    }

    console.log(`Found ${symbolMatches.length} pairs with symbol ${dbRecord.symbol}`);

    // Step 2: Calculate name match percentage for each symbol match
    const searchName = this.normalize(dbRecord.name);
    const matchesWithScores = symbolMatches.map((pair) => {
      const tokenName = this.normalize(pair.baseToken.name);

      let nameMatchPercentage = 0;
      let matchType = null;

      // Check if search name is contained in token name
      if (tokenName.includes(searchName)) {
        nameMatchPercentage = (searchName.length / tokenName.length) * 100;
        matchType = 'NAME_IN_TOKEN';
      }
      // Check if token name is contained in search name
      else if (searchName.includes(tokenName)) {
        nameMatchPercentage = (tokenName.length / searchName.length) * 100;
        matchType = 'TOKEN_IN_NAME';
      }
      // Check for partial word matches
      else {
        nameMatchPercentage = this.calculatePartialMatch(searchName, tokenName);
        matchType = 'PARTIAL_MATCH';
      }

      return {
        pair,
        nameMatchPercentage,
        matchType,
        tokenName: pair.baseToken.name,
        tokenSymbol: pair.baseToken.symbol,
        marketCap: pair.marketCap || 0,
        volume24h: pair.volume?.h24 || 0,
        fdv: pair.fdv || 0,
        liquidity: pair.liquidity?.usd || 0,
      };
    });

    // Step 3: Filter by financial criteria
    const financiallyViable = matchesWithScores.filter(
      (match) =>
        match.marketCap >= this.minMarketCap && match.volume24h >= this.minVolume,
    );

    if (financiallyViable.length === 0) {
      console.log(`Symbol matches found but none meet financial criteria`);
      console.log(
        `Failed matches:`,
        matchesWithScores.map((m) => ({
          name: m.tokenName,
          marketCap: m.marketCap,
          volume: m.volume24h,
        })),
      );
      return null;
    }

    // Step 4: Rank by name match first, then by FDV
    financiallyViable.sort((a, b) => {
      // If name match percentages are very different (>20% difference), use that
      if (Math.abs(a.nameMatchPercentage - b.nameMatchPercentage) > 20) {
        return b.nameMatchPercentage - a.nameMatchPercentage;
      }
      // Otherwise, prioritize by FDV
      return b.fdv - a.fdv;
    });

    return financiallyViable[0];
  }

  // Simple normalization
  normalize(str) {
    return str
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  // Calculate partial match for cases where neither string contains the other
  calculatePartialMatch(str1, str2) {
    const words1 = str1.split(' ');
    const words2 = str2.split(' ');

    let matchedWords = 0;
    let totalChars = 0;

    for (const word1 of words1) {
      for (const word2 of words2) {
        if (word1 === word2) {
          matchedWords++;
          totalChars += word1.length;
          break;
        }
      }
    }

    if (matchedWords === 0) return 0;

    // Return percentage based on matched characters vs total length
    return (totalChars / Math.max(str1.length, str2.length)) * 100;
  }
}

// Export the class
export default AlphaProjectMatcher;

// Usage example (commented out)
// const matcher = new AlphaProjectMatcher();
// const bestMatch = matcher.findBestAlphaProject(dbRecord, dexScreenerPairs);
//
// if (bestMatch) {
//   console.log(`Best Match: ${bestMatch.tokenName} (${bestMatch.tokenSymbol})`);
//   console.log(`Name Match: ${bestMatch.nameMatchPercentage.toFixed(1)}%`);
//   console.log(`FDV: $${bestMatch.fdv.toLocaleString()}`);
//   console.log(`Market Cap: $${bestMatch.marketCap.toLocaleString()}`);
//   console.log(`24h Volume: $${bestMatch.volume24h.toLocaleString()}`);
// }

// src/services/matching.js
import {
  isExactBaseMatch,
  selectTopExactPair,
  getVolumeUsd,
  getLiquidityUsd,
  VOLUME_MIN_USD,
  LIQ_MIN_USD
} from '../../utils.js';

/**
 * Token matching and validation service
 * Handles all logic related to matching tokens and validating thresholds
 */

/**
 * Analyze a Dexscreener response to find matching pairs
 * @param {Object} dexData - Dexscreener API response
 * @param {string} baseToken - Token symbol to match
 * @param {string} preferredChain - Optional preferred blockchain
 * @returns {Object} Analysis result with top pair and metrics
 */
export function analyzeTokenMatch(dexData, baseToken, preferredChain = '') {
  const pairs = Array.isArray(dexData?.pairs) ? dexData.pairs : [];

  if (!pairs.length) {
    return {
      status: 'no_match',
      reason: 'no_pairs',
      pairs: 0
    };
  }

  // Use the improved exact matching logic
  const { top, vol, liq, reason } = selectTopExactPair(dexData, baseToken, preferredChain);

  if (!top) {
    return {
      status: 'no_match',
      reason: reason || 'unknown',
      pairs: pairs.length
    };
  }

  // Validate thresholds
  if (vol <= VOLUME_MIN_USD || liq <= LIQ_MIN_USD) {
    return {
      status: 'no_match',
      reason: 'thresholds_not_met_or_no_fdv',
      pairs: pairs.length,
      topPair: top,
      volume: vol,
      liquidity: liq
    };
  }

  return {
    status: 'ok',
    reason: 'ok_exact_base',
    pairs: pairs.length,
    topPair: top,
    volume: vol,
    liquidity: liq,
    fdv: top.fdv
  };
}

/**
 * Extract enrichment data from a successful match
 * @param {Object} matchResult - Result from analyzeTokenMatch or selectPairByContract
 * @param {Object} options - Additional options for enrichment
 * @param {string} options.projectName - Project name override
 * @param {string} options.matchedFrom - Source of the match (name_symbol, exact_base, contract)
 * @param {string} options.newListingMatchId - ID of matched new_listing record
 * @param {string} options.matchedContract - Contract address that was matched
 * @param {string} options.preferredChain - Preferred chain that was used
 * @param {Object} options.rawData - Raw Dexscreener response
 * @returns {Object} Structured data for database update
 */
export function extractEnrichmentData(matchResult, options = {}) {
  if (!matchResult.pair && matchResult.status !== 'ok') {
    return null;
  }

  const pair = matchResult.topPair || matchResult.pair;
  const vol = matchResult.volume || matchResult.vol;
  const liq = matchResult.liquidity || matchResult.liq;

  const status = options.matchedFrom
    ? (options.matchedFrom === 'name_symbol' ? 'ok_name_symbol'
       : options.matchedFrom === 'exact_base' ? 'ok_exact_base'
       : 'ok_from_new_listing_match')
    : matchResult.status || 'ok';

  return {
    status,
    reason: matchResult.reason || null,
    projectName: options.projectName || pair?.baseToken?.name || pair?.baseToken?.symbol || null,
    chainId: pair?.chainId || null,
    contractAddress: pair?.baseToken?.address || options.matchedContract || null,
    pairAddress: pair?.pairAddress || null,
    pairUrl: pair?.url || null,
    baseSymbol: pair?.baseToken?.symbol || null,
    baseName: pair?.baseToken?.name || null,
    quoteSymbol: pair?.quoteToken?.symbol || null,
    quoteName: pair?.quoteToken?.name || null,
    priceUsd: pair?.priceUsd ?? null,
    priceNative: pair?.priceNative ?? null,
    fdv: typeof pair?.fdv === 'number' && Number.isFinite(pair.fdv) ? pair.fdv : null,
    marketCap: typeof pair?.marketCap === 'number' ? pair.marketCap : null,
    volumeUsd: typeof vol === 'number' ? vol : getVolumeUsd(pair?.volume),
    liquidityUsd: typeof liq === 'number' ? liq : getLiquidityUsd(pair?.liquidity),
    selectedPair: pair,
    matchedFrom: options.matchedFrom || null,
    newListingMatchId: options.newListingMatchId || null,
    matchedContract: options.matchedContract || null,
    preferredChain: options.preferredChain || null,
    checkedAt: new Date(),
    raw: options.rawData || (matchResult.pairs ? { pairs: matchResult.pairs } : { pairs: [pair] })
  };
}

/**
 * Create enrichment data for no match cases
 * @param {Object} options - No match options
 * @param {string} options.status - Status (no_match, no_match_for_new_listing_contract)
 * @param {string} options.reason - Reason for no match
 * @param {string} options.newListingMatchId - ID of matched new_listing record
 * @param {string} options.matchedContract - Contract address that was attempted
 * @param {string} options.preferredChain - Preferred chain that was used
 * @param {Object} options.rawData - Raw Dexscreener response
 * @returns {Object} Structured data for database update
 */
export function createNoMatchEnrichmentData(options = {}) {
  return {
    status: options.status || 'no_match',
    reason: options.reason || 'unknown',
    newListingMatchId: options.newListingMatchId || null,
    matchedContract: options.matchedContract || null,
    preferredChain: options.preferredChain || null,
    checkedAt: new Date(),
    raw: options.rawData || null
  };
}

/**
 * Analyze failed records to identify potential fixes
 * @param {Array} failedRecords - Records with no_match status
 * @returns {Object} Analysis results with potential fixes
 */
export function analyzeFailedMatches(failedRecords) {
  const analysis = {
    totalAnalyzed: failedRecords.length,
    byReason: {},
    detectedIssues: [],
    sampleProblems: [],
  };

  const targetReasons = ['no_exact_baseToken_match', 'thresholds_not_met_or_no_fdv'];

  // Initialize counters
  targetReasons.forEach((reason) => {
    analysis.byReason[reason] = {
      count: 0,
      shouldHaveMatched: 0,
      shouldHavePassedThresholds: 0,
      logicalErrors: [],
    };
  });

  for (const record of failedRecords) {
    const reason = record.dexscreener.reason;
    const symbol = record.symbol;
    const pairs = record.dexscreener.raw?.pairs || [];

    if (!analysis.byReason[reason]) continue;
    analysis.byReason[reason].count++;

    if (reason === 'no_exact_baseToken_match') {
      // Check if there ARE actually exact matches that were missed
      const actualExactMatches = pairs.filter((p) => isExactBaseMatch(p, symbol));

      if (actualExactMatches.length > 0) {
        analysis.byReason[reason].shouldHaveMatched++;
        analysis.byReason[reason].logicalErrors.push({
          recordId: record._id,
          symbol: symbol,
          issue: 'Found exact matches that should have been detected',
          matches: actualExactMatches.map((p) => ({
            symbol: p.baseToken.symbol,
            name: p.baseToken.name,
            address: p.baseToken.address,
            chainId: p.chainId,
          })),
        });
      }
    } else if (reason === 'thresholds_not_met_or_no_fdv') {
      // Re-run the exact matching logic to see what passed initial filters
      let exactMatches = pairs.filter((p) => isExactBaseMatch(p, symbol));

      if (exactMatches.length > 0) {
        // Apply the same logic as selectTopExactPair
        const withMetrics = exactMatches.map((p) => {
          const vol = getVolumeUsd(p.volume);
          const liq = getLiquidityUsd(p.liquidity);
          const fdv = typeof p.fdv === 'number' && Number.isFinite(p.fdv) ? p.fdv : -Infinity;
          return { p, vol, liq, fdv };
        });

        const passedThresholds = withMetrics.filter(
          (x) => x.vol > VOLUME_MIN_USD && x.liq > LIQ_MIN_USD,
        );

        if (passedThresholds.length > 0) {
          analysis.byReason[reason].shouldHavePassedThresholds++;
          const topPair = passedThresholds.sort((a, b) => b.fdv - a.fdv)[0];

          analysis.byReason[reason].logicalErrors.push({
            recordId: record._id,
            symbol: symbol,
            issue: 'Found pairs that should have passed thresholds',
            topPair: {
              symbol: topPair.p.baseToken.symbol,
              name: topPair.p.baseToken.name,
              volume: topPair.vol,
              liquidity: topPair.liq,
              fdv: topPair.fdv,
              chainId: topPair.p.chainId,
              address: topPair.p.baseToken.address,
            },
          });
        }
      }
    }
  }

  return analysis;
}

/**
 * Select pair from Dexscreener by contract address and optional matching strategies
 * Implements the sophisticated multi-stage matching from original backfill logic
 * @param {Object} data - Dexscreener API response
 * @param {Object} options - Matching options
 * @param {string} options.symbol - Token symbol
 * @param {Array} options.names - Project name candidates
 * @param {string} options.contract - Contract address
 * @param {string} options.preferredChain - Preferred blockchain
 * @returns {Object} Matching result with pair, volume, liquidity, and source
 */
export function selectPairByContract(data, { symbol, names = [], contract = '', preferredChain = '' }) {
  const pairs = Array.isArray(data?.pairs) ? data.pairs : [];
  if (!pairs.length) return { pair: null, reason: 'no_pairs' };

  const ciEq = (a, b) => String(a ?? '').toLowerCase() === String(b ?? '').toLowerCase();
  const chainLC = String(preferredChain || '').toLowerCase();

  // Step 1: Match Project Name AND Symbol with Dexscreener output
  if (symbol) {
    let candidates = pairs.filter((p) => {
      const symOk = ciEq(p?.baseToken?.symbol, symbol);
      if (!symOk) return false;
      if (!names?.length) return true;
      const nameOk = names.some((n) => ciEq(p?.baseToken?.name, n));
      return nameOk;
    });

    if (chainLC) {
      const onChain = candidates.filter((p) => ciEq(p?.chainId, preferredChain));
      if (onChain.length) candidates = onChain;
    }

    // Apply thresholds then FDV desc (vol/liquidity > 10k)
    const ranked = candidates
      .map((p) => ({
        p,
        vol: getVolumeUsd(p.volume),
        liq: getLiquidityUsd(p.liquidity),
        fdv: typeof p.fdv === 'number' && Number.isFinite(p.fdv) ? p.fdv : -Infinity,
      }))
      .filter((x) => x.vol > VOLUME_MIN_USD && x.liq > LIQ_MIN_USD)
      .sort((a, b) => b.fdv - a.fdv);

    if (ranked.length) {
      const top = ranked[0];
      return { pair: top.p, vol: top.vol, liq: top.liq, source: 'name_symbol' };
    }
  }

  // Step 2: Exact baseToken match using existing pipeline
  if (symbol) {
    const { top, vol, liq, reason } = selectTopExactPair(data, symbol, preferredChain);
    if (top) return { pair: top, vol, liq, source: 'exact_base' };
  }

  // Step 3: Fallback to contract address matching
  if (contract) {
    let candidates = pairs.filter((p) => ciEq(p?.baseToken?.address, contract));
    if (!candidates.length) return { pair: null, reason: 'no_pairs_for_contract' };

    if (chainLC) {
      const onChain = candidates.filter((p) => ciEq(p?.chainId, preferredChain));
      if (onChain.length) candidates = onChain;
    }

    // Rank by liquidity desc, then FDV desc, then volume desc
    const ranked = candidates
      .map((p) => ({
        p,
        liq: getLiquidityUsd(p.liquidity),
        fdv: typeof p.fdv === 'number' && Number.isFinite(p.fdv) ? p.fdv : -Infinity,
        vol: getVolumeUsd(p.volume),
      }))
      .sort((a, b) => b.liq - a.liq || b.fdv - a.fdv || b.vol - a.vol);

    if (ranked.length) {
      const top = ranked[0];
      return { pair: top.p, vol: top.vol, liq: top.liq, source: 'contract' };
    }
    return { pair: null, reason: 'no_ranked_candidates_for_contract' };
  }

  return { pair: null, reason: 'no_match_after_name_symbol_and_exact' };
}

/**
 * Generate fix data for a failed record
 * @param {Object} record - Failed database record
 * @returns {Object|null} Fix update object or null if can't be fixed
 */
export function generateRecordFix(record) {
  const symbol = record.symbol;
  const reason = record.dexscreener.reason;

  try {
    // Re-run the improved matching logic
    const { top, vol, liq } = selectTopExactPair(record.dexscreener.raw, symbol);

    // Check if we found exact matches but they failed thresholds
    if (!top || vol <= VOLUME_MIN_USD || liq <= LIQ_MIN_USD) {
      // If original reason was no_exact_baseToken_match but we found exact matches,
      // reclassify the failure reason to thresholds_not_met_or_no_fdv
      if (reason === 'no_exact_baseToken_match') {
        const pairs = Array.isArray(record.dexscreener.raw?.pairs) ? record.dexscreener.raw.pairs : [];
        const exactMatches = pairs.filter((p) => isExactBaseMatch(p, symbol));

        if (exactMatches.length > 0) {
          // Found exact matches but they failed thresholds - reclassify
          return {
            $set: {
              'dexscreener.status': 'no_match',
              'dexscreener.reason': 'thresholds_not_met_or_no_fdv',
              'dexscreener.reclassifiedAt': new Date(),
              'dexscreener.reclassifiedFrom': reason,
              'dexscreener.originalError': {
                status: record.dexscreener.status,
                reason: record.dexscreener.reason,
                checkedAt: record.dexscreener.checkedAt,
                note: 'Record had exact matches but they failed volume/liquidity thresholds, reason reclassified from no_exact_baseToken_match to thresholds_not_met_or_no_fdv'
              },
              'dexscreener.checkedAt': new Date()
            }
          };
        }
      }
      return null; // Can't be fixed
    }

    return {
      $set: {
        'dexscreener.status': 'ok_fixed',
        'dexscreener.reason': null,
        'dexscreener.fixedAt': new Date(),
        'dexscreener.fixedFrom': reason,
        // Preserve original error information for audit trail
        'dexscreener.originalError': {
          status: record.dexscreener.status,
          reason: record.dexscreener.reason,
          checkedAt: record.dexscreener.checkedAt,
          note: 'This record was originally missed due to case-sensitivity/whitespace issues but has been corrected'
        },
        // Current correct data
        'dexscreener.chainId': top.chainId,
        'dexscreener.contractAddress': top.baseToken?.address || null,
        'dexscreener.pairAddress': top.pairAddress || null,
        'dexscreener.pairUrl': top.url || null,
        'dexscreener.baseSymbol': top.baseToken?.symbol || null,
        'dexscreener.baseName': top.baseToken?.name || null,
        'dexscreener.quoteSymbol': top.quoteToken?.symbol || null,
        'dexscreener.quoteName': top.quoteToken?.name || null,
        'dexscreener.priceUsd': top.priceUsd ?? null,
        'dexscreener.priceNative': top.priceNative ?? null,
        'dexscreener.fdv': typeof top.fdv === 'number' && Number.isFinite(top.fdv) ? top.fdv : null,
        'dexscreener.marketCap': typeof top.marketCap === 'number' ? top.marketCap : null,
        'dexscreener.volumeUsd': vol,
        'dexscreener.liquidityUsd': liq,
        'dexscreener.selectedPair': top,
      }
    };
  } catch (error) {
    console.error(`Error generating fix for record ${record._id}:`, error.message);
    return null;
  }
}
#!/usr/bin/env node

// scripts/process-announcements.js
import mongoose from 'mongoose';
import { config } from '../src/config.js';
import { getCollection } from '../src/core/database.js';

const ENDPOINT_URL = 'http://localhost:3001/process-announcement';
const TARGET_COLLECTION = 'test_announcement_4';
const DELAY_MS = 500; // 5 seconds

/**
 * Sleep function for delays between requests
 */
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Make API call to process-announcement endpoint
 */
async function processAnnouncement(record) {
  const payload = {
    symbol: record.symbol,
    name: record.name,
    contract_address: record.contract_address,
    // Include other fields that might be useful
    _id: record._id,
    blockchain: record.blockchain,
    exchange: record.exchange,
    announced_at: record.announced_at,
    listed_at: record.listed_at,
    market_type: record.market_type,
    quote: record.quote,
    pair: record.pair,
  };

  try {
    console.log(`🔄 Processing record ${record._id}: ${record.symbol} - ${record.name}`);

    const response = await fetch(ENDPOINT_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
      timeout: 30000, // 30 second timeout
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const result = await response.json();
    console.log(
      `✅ Success: ${record.symbol} - Confidence: ${result.confidence?.percentage}% (${result.confidence?.reason})`,
    );

    return {
      success: true,
      original: record,
      processed: result,
      timestamp: new Date(),
    };
  } catch (error) {
    console.error(`❌ Error processing ${record.symbol}:`, error.message);

    return {
      success: false,
      original: record,
      error: error.message,
      timestamp: new Date(),
    };
  }
}

/**
 * Save result to target collection
 */
async function saveResult(result) {
  const targetCollection = getCollection(TARGET_COLLECTION);

  try {
    await targetCollection.replaceOne({ 'original._id': result.original._id }, result, {
      upsert: true,
    });
    console.log(`💾 Saved result for ${result.original.symbol} to ${TARGET_COLLECTION}`);
  } catch (error) {
    console.error(
      `❌ Failed to save result for ${result.original.symbol}:`,
      error.message,
    );
  }
}

/**
 * Main processing function
 */
async function processAllAnnouncements() {
  try {
    console.log('🚀 Starting announcement processing script...');
    console.log(`📡 Endpoint: ${ENDPOINT_URL}`);
    console.log(`💾 Target collection: ${TARGET_COLLECTION}`);
    console.log(`⏱️  Delay between requests: ${DELAY_MS}ms`);
    console.log('');

    // Connect to MongoDB
    console.log('📦 Connecting to MongoDB...');
    await mongoose.connect(config.mongodb.uri);
    console.log('✅ Connected to MongoDB');

    // Get announcements collection
    const announcementsCollection = getCollection('announcements');

    // Count total records
    const totalRecords = await announcementsCollection.countDocuments({});
    console.log(`📊 Found ${totalRecords} records in announcements collection`);
    console.log('');

    // Process records in batches
    let processed = 0;
    let successful = 0;
    let failed = 0;

    // Use cursor to avoid loading all records into memory
    const cursor = announcementsCollection.find({}).sort({ _id: 1 }).skip(4800);

    for await (const record of cursor) {
      try {
        // Process the record
        const result = await processAnnouncement(record);

        // Save the result
        await saveResult(result);

        // Update counters
        processed++;
        if (result.success) {
          successful++;
        } else {
          failed++;
        }

        // Progress logging
        if (processed % 10 === 0) {
          console.log(
            `\n📈 Progress: ${processed}/${totalRecords} (${Math.round(
              (processed / totalRecords) * 100,
            )}%)`,
          );
          console.log(`✅ Successful: ${successful}, ❌ Failed: ${failed}`);
          console.log('');
        }

        // Wait before next request (except for the last one)
        if (processed < totalRecords) {
          console.log(`⏳ Waiting ${DELAY_MS}ms before next request...`);
          await sleep(DELAY_MS);
        }
      } catch (error) {
        console.error(`💥 Unexpected error processing record ${record._id}:`, error);
        failed++;
        processed++;
      }
    }

    // Final summary
    console.log('\n🎉 Processing complete!');
    console.log('='.repeat(50));
    console.log(`📊 Total processed: ${processed}`);
    console.log(`✅ Successful: ${successful}`);
    console.log(`❌ Failed: ${failed}`);
    console.log(`📈 Success rate: ${Math.round((successful / processed) * 100)}%`);
    console.log(`💾 Results saved to: ${TARGET_COLLECTION}`);
    console.log('='.repeat(50));
  } catch (error) {
    console.error('💥 Script failed:', error);
    process.exit(1);
  } finally {
    // Close MongoDB connection
    await mongoose.disconnect();
    console.log('👋 Disconnected from MongoDB');
    process.exit(0);
  }
}

// Handle script interruption
process.on('SIGINT', async () => {
  console.log('\n⚠️  Script interrupted by user');
  await mongoose.disconnect();
  process.exit(0);
});

// Start the script
processAllAnnouncements();

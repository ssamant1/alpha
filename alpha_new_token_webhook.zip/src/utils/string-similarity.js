// src/utils/string-similarity.js
import levenshtein from 'js-levenshtein-esm';

/**
 * String similarity utility using Levenshtein distance
 * Provides fuzzy string matching capabilities for project name comparison
 */

/**
 * Calculate similarity score between two strings using Levenshtein distance
 * @param {string} str1 - First string to compare
 * @param {string} str2 - Second string to compare
 * @param {Object} options - Options for comparison
 * @param {boolean} options.caseSensitive - Whether comparison should be case-sensitive (default: false)
 * @param {boolean} options.trimWhitespace - Whether to trim whitespace before comparison (default: true)
 * @param {boolean} options.normalizeSpaces - Whether to normalize multiple spaces to single space (default: true)
 * @returns {number} Similarity score between 0.0 (no similarity) and 1.0 (identical)
 */
export function calculateSimilarity(str1, str2, options = {}) {
  // Set default options
  const {
    caseSensitive = false,
    trimWhitespace = true,
    normalizeSpaces = true
  } = options;

  // Input validation
  if (typeof str1 !== 'string' || typeof str2 !== 'string') {
    return 0.0;
  }

  // Handle empty strings
  if (str1.length === 0 && str2.length === 0) {
    return 1.0;
  }
  if (str1.length === 0 || str2.length === 0) {
    return 0.0;
  }

  // Normalize strings based on options
  let normalizedStr1 = str1;
  let normalizedStr2 = str2;

  if (trimWhitespace) {
    normalizedStr1 = normalizedStr1.trim();
    normalizedStr2 = normalizedStr2.trim();
  }

  if (normalizeSpaces) {
    // Replace multiple consecutive spaces with single space
    normalizedStr1 = normalizedStr1.replace(/\s+/g, ' ');
    normalizedStr2 = normalizedStr2.replace(/\s+/g, ' ');
  }

  if (!caseSensitive) {
    normalizedStr1 = normalizedStr1.toLowerCase();
    normalizedStr2 = normalizedStr2.toLowerCase();
  }

  // Handle identical strings after normalization
  if (normalizedStr1 === normalizedStr2) {
    return 1.0;
  }

  // Calculate Levenshtein distance
  const distance = levenshtein(normalizedStr1, normalizedStr2);
  const maxLength = Math.max(normalizedStr1.length, normalizedStr2.length);

  // Convert distance to similarity score (0.0 to 1.0)
  const similarity = 1.0 - (distance / maxLength);

  return Math.max(0.0, similarity); // Ensure non-negative result
}

/**
 * Check if two strings are similar based on a threshold
 * @param {string} str1 - First string to compare
 * @param {string} str2 - Second string to compare
 * @param {number} threshold - Minimum similarity score (0.0 to 1.0) to consider strings similar
 * @param {Object} options - Options for comparison (same as calculateSimilarity)
 * @returns {boolean} True if strings are similar above threshold
 */
export function isSimilar(str1, str2, threshold = 0.8, options = {}) {
  const similarity = calculateSimilarity(str1, str2, options);
  return similarity >= threshold;
}

/**
 * Find the most similar string from an array of candidates
 * @param {string} target - Target string to match against
 * @param {Array<string>} candidates - Array of candidate strings
 * @param {Object} options - Options for comparison
 * @param {number} options.threshold - Minimum similarity score to consider a match (default: 0.0)
 * @param {boolean} options.caseSensitive - Whether comparison should be case-sensitive (default: false)
 * @param {boolean} options.trimWhitespace - Whether to trim whitespace (default: true)
 * @param {boolean} options.normalizeSpaces - Whether to normalize spaces (default: true)
 * @returns {Object|null} Best match object with { text, similarity, index } or null if no match above threshold
 */
export function findBestMatch(target, candidates, options = {}) {
  const { threshold = 0.0, ...similarityOptions } = options;

  if (!Array.isArray(candidates) || candidates.length === 0) {
    return null;
  }

  let bestMatch = null;
  let highestSimilarity = threshold;

  candidates.forEach((candidate, index) => {
    if (typeof candidate === 'string') {
      const similarity = calculateSimilarity(target, candidate, similarityOptions);

      if (similarity > highestSimilarity) {
        highestSimilarity = similarity;
        bestMatch = {
          text: candidate,
          similarity: similarity,
          index: index
        };
      }
    }
  });

  return bestMatch;
}

/**
 * Find all similar strings from an array of candidates above a threshold
 * @param {string} target - Target string to match against
 * @param {Array<string>} candidates - Array of candidate strings
 * @param {Object} options - Options for comparison
 * @param {number} options.threshold - Minimum similarity score (default: 0.8)
 * @param {boolean} options.caseSensitive - Whether comparison should be case-sensitive (default: false)
 * @param {boolean} options.trimWhitespace - Whether to trim whitespace (default: true)
 * @param {boolean} options.normalizeSpaces - Whether to normalize spaces (default: true)
 * @param {boolean} options.sortByScore - Whether to sort results by similarity score descending (default: true)
 * @returns {Array<Object>} Array of match objects with { text, similarity, index }
 */
export function findSimilarStrings(target, candidates, options = {}) {
  const {
    threshold = 0.8,
    sortByScore = true,
    ...similarityOptions
  } = options;

  if (!Array.isArray(candidates) || candidates.length === 0) {
    return [];
  }

  const matches = [];

  candidates.forEach((candidate, index) => {
    if (typeof candidate === 'string') {
      const similarity = calculateSimilarity(target, candidate, similarityOptions);

      if (similarity >= threshold) {
        matches.push({
          text: candidate,
          similarity: similarity,
          index: index
        });
      }
    }
  });

  if (sortByScore) {
    matches.sort((a, b) => b.similarity - a.similarity);
  }

  return matches;
}

/**
 * Get similarity statistics for debugging purposes
 * @param {string} str1 - First string
 * @param {string} str2 - Second string
 * @param {Object} options - Options for comparison
 * @returns {Object} Detailed comparison statistics
 */
export function getSimilarityStats(str1, str2, options = {}) {
  const {
    caseSensitive = false,
    trimWhitespace = true,
    normalizeSpaces = true
  } = options;

  // Original strings
  const original = { str1, str2 };

  // Normalized strings
  let normalized1 = str1;
  let normalized2 = str2;

  if (trimWhitespace) {
    normalized1 = normalized1.trim();
    normalized2 = normalized2.trim();
  }

  if (normalizeSpaces) {
    normalized1 = normalized1.replace(/\s+/g, ' ');
    normalized2 = normalized2.replace(/\s+/g, ' ');
  }

  if (!caseSensitive) {
    normalized1 = normalized1.toLowerCase();
    normalized2 = normalized2.toLowerCase();
  }

  const normalized = { str1: normalized1, str2: normalized2 };

  // Calculate metrics
  const distance = levenshtein(normalized1, normalized2);
  const maxLength = Math.max(normalized1.length, normalized2.length);
  const similarity = calculateSimilarity(str1, str2, options);

  return {
    original,
    normalized,
    distance,
    maxLength,
    similarity,
    identical: normalized1 === normalized2,
    options
  };
}
// src/core/database.js
import mongoose from 'mongoose';

/**
 * Database operations for token records
 * Handles all MongoDB queries and updates
 */

/**
 * Get database collection
 * @param {string} collectionName - Name of the collection
 * @returns {Object} MongoDB collection instance
 */
export function getCollection(collectionName) {
  return mongoose.connection.db.collection(collectionName);
}

/**
 * Update a record with dexscreener enrichment data
 * @param {string} collectionName - Collection name
 * @param {Object} recordId - MongoDB ObjectId
 * @param {Object} enrichmentData - Data to update
 * @returns {Promise<Object>} Update result
 */
export async function updateRecordWithEnrichment(collectionName, recordId, enrichmentData) {
  const collection = getCollection(collectionName);

  const updateDoc = {
    $set: {
      dexscreener: {
        ...enrichmentData,
        checkedAt: new Date(),
      },
    },
  };

  return await collection.updateOne({ _id: recordId }, updateDoc);
}

/**
 * Find failed records that might be fixable
 * @param {string} collectionName - Collection name
 * @param {Array} targetStatuses - Array of status reasons to search for
 * @returns {Promise<Array>} Array of failed records
 */
export async function findFailedRecords(collectionName, targetStatuses = ['no_exact_baseToken_match', 'thresholds_not_met_or_no_fdv']) {
  const collection = getCollection(collectionName);

  return await collection
    .find({
      'dexscreener.status': 'no_match',
      'dexscreener.reason': { $in: targetStatuses },
    })
    .toArray();
}

/**
 * Apply a fix update to a specific record
 * @param {string} collectionName - Collection name
 * @param {Object} recordId - MongoDB ObjectId
 * @param {Object} fixUpdate - MongoDB update object
 * @returns {Promise<Object>} Update result
 */
export async function applyRecordFix(collectionName, recordId, fixUpdate) {
  const collection = getCollection(collectionName);
  return await collection.updateOne({ _id: recordId }, fixUpdate);
}

/**
 * Get matching statistics for analysis
 * @param {string} collectionName - Collection name
 * @returns {Promise<Object>} Statistics object
 */
export async function getMatchingStatistics(collectionName) {
  const collection = getCollection(collectionName);

  const pipeline = [
    {
      $group: {
        _id: '$dexscreener.status',
        count: { $sum: 1 },
        reasons: { $push: '$dexscreener.reason' }
      }
    }
  ];

  const results = await collection.aggregate(pipeline).toArray();

  // Transform results into a more usable format
  const stats = {
    total: 0,
    byStatus: {},
    byReason: {}
  };

  for (const result of results) {
    const status = result._id || 'unknown';
    const count = result.count;

    stats.total += count;
    stats.byStatus[status] = count;

    // Count reasons
    for (const reason of result.reasons) {
      if (reason) {
        stats.byReason[reason] = (stats.byReason[reason] || 0) + 1;
      }
    }
  }

  return stats;
}

/**
 * Count records by query
 * @param {string} collectionName - Collection name
 * @param {Object} query - MongoDB query object
 * @returns {Promise<number>} Count of matching records
 */
export async function countRecords(collectionName, query = {}) {
  const collection = getCollection(collectionName);
  return await collection.countDocuments(query);
}

/**
 * Find records with pagination
 * @param {string} collectionName - Collection name
 * @param {Object} query - MongoDB query object
 * @param {Object} options - Options with limit, offset, sort
 * @returns {Promise<Array>} Array of records
 */
export async function findRecords(collectionName, query = {}, options = {}) {
  const collection = getCollection(collectionName);
  const { limit = 100, offset = 0, sort = {} } = options;

  return await collection
    .find(query)
    .sort(sort)
    .skip(offset)
    .limit(limit)
    .toArray();
}

/**
 * Check if record already has blockchain and contract data
 * @param {Object} record - Database record
 * @returns {boolean} True if record is already complete
 */
export function isRecordComplete(record) {
  // This uses the existing hasBlockchainAndContract logic
  const chain = record?.blockchain || record?.chainId || record?.chain || record?.network || '';
  const contract = record?.contract_address || record?.contractAddress || record?.token_address || record?.baseToken?.address || '';
  const evmLike = /^0x[a-fA-F0-9]{40}$/.test(contract);
  return Boolean(chain && (evmLike || contract.length > 0));
}
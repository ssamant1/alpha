// src/index.js
import express from 'express';
import mongoose from 'mongoose';
import { config } from './config.js';
import { startChangeStreamMonitoring, setupShutdownHandlers } from './core/handlers.js';
import { searchDexscreener } from './services/dexscreener.js';
import { getCollection } from './core/database.js';
import AlphaProjectMatcher from './services/matcher.js';
import endpointsRouter from './routes/endpoints.js';
import { applyFinancialFilterSingle } from './services/enhanced-matching.js';

const app = express();
app.use(express.json());

// Use the endpoints router for all other endpoints
app.use('/', endpointsRouter);

/**
 * Process announcement with DEXScreener integration
 * POST /process-announcement
 * Expects announcement document with contract_address, symbol, name fields
 */
app.post('/process-announcement', async (req, res) => {
  try {
    const announcement = req.body;
    const { contract_address, symbol, name } = announcement;

    console.log(
      `🔄 Processing announcement: ${symbol} (${contract_address || 'no contract'})`,
    );

    // Calculate confidence based on available data
    let confidence = 0;
    let confidenceReason = '';
    let matchSource = null;
    let matchedProjectName = name; // Default to input name

    if (contract_address) {
      confidence = 100;
      confidenceReason = 'Contract address provided in announcement';
      matchSource = 'direct_contract';
    } else if (symbol && name) {
      // Try to find exact matches in new_listings collection
      try {
        const newListingsCollection = getCollection('new_listings');

        // Search for all records matching the symbol (regardless of name)
        const symbolMatches = await newListingsCollection
          .find({
            symbol: { $regex: new RegExp(`^${symbol}$`, 'i') },
          })
          .toArray();

        console.log(
          `🔍 Found ${symbolMatches.length} records with symbol ${symbol} in new_listings`,
        );

        if (symbolMatches.length > 0) {
          // Filter for dates after 2024-12-26 01:47:20 UTC
          const cutoffDate = '2024-12-26 01:47:20 UTC';
          const filteredMatches = symbolMatches.filter((match) => {
            if (!match.listed_at) return false;
            return match.listed_at > cutoffDate;
          });

          console.log(`📅 Found ${filteredMatches.length} records after ${cutoffDate}`);

          // Count occurrences of each project name
          const nameCount = {};
          filteredMatches.forEach((match) => {
            const projectName = match.name;
            if (projectName) {
              nameCount[projectName] = (nameCount[projectName] || 0) + 1;
            }
          });

          // Find the most commonly used project name
          let mostCommonName = '';
          let highestCount = 0;
          for (const [name, count] of Object.entries(nameCount)) {
            if (count > highestCount) {
              highestCount = count;
              mostCommonName = name;
            }
          }

          console.log(
            `📊 Most common project name for ${symbol}: "${mostCommonName}" (${highestCount} occurrences)`,
          );
          console.log(`📋 All name occurrences:`, nameCount);

          // Get all records with the most common name (case-insensitive)
          const commonNameRecords = filteredMatches.filter(
            (match) =>
              match.name && match.name.toLowerCase() === mostCommonName.toLowerCase(),
          );

          // Sort by listed_at (latest first)
          const sortedRecords = commonNameRecords.sort((a, b) => {
            const dateA = a.listed_at || '';
            const dateB = b.listed_at || '';
            return dateB.localeCompare(dateA);
          });

          // Get all records with valid contract addresses
          const recordsWithContracts = sortedRecords.filter((match) => {
            const contractAddr =
              match.contract_address ||
              match['contract address'] ||
              match.contractAddress ||
              match.Contract_Address ||
              match['Contract Address'];
            return contractAddr && contractAddr.trim() !== '';
          });

          if (recordsWithContracts.length > 0) {
            let bestMatch = null;

            if (recordsWithContracts.length === 1) {
              // Only one contract, use it directly
              bestMatch = recordsWithContracts[0];
              console.log(`📋 Found single contract for "${mostCommonName}"`);
            } else {
              // Multiple contracts found, compare financials
              console.log(
                `📊 Found ${recordsWithContracts.length} contracts for "${mostCommonName}", comparing financials...`,
              );

              let bestFinancialScore = -1;

              for (const record of recordsWithContracts) {
                const contractAddr =
                  record.contract_address ||
                  record['contract address'] ||
                  record.contractAddress ||
                  record.Contract_Address ||
                  record['Contract Address'];

                try {
                  const dexData = await searchDexscreener(contractAddr);
                  // console.log(`+++++++ DEX screener data:`, dexData);

                  if (dexData && dexData.pairs && dexData.pairs.length > 0) {
                    const topPairs = applyFinancialFilterSingle(dexData.pairs);

                    console.log('+++++++++ response of top pairs', topPairs[0]);
                    const bestPair = topPairs[0];
                    const marketCap = bestPair.marketCap || 0;
                    const liquidity = bestPair.liquidity?.usd || 0;
                    const volume = bestPair.volume?.h24 || 0;

                    // Calculate financial score (market cap + liquidity + volume)
                    const financialScore = marketCap + liquidity + volume;

                    console.log(
                      `📈 ${contractAddr}: MC=${marketCap}, Liq=${liquidity}, Vol=${volume}, Score=${financialScore}`,
                    );

                    bestFinancialScore = financialScore;
                    bestMatch = record;
                    bestMatch.blockchain = bestPair?.chainId;
                    console.log(
                      `🏆 New best contract: ${contractAddr} (Score: ${financialScore})`,
                    );
                  } else {
                    console.log(`⚠️ No DEXScreener data for: ${contractAddr}`);
                  }
                } catch (error) {
                  console.error(
                    `❌ Failed to get financials for ${contractAddr}:`,
                    error.message,
                  );
                }
              }

              if (!bestMatch) {
                // If no financial data found, fall back to latest record
                bestMatch = recordsWithContracts[0];
                console.log(`⚠️ No financial data found, using latest record`);
              }
            }

            if (bestMatch) {
              // Get the actual contract address from whichever field has it
              const contractAddr =
                bestMatch.contract_address ||
                bestMatch['contract address'] ||
                bestMatch.contractAddress ||
                bestMatch.Contract_Address ||
                bestMatch['Contract Address'];

              confidence = 90;
              confidenceReason =
                'Symbol matches and using most common project name with best financials from token listings';
              matchSource = 'new_listings_best_financials';
              announcement.contract_address = contractAddr;
              announcement.blockchain = bestMatch.blockchain;
              matchedProjectName = mostCommonName; // Use the most common name
              console.log(
                `✅ Selected best contract for "${mostCommonName}": ${contractAddr}`,
              );
            }
          } else {
            // No contract address found in records with most common name
            // Update the name to use for DEXScreener matching
            matchedProjectName = mostCommonName;
            console.log(
              `⚠️ Found most common name "${mostCommonName}" but no contract addresses, will use this name for DEXScreener matching`,
            );
          }
        } else {
          console.log(`❌ No matches found in new_listings for symbol ${symbol}`);
        }
      } catch (error) {
        console.warn('New listings exact match failed:', error.message);
      }

      // If no exact match in new_listings, try DEXScreener search with symbol
      if (confidence === 0) {
        try {
          console.log(`🔍 Searching DEXScreener for symbol: ${symbol}`);
          const dexData = await searchDexscreener(symbol);

          if (dexData && dexData.pairs && dexData.pairs.length > 0) {
            console.log(
              `📊 DEXScreener found ${dexData.pairs.length} pairs for ${symbol}`,
            );

            // Use AlphaProjectMatcher to find the best match
            const matcher = new AlphaProjectMatcher();
            const bestMatch = matcher.findBestAlphaProject(announcement, dexData.pairs);

            if (bestMatch) {
              console.log(
                `🎯 Best match found: ${
                  bestMatch.tokenName
                } (${bestMatch.nameMatchPercentage.toFixed(1)}% name match)`,
              );

              // Determine confidence based on name match quality
              if (bestMatch.nameMatchPercentage >= 80) {
                confidence = 75;
                confidenceReason = 'Project name and symbol match exactly to DEXScreener';
                matchSource = 'dexscreener_name_symbol';
              } else {
                confidence = 50;
                confidenceReason = 'Only symbol matches in DEXScreener';
                matchSource = 'dexscreener_symbol_only';
              }

              announcement.contract_address = bestMatch.pair.baseToken.address;
              announcement.blockchain = bestMatch.pair.chainId; // Extract blockchain from DEXScreener
              matchedProjectName = bestMatch.tokenName; // Use the name from DEXScreener match
              announcement.dexscreener_match = bestMatch;
            } else {
              console.log(
                `❌ No viable matches found for ${symbol} (failed financial criteria)`,
              );
            }
          } else {
            console.log(`❌ No pairs found on DEXScreener for ${symbol}`);
          }
        } catch (error) {
          console.warn('DEXScreener search failed:', error.message);
        }
      }
    }

    const statusFields = {
      hasContractAddress: !!announcement.contract_address,
      hasSymbol: !!symbol,
      hasName: !!name,
      hasBlockchain: !!announcement.blockchain,
      matchSource,
    };

    // Always get financial data from DEXScreener if we have contract address
    let financials = {};
    let dexScreenerLink = null;
    let dexScreenerPairs = 0;

    if (announcement.contract_address) {
      try {
        console.log(
          `💰 Getting financial data from DEXScreener for: ${announcement.contract_address}`,
        );
        const dexFinancialData = await searchDexscreener(announcement.contract_address);

        if (
          dexFinancialData &&
          dexFinancialData.pairs &&
          dexFinancialData.pairs.length > 0
        ) {
          const bestPair = dexFinancialData.pairs[0];
          dexScreenerPairs = dexFinancialData.pairs.length;

          financials = {
            marketCap: bestPair.marketCap || null,
            liquidity: bestPair.liquidity?.usd || null,
            volume: bestPair.volume?.h24 || null,
            price: bestPair.priceUsd || null,
            priceChange24h: bestPair.priceChange?.h24 || null,
          };

          dexScreenerLink = `https://dexscreener.com/${bestPair.chainId}/${bestPair.pairAddress}`;
          console.log(
            `✅ Financial data retrieved: MC=${financials.marketCap}, Liq=${financials.liquidity}`,
          );
        } else {
          console.log(
            `⚠️ No financial pairs found for contract: ${announcement.contract_address}`,
          );
        }
      } catch (error) {
        console.error(`❌ DEXScreener financial data error:`, error.message);
      }
    }

    const response = {
      ok: true,
      timestamp: new Date().toISOString(),
      input: {
        id: announcement._id,
        symbol,
        name,
        originalContractAddress: contract_address,
        blockchain: announcement.blockchain,
        exchange: announcement.exchange,
      },
      status: statusFields,
      confidence: {
        percentage: confidence,
        reason: confidenceReason,
      },
      financials: {
        dexScreenerLink,
        marketCap: financials.marketCap,
        liquidity: financials.liquidity,
        volume: financials.volume,
      },
      result: {
        contractAddress: announcement.contract_address,
        blockchain: announcement.blockchain,
        projectName: matchedProjectName,
        hasFinancialData: !!(
          financials.marketCap ||
          financials.liquidity ||
          financials.volume
        ),
        dexScreenerPairs,
      },
    };

    res.json(response);
  } catch (error) {
    console.error('Process announcement endpoint error:', error);
    res.status(500).json({
      ok: false,
      error: error.message,
    });
  }
});

/**
 * Process new_listing with DEXScreener integration
 * POST /process-new-listing
 * Expects new_listing document with contract_address, symbol, name fields
 * Additional logic: searches announcements collection if not found in new_listings
 */
app.post('/process-new-listing', async (req, res) => {
  try {
    const newListing = req.body;
    const { contract_address, symbol, name } = newListing;

    console.log(
      `🔄 Processing new listing: ${symbol} (${contract_address || 'no contract'})`,
    );

    // Calculate confidence based on available data
    let confidence = 0;
    let confidenceReason = '';
    let matchSource = null;

    if (contract_address) {
      confidence = 100;
      confidenceReason = 'Contract address provided in new listing';
      matchSource = 'direct_contract';
    } else if (symbol && name) {
      // Try to find matches in new_listings collection based on symbol first
      try {
        const newListingsCollection = getCollection('new_listings');

        // Search for all records matching the symbol (regardless of name)
        const symbolMatches = await newListingsCollection
          .find({
            symbol: { $regex: new RegExp(`^${symbol}$`, 'i') },
          })
          .toArray();

        console.log(
          `🔍 Found ${symbolMatches.length} records with symbol ${symbol} in new_listings`,
        );

        if (symbolMatches.length > 0) {
          // Filter for dates after 2024-12-26 01:47:20 UTC
          const cutoffDate = '2024-12-26 01:47:20 UTC';
          const filteredMatches = symbolMatches.filter((match) => {
            if (!match.listed_at) return false;
            return match.listed_at > cutoffDate;
          });

          console.log(`📅 Found ${filteredMatches.length} records after ${cutoffDate}`);

          // Count occurrences of each project name
          const nameCount = {};
          filteredMatches.forEach((match) => {
            const projectName = match.name;
            if (projectName) {
              nameCount[projectName] = (nameCount[projectName] || 0) + 1;
            }
          });

          // Find the most commonly used project name
          let mostCommonName = '';
          let highestCount = 0;
          for (const [name, count] of Object.entries(nameCount)) {
            if (count > highestCount) {
              highestCount = count;
              mostCommonName = name;
            }
          }

          console.log(
            `📊 Most common project name for ${symbol}: "${mostCommonName}" (${highestCount} occurrences)`,
          );
          console.log(`📋 All name occurrences:`, nameCount);

          // Get all records with the most common name (case-insensitive)
          const commonNameRecords = filteredMatches.filter(
            (match) =>
              match.name && match.name.toLowerCase() === mostCommonName.toLowerCase(),
          );

          // Sort by listed_at (latest first)
          const sortedRecords = commonNameRecords.sort((a, b) => {
            const dateA = a.listed_at || '';
            const dateB = b.listed_at || '';
            return dateB.localeCompare(dateA);
          });

          // Get all records with valid contract addresses
          const recordsWithContracts = sortedRecords.filter((match) => {
            const contractAddr =
              match.contract_address ||
              match['contract address'] ||
              match.contractAddress ||
              match.Contract_Address ||
              match['Contract Address'];
            return contractAddr && contractAddr.trim() !== '';
          });

          if (recordsWithContracts.length > 0) {
            let bestMatch = null;

            if (recordsWithContracts.length === 1) {
              // Only one contract, use it directly
              bestMatch = recordsWithContracts[0];
              console.log(`📋 Found single contract for "${mostCommonName}"`);
            } else {
              // Multiple contracts found, compare financials
              console.log(
                `📊 Found ${recordsWithContracts.length} contracts for "${mostCommonName}", comparing financials...`,
              );

              let bestFinancialScore = -1;

              for (const record of recordsWithContracts) {
                const contractAddr =
                  record.contract_address ||
                  record['contract address'] ||
                  record.contractAddress ||
                  record.Contract_Address ||
                  record['Contract Address'];

                try {
                  console.log(`💰 Getting financials for: ${contractAddr}`);
                  const dexData = await searchDexscreener(contractAddr);

                  if (dexData && dexData.pairs && dexData.pairs.length > 0) {
                    const bestPair = dexData.pairs[0];
                    const marketCap = bestPair.marketCap || 0;
                    const liquidity = bestPair.liquidity?.usd || 0;
                    const volume = bestPair.volume?.h24 || 0;

                    // Calculate financial score (market cap + liquidity + volume)
                    const financialScore = marketCap + liquidity + volume;

                    console.log(
                      `📈 ${contractAddr}: MC=${marketCap}, Liq=${liquidity}, Vol=${volume}, Score=${financialScore}`,
                    );

                    if (financialScore > bestFinancialScore) {
                      bestFinancialScore = financialScore;
                      bestMatch = record;
                      console.log(
                        `🏆 New best contract: ${contractAddr} (Score: ${financialScore})`,
                      );
                    }
                  } else {
                    console.log(`⚠️ No DEXScreener data for: ${contractAddr}`);
                  }
                } catch (error) {
                  console.error(
                    `❌ Failed to get financials for ${contractAddr}:`,
                    error.message,
                  );
                }
              }

              if (!bestMatch) {
                // If no financial data found, fall back to latest record
                bestMatch = recordsWithContracts[0];
                console.log(`⚠️ No financial data found, using latest record`);
              }
            }

            if (bestMatch) {
              // Check for various contract address field names
              const contractAddr =
                bestMatch.contract_address ||
                bestMatch['contract address'] ||
                bestMatch.contractAddress ||
                bestMatch.Contract_Address ||
                bestMatch['Contract Address'];

              confidence = 90;
              confidenceReason =
                'Symbol matches and using most common project name with best financials from new listings';
              matchSource = 'new_listings_best_financials';
              newListing.contract_address = contractAddr;
              newListing.blockchain = bestMatch.blockchain;
              console.log(
                `✅ Selected best contract for "${mostCommonName}": ${contractAddr}`,
              );
            }
          } else {
            // No contract address found in records with most common name
            console.log(
              `⚠️ Found most common name "${mostCommonName}" but no contract addresses, continuing search`,
            );
          }
        } else {
          console.log(`❌ No matches found in new_listings for symbol ${symbol}`);
        }
      } catch (error) {
        console.warn('New listings exact match failed:', error.message);
      }

      // If no exact match in new_listings, try announcements collection
      if (confidence === 0) {
        try {
          console.log(
            `🔍 Searching announcements collection for symbol: ${symbol} and name: ${name}`,
          );
          const announcementsCollection = getCollection('announcements');

          // Search for exact match on symbol and name (case-insensitive)
          const announcementMatch = await announcementsCollection.findOne({
            symbol: { $regex: new RegExp(`^${symbol}$`, 'i') },
            name: { $regex: new RegExp(`^${name}$`, 'i') },
            contract_address: { $exists: true, $ne: null, $ne: '' },
          });

          if (announcementMatch) {
            // Check for various contract address field names
            const contractAddr =
              announcementMatch.contract_address ||
              announcementMatch['contract address'] ||
              announcementMatch.contractAddress ||
              announcementMatch.Contract_Address ||
              announcementMatch['Contract Address'];

            if (contractAddr && contractAddr.trim() !== '') {
              confidence = 90;
              confidenceReason = 'Project name and symbol match exactly to announcements';
              matchSource = 'announcements_exact';
              newListing.contract_address = contractAddr;
              newListing.blockchain = announcementMatch.blockchain; // Extract blockchain from database
              console.log(
                `✅ Found exact match in announcements with contract: ${contractAddr}`,
              );
            } else {
              console.log(
                `⚠️ Found exact match in announcements but no contract address, falling back to DEXScreener`,
              );
              // Will fall through to DEXScreener search below
            }
          } else {
            console.log(`❌ No exact match found in announcements collection`);
          }
        } catch (error) {
          console.warn('Announcements exact match failed:', error.message);
        }
      }

      // If no exact match in both collections, try DEXScreener search with symbol
      if (confidence === 0) {
        try {
          console.log(`🔍 Searching DEXScreener for symbol: ${symbol}`);
          const dexData = await searchDexscreener(symbol);

          if (dexData && dexData.pairs && dexData.pairs.length > 0) {
            console.log(
              `📊 DEXScreener found ${dexData.pairs.length} pairs for ${symbol}`,
            );

            // Use AlphaProjectMatcher to find the best match
            const matcher = new AlphaProjectMatcher();
            const bestMatch = matcher.findBestAlphaProject(newListing, dexData.pairs);

            if (bestMatch) {
              console.log(
                `🎯 Best match found: ${
                  bestMatch.tokenName
                } (${bestMatch.nameMatchPercentage.toFixed(1)}% name match)`,
              );

              // Determine confidence based on name match quality
              if (bestMatch.nameMatchPercentage >= 80) {
                confidence = 75;
                confidenceReason = 'Project name and symbol match exactly to DEXScreener';
                matchSource = 'dexscreener_name_symbol';
              } else {
                confidence = 50;
                confidenceReason = 'Only symbol matches in DEXScreener';
                matchSource = 'dexscreener_symbol_only';
              }

              newListing.contract_address = bestMatch.pair.baseToken.address;
              newListing.blockchain = bestMatch.pair.chainId; // Extract blockchain from DEXScreener
              newListing.dexscreener_match = bestMatch;
            } else {
              console.log(
                `❌ No viable matches found for ${symbol} (failed financial criteria)`,
              );
            }
          } else {
            console.log(`❌ No pairs found on DEXScreener for ${symbol}`);
          }
        } catch (error) {
          console.warn('DEXScreener search failed:', error.message);
        }
      }
    }

    const statusFields = {
      hasContractAddress: !!newListing.contract_address,
      hasSymbol: !!symbol,
      hasName: !!name,
      hasBlockchain: !!newListing.blockchain,
      matchSource,
    };

    // Always get financial data from DEXScreener if we have contract address
    let financials = {};
    let dexScreenerLink = null;
    let dexScreenerPairs = 0;

    if (newListing.contract_address) {
      try {
        console.log(
          `💰 Getting financial data from DEXScreener for: ${newListing.contract_address}`,
        );
        const dexFinancialData = await searchDexscreener(newListing.contract_address);

        if (
          dexFinancialData &&
          dexFinancialData.pairs &&
          dexFinancialData.pairs.length > 0
        ) {
          const bestPair = dexFinancialData.pairs[0];
          dexScreenerPairs = dexFinancialData.pairs.length;

          financials = {
            marketCap: bestPair.marketCap || null,
            liquidity: bestPair.liquidity?.usd || null,
            volume: bestPair.volume?.h24 || null,
            price: bestPair.priceUsd || null,
            priceChange24h: bestPair.priceChange?.h24 || null,
          };

          dexScreenerLink = `https://dexscreener.com/${bestPair.chainId}/${bestPair.pairAddress}`;
          console.log(
            `✅ Financial data retrieved: MC=${financials.marketCap}, Liq=${financials.liquidity}`,
          );
        } else {
          console.log(
            `⚠️ No financial pairs found for contract: ${newListing.contract_address}`,
          );
        }
      } catch (error) {
        console.error(`❌ DEXScreener financial data error:`, error.message);
      }
    }

    const response = {
      ok: true,
      timestamp: new Date().toISOString(),
      input: {
        id: newListing._id,
        symbol,
        name,
        originalContractAddress: contract_address,
        blockchain: newListing.blockchain,
        exchange: newListing.exchange,
      },
      status: statusFields,
      confidence: {
        percentage: confidence,
        reason: confidenceReason,
      },
      financials: {
        dexScreenerLink,
        marketCap: financials.marketCap,
        liquidity: financials.liquidity,
        volume: financials.volume,
      },
      result: {
        contractAddress: newListing.contract_address,
        blockchain: newListing.blockchain,
        hasFinancialData: !!(
          financials.marketCap ||
          financials.liquidity ||
          financials.volume
        ),
        dexScreenerPairs,
      },
    };

    res.json(response);
  } catch (error) {
    console.error('Process new listing endpoint error:', error);
    res.status(500).json({
      ok: false,
      error: error.message,
    });
  }
});

/**
 * Initialize and start the server
 */
async function startServer() {
  try {
    // Connect to MongoDB
    console.log('Connecting to MongoDB...');
    await mongoose.connect(config.mongodb.uri);
    console.log('Connected to MongoDB successfully');

    // Start change stream monitoring
    // await startChangeStreamMonitoring();

    // Setup graceful shutdown
    setupShutdownHandlers();

    // Start Express server
    app.listen(config.server.port, () => {
      console.log(`🚀 Server running on port ${config.server.port}`);
      console.log(`📊 Monitoring collections: ${config.collections.targets.join(', ')}`);
      console.log(
        `🔄 Process announcement endpoint: http://localhost:${config.server.port}/process-announcement`,
      );
      console.log(
        `🆕 Process new listing endpoint: http://localhost:${config.server.port}/process-new-listing`,
      );
      console.log(
        `🔍 Debug endpoint: http://localhost:${config.server.port}/debug/failed-matches`,
      );
      console.log(
        `📈 Analysis endpoint: http://localhost:${config.server.port}/analyze/matching`,
      );
      console.log(
        `🔄 Backfill endpoint: http://localhost:${config.server.port}/backfill/announcements`,
      );
      console.log(
        `🧪 Enhanced matching test: http://localhost:${config.server.port}/test/enhanced-matching`,
      );
      console.log(
        `🎯 Single record backfill test: http://localhost:${config.server.port}/test/backfill-record`,
      );
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the application
startServer();

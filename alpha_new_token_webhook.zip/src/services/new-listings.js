// src/services/new-listings.js
import { getCollection } from '../core/database.js';
import { calculateSimilarity, findBestMatch } from '../utils/string-similarity.js';

/**
 * New listings cross-collection matching service
 * Handles matching announcements with new_listings for contract pre-matching
 */

/**
 * Escape special regex characters
 */
function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Extract name candidates from document
 */
export function pickNameCandidates(doc) {
  const vals = [doc?.name, doc?.Project_name, doc?.project_name, doc?.title].filter(
    (x) => typeof x === 'string' && x.trim(),
  );
  return [...new Set(vals.map((v) => v.trim()))];
}

/**
 * Extract project name from a document (handles different field structures)
 * @param {Object} doc - Document from announcements or new_listings
 * @returns {string|null} Main project name or null if not found
 */
export function extractProjectName(doc) {
  // Handle different name field structures
  let name = doc?.name || doc?.Project_name || doc?.project_name || doc?.title;

  if (typeof name !== 'string' || !name.trim()) {
    return null;
  }

  name = name.trim();

  // For announcements: Extract name from "Morpho (MORPHO)" format
  if (name.includes('(') && name.includes(')')) {
    const match = name.match(/^(.+?)\s*\(/);
    if (match && match[1]) {
      return match[1].trim();
    }
  }

  return name;
}

/**
 * Extract contract address from document (looser matching for various schemas)
 */
export function pickContractLoose(doc) {
  return (
    (typeof doc?.contract_address === 'string' && doc.contract_address.trim()) ||
    (typeof doc?.contractAddress === 'string' && doc.contractAddress.trim()) ||
    (typeof doc?.token_address === 'string' && doc.token_address.trim()) ||
    (typeof doc?.token === 'string' && doc.token.trim()) || // e.g., Solana mint
    (typeof doc?.baseToken?.address === 'string' && doc.baseToken.address.trim()) ||
    ''
  );
}

/**
 * Extract chain/blockchain from document (looser matching for various schemas)
 */
export function pickChainLoose(doc) {
  return (
    (typeof doc?.blockchain === 'string' && doc.blockchain.trim()) ||
    (typeof doc?.chainId === 'string' && doc.chainId.trim()) ||
    (typeof doc?.chain === 'string' && doc.chain.trim()) ||
    (typeof doc?.network === 'string' && doc.network.trim()) ||
    (typeof doc?.Blockchain === 'string' && doc.Blockchain.trim()) ||
    ''
  );
}

/**
 * Find matching records in new_listings using symbol, ranked by project name similarity
 * @param {string} symbol - Token symbol to search for
 * @param {Array<string>} names - Project name candidates from announcement
 * @param {Object} options - Search options
 * @param {number} options.maxResults - Maximum number of results to return (default: 5)
 * @param {number} options.similarityThreshold - Minimum similarity score for ranking (default: 0.3)
 * @returns {Array<Object>} Array of matched records with similarity scores, sorted by relevance
 */
export async function findNewListingMatches(symbol, names = [], options = {}) {
  const { maxResults = 30, similarityThreshold = 0.3 } = options;

  if (!symbol) return [];

  const collection = getCollection('new_listings');

  // Normalize the search symbol (trim whitespace and prepare for case-insensitive search)
  const normalizedSymbol = symbol.trim();
  const escapedSymbol = escapeRegex(normalizedSymbol);

  // Build case-insensitive symbol search criteria with whitespace handling
  const symbolOr = [
    { symbol: new RegExp(`^\\s*${escapedSymbol}\\s*$`, 'i') },
    { Symbol: new RegExp(`^\\s*${escapedSymbol}\\s*$`, 'i') },
    { Ticker: new RegExp(`^\\s*${escapedSymbol}\\s*$`, 'i') },
    { dexapi_baseTokenSymbol: new RegExp(`^\\s*${escapedSymbol}\\s*$`, 'i') },
  ];

  const query = {
    $or: symbolOr,
  };

  try {
    // Find all matching records by symbol
    const symbolMatches = await collection.find(query).toArray();

    if (symbolMatches.length === 0) {
      console.log(`✗ No new_listings matches found for symbol: ${symbol}`);
      return [];
    }

    console.log(`📋 Found ${symbolMatches.length} symbol matches for: ${symbol}`);

    // If no project names provided, return all matches with basic scoring
    if (!names.length) {
      return symbolMatches.map((doc, index) => ({
        document: doc,
        similarity: 1.0, // Perfect match for symbol only
        matchType: 'symbol_only',
        projectName: extractProjectName(doc),
        hasContract: !!pickContractLoose(doc),
        rank: index + 1,
      }));
    }

    // Extract the main project name from announcement for comparison
    const announcementProjectName = names[0]; // Use first name as primary

    // Score each match based on project name similarity
    const scoredMatches = [];

    for (const doc of symbolMatches) {
      const newListingProjectName = extractProjectName(doc);
      let maxSimilarity = 0;
      let bestMatchName = null;

      if (newListingProjectName) {
        // Compare against all announcement name candidates
        for (const announcementName of names) {
          const similarity = calculateSimilarity(
            announcementName,
            newListingProjectName,
            {
              caseSensitive: false,
              trimWhitespace: true,
              normalizeSpaces: true,
            },
          );

          if (similarity > maxSimilarity) {
            maxSimilarity = similarity;
            bestMatchName = announcementName;
          }
        }
      }

      // Only include matches above threshold
      if (maxSimilarity >= similarityThreshold) {
        scoredMatches.push({
          document: doc,
          similarity: maxSimilarity,
          matchType: maxSimilarity >= 0.9 ? 'exact_name' : 'similar_name',
          projectName: newListingProjectName,
          matchedAgainst: bestMatchName,
          hasContract: !!pickContractLoose(doc),
          contractAddress: pickContractLoose(doc) || null,
          rank: 0, // Will be set after sorting
        });

        console.log(
          `📊 ${
            doc._id
          }: "${newListingProjectName}" vs "${bestMatchName}" = ${maxSimilarity.toFixed(
            3,
          )}`,
        );
      }
    }

    // Sort by similarity score (highest first), then by contract availability
    scoredMatches.sort((a, b) => {
      if (Math.abs(a.similarity - b.similarity) < 0.01) {
        // If similarity is very close, prefer records with contracts
        return (b.hasContract ? 1 : 0) - (a.hasContract ? 1 : 0);
      }
      return b.similarity - a.similarity;
    });

    // Assign ranks and limit results
    const rankedMatches = scoredMatches.slice(0, maxResults).map((match, index) => ({
      ...match,
      rank: index + 1,
    }));

    console.log(`🎯 Returning ${rankedMatches.length} ranked matches for: ${symbol}`);

    return rankedMatches;
  } catch (error) {
    console.error('Error finding new_listings matches:', error.message);
    return [];
  }
}

/**
 * Find a single best matching record in new_listings (backward compatibility)
 * @param {string} symbol - Token symbol to search for
 * @param {Array<string>} names - Project name candidates from announcement
 * @returns {Object|null} Best matching record or null if no match found
 */
export async function findNewListingMatch(symbol, names) {
  const matches = await findNewListingMatches(symbol, names, { maxResults: 1 });

  if (matches.length > 0) {
    const bestMatch = matches[0];
    console.log(
      `✓ Found best new_listings match: ${
        bestMatch.document._id
      } for symbol: ${symbol} (similarity: ${bestMatch.similarity.toFixed(3)})`,
    );
    return bestMatch.document;
  }

  return null;
}

/**
 * Find the best new_listing match with contract address using enhanced ranking
 * @param {string} symbol - Token symbol to search for
 * @param {Array<string>} names - Project name candidates from announcement
 * @param {Object} options - Search options
 * @param {number} options.maxResults - Maximum results to consider (default: 5)
 * @param {number} options.similarityThreshold - Minimum similarity for ranking (default: 0.3)
 * @param {boolean} options.requireContract - Only return matches with contract addresses (default: true)
 * @returns {Object|null} Best match with contract address or null
 */
export async function findNewListingMatchWithContract(symbol, names = [], options = {}) {
  const { requireContract = true, ...searchOptions } = options;

  // Get all ranked matches
  const rankedMatches = await findNewListingMatches(symbol, names, searchOptions);

  if (rankedMatches.length === 0) {
    console.log(`✗ No ranked matches found for symbol: ${symbol}`);
    return null;
  }

  // Filter for matches with contract addresses if required
  const matchesWithContract = requireContract
    ? rankedMatches.filter((match) => match.hasContract && match.contractAddress)
    : rankedMatches;

  if (matchesWithContract.length === 0) {
    console.log(
      `⚠️ Found ${rankedMatches.length} matches for ${symbol}, but none have contract addresses`,
    );
    return null;
  }

  const bestMatch = matchesWithContract[0];

  console.log(`🎯 Best match for ${symbol}:`);
  console.log(`   📄 Document: ${bestMatch.document._id}`);
  console.log(
    `   📝 Project: "${
      bestMatch.projectName
    }" (similarity: ${bestMatch.similarity.toFixed(3)})`,
  );
  console.log(`   🔗 Contract: ${bestMatch.contractAddress}`);
  console.log(`   🏆 Rank: ${bestMatch.rank}/${rankedMatches.length}`);

  return {
    document: bestMatch.document,
    contractAddress: bestMatch.contractAddress,
    similarity: bestMatch.similarity,
    matchType: bestMatch.matchType,
    projectName: bestMatch.projectName,
    matchedAgainst: bestMatch.matchedAgainst,
    rank: bestMatch.rank,
    totalMatches: rankedMatches.length,
    matchesWithContract: matchesWithContract.length,
  };
}

/**
 * Get detailed matching information for debugging
 * @param {string} symbol - Token symbol to search for
 * @param {Array<string>} names - Project name candidates from announcement
 * @returns {Object} Detailed matching information
 */
export async function getNewListingMatchDetails(symbol, names = []) {
  const rankedMatches = await findNewListingMatches(symbol, names, { maxResults: 10 });

  const details = {
    symbol,
    searchNames: names,
    totalMatches: rankedMatches.length,
    matchesWithContract: rankedMatches.filter((m) => m.hasContract).length,
    matches: rankedMatches.map((match) => ({
      id: match.document._id,
      projectName: match.projectName,
      similarity: match.similarity,
      matchType: match.matchType,
      matchedAgainst: match.matchedAgainst,
      hasContract: match.hasContract,
      contractAddress: match.contractAddress,
      rank: match.rank,
      exchange: match.document.exchange,
      announced_at: match.document.announced_at,
    })),
  };

  return details;
}

/**
 * Get total count of new_listings collection
 */
export async function getNewListingsCount() {
  const collection = getCollection('new_listings');
  return await collection.countDocuments({});
}

# Alpha Project Matching Instructions

## Overview
Implement a symbol-first, name-second matching system to find the best financially viable project from DEXScreener API responses that matches a database record.

## Matching Logic Flow

### Step 1: Symbol Filtering (Required)
- Extract symbol from database record and normalize (lowercase, trim)
- Filter DEXScreener pairs to ONLY those with exact case-insensitive symbol match
- If no symbol matches found, return null - do not proceed

### Step 2: Name Match Scoring
For each symbol-matched pair, calculate name match percentage:

```javascript
// Normalize names: lowercase, remove special chars, trim
normalizedDBName = dbName.toLowerCase().replace(/[^a-z0-9\s]/g, '').replace(/\s+/g, ' ').trim()
normalizedDexName = dexName.toLowerCase().replace(/[^a-z0-9\s]/g, '').replace(/\s+/g, ' ').trim()

// Calculate percentage
if (normalizedDBName === normalizedDexName) {
  matchPercentage = 100
} else if (normalizedDexName.includes(normalizedDBName)) {
  matchPercentage = (normalizedDBName.length / normalizedDexName.length) * 100
} else if (normalizedDBName.includes(normalizedDexName)) {
  matchPercentage = (normalizedDexName.length / normalizedDBName.length) * 100
} else {
  matchPercentage = 0 // or calculate partial word matches
}
```

### Step 3: Financial Filtering
Filter results where:
- marketCap >= 10000
- volume.h24 >= 10000

### Step 4: Ranking
Sort filtered results by:
1. If name match percentages differ by >20%, sort by name match percentage
2. Otherwise, sort by FDV (highest first)

Return the top result

## Example Implementation Structure

```javascript
function findBestAlphaProject(dbRecord, dexScreenerPairs) {
  // 1. Symbol filter
  const symbolMatches = dexScreenerPairs.filter(pair => 
    pair.baseToken.symbol.toLowerCase().trim() === dbRecord.symbol.toLowerCase().trim()
  )
  
  if (symbolMatches.length === 0) return null
  
  // 2. Calculate name match percentages
  const matchesWithScores = symbolMatches.map(pair => ({
    pair,
    nameMatchPercentage: calculateNameMatchPercentage(dbRecord.name, pair.baseToken.name),
    marketCap: pair.marketCap || 0,
    volume24h: pair.volume?.h24 || 0,
    fdv: pair.fdv || 0
  }))
  
  // 3. Financial filter
  const viable = matchesWithScores.filter(m => 
    m.marketCap >= 10000 && m.volume24h >= 10000
  )
  
  // 4. Sort and return best
  viable.sort((a, b) => {
    if (Math.abs(a.nameMatchPercentage - b.nameMatchPercentage) > 20) {
      return b.nameMatchPercentage - a.nameMatchPercentage
    }
    return b.fdv - a.fdv
  })
  
  return viable[0] || null
}
```

## Key Points
- Symbol match is mandatory - no symbol match means no result
- Name matching uses simple containment check with percentage calculation
- Financial thresholds are hard requirements (10k minimum)
- When name matches are similar (within 20%), FDV becomes the deciding factor
- Always return the pair object with match metadata for transparency

## Edge Cases
- Multiple pairs with same symbol: Use name match percentage then FDV
- No financial viable matches: Return null
- Perfect symbol match but poor name match: Still consider if meets financial criteria
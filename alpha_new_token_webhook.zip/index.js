// index.js
import express from 'express';
import mongoose from 'mongoose';
import * as dotenv from 'dotenv';
import {
  sleep,
  extractBaseToken,
  fetchDexscreener,
  selectTopExactPair,
  hasBlockchainAndContract,
  pickBlockchain,
  updateInsertedDoc,
  getVolumeUsd,
  getLiquidityUsd,
  isExactBaseMatch,
  VOLUME_MIN_USD,
  LIQ_MIN_USD,
} from './utils.js';

dotenv.config();

const app = express();
app.use(express.json());

// ---- config ----
const MONGODB_URI = process.env.DATABASE_URL; // e.g. mongodb://user:pass@host:27017/?replicaSet=rs0
const DB_NAME = process.env.DB_NAME || 'block_circle';

const TARGET_COLLECTIONS = (process.env.TARGET_COLLECTIONS &&
  process.env.TARGET_COLLECTIONS.split(',')
    .map((s) => s.trim())
    .filter(Boolean)) || [
  'announcements',
  'alpha_hunter_new_tokens_tier_1',
  'alpha_hunter_new_tokens',
];

const PORT = process.env.PORT || 3001;

/** ---------------------------------------------------
 * Dexscreener rate-limit: ensure ≥10s between requests
 * Tunable via DEXSCREENER_MIN_GAP_MS (default 10000 ms)
 * --------------------------------------------------- */
const DEXS_GAP_MS = Number(process.env.DEXSCREENER_MIN_GAP_MS ?? 500);
let _dexsQueue = Promise.resolve();
let _dexsLastCallTs = 0;

function fetchDexscreenerWithGap(query) {
  const run = async () => {
    const elapsed = Date.now() - _dexsLastCallTs;
    const wait = Math.max(0, DEXS_GAP_MS - elapsed);
    if (wait > 0) await sleep(wait);
    const data = await fetchDexscreener(query);
    _dexsLastCallTs = Date.now();
    return data;
  };
  // Chain to guarantee serialization (handles concurrency safely)
  _dexsQueue = _dexsQueue.then(run, run);
  return _dexsQueue;
}

// Core handler for each insert (refactored)
async function handleInsert(change) {
  try {
    const doc = change.fullDocument || {};

    // 0) Short-circuit if both already present
    if (hasBlockchainAndContract(doc)) {
      await updateInsertedDoc(change, {
        status: 'skipped_existing_fields',
        reason: 'document_already_has_blockchain_and_contract',
        blockchain: pickBlockchain(doc),
        // NOTE: we intentionally do not echo the contract address here for privacy unless you want it
      });
      return;
    }

    // 1) Need a base token string to query Dexscreener
    const baseToken = extractBaseToken(doc);
    if (!baseToken) {
      await updateInsertedDoc(change, {
        status: 'no_match',
        reason: 'missing_baseToken',
      });
      return;
    }

    // Prefer a known chain if provided (but contract was missing)
    const preferredChain = pickBlockchain(doc);

    // 2) Query Dexscreener
    const data = await fetchDexscreener(baseToken);

    // 3) Apply exact-match + thresholds + FDV sort and pick best
    const { top, vol, liq, reason } = selectTopExactPair(data, baseToken, preferredChain);

    if (!top) {
      await updateInsertedDoc(change, { status: 'no_match', reason });
      return;
    }

    // 4) Persist selection details
    await updateInsertedDoc(change, {
      status: 'ok',
      chainId: top.chainId, // blockchain name/id
      contractAddress: top.baseToken?.address || null, // contract
      pairAddress: top.pairAddress || null,
      pairUrl: top.url || null,
      baseSymbol: top.baseToken?.symbol || null,
      fdv: typeof top.fdv === 'number' ? top.fdv : null,
      volumeUsd: vol,
      liquidityUsd: liq,
    });
  } catch (err) {
    console.error('Handler error:', err);
    try {
      await updateInsertedDoc(change, {
        status: 'error',
        error: String(err?.message || err),
      });
    } catch (_) {
      /* ignore secondary failure */
    }
  }
}

// ---- change stream setup ----
async function startChangeStream() {
  const pipeline = [
    {
      $match: {
        operationType: { $in: ['insert'] },
        'ns.coll': { $in: TARGET_COLLECTIONS },
      },
    },
  ];

  // For inserts, MongoDB already includes fullDocument; keeping explicit for clarity
  const cs = mongoose.connection.watch(pipeline, { fullDocument: 'default' });

  cs.on('change', async (change) => {
    // change.ns = { db, coll }
    // change.fullDocument = inserted doc
    console.log(`[change] ${change.ns.coll} insert _id=${change.fullDocument?._id}`);
    await handleInsert(change);
  });

  cs.on('error', async (err) => {
    console.error('Change stream error:', err);
    // naive backoff + restart
    await sleep(2000);
    startChangeStream().catch((e) =>
      console.error('Failed to restart change stream:', e),
    );
  });

  process.on('SIGINT', async () => {
    try {
      await cs.close();
    } catch {}
    process.exit(0);
  });
}

// ---- health endpoint ----
app.get('/health', (_req, res) => res.json({ ok: true, watching: TARGET_COLLECTIONS }));

/**
 * Matching Analysis endpoint:
 * Analyzes how many announcements can be matched with new_listings records
 * without performing any actual processing - just statistics.
 *
 * Request:  GET /analyze/matching
 * Response: { ok: true, matchingStats: { ... } }
 */
app.get('/analyze/matching', async (req, res) => {
  // --- helper functions (extracted from backfill endpoint) ---
  const escRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  const pickNameCandidates = (d) => {
    const vals = [d?.name, d?.Project_name, d?.project_name, d?.title].filter(
      (x) => typeof x === 'string' && x.trim(),
    );
    return [...new Set(vals.map((v) => v.trim()))];
  };

  const findNewListingMatch = async (db, symbol, names) => {
    if (!symbol || !names?.length) return null;
    const coll = db.collection('new_listings');

    const symbolOr = [
      { symbol: symbol },
      { Symbol: symbol },
      { Ticker: symbol },
      { dexapi_baseTokenSymbol: symbol },
    ];

    const nameOr = names.flatMap((n) => {
      try {
        const escaped = escRe(n);
        return [
          { name: new RegExp(`^${escaped}$`, 'i') },
          { Name: new RegExp(`^${escaped}$`, 'i') },
          { project_name: new RegExp(`^${escaped}$`, 'i') },
          { Project_name: new RegExp(`^${escaped}$`, 'i') },
        ];
      } catch (error) {
        console.warn(`Failed to create regex for name "${n}":`, error.message);
        return [];
      }
    });

    const filter = {
      $and: [
        { $or: symbolOr },
        // { $or: nameOr },
      ],
    };
    return await coll.findOne(filter);
  };

  try {
    const db = mongoose.connection.db;
    const announcementsColl = db.collection('announcements');
    const newListingsColl = db.collection('new_listings');

    // Get collection totals
    const totalAnnouncements = await announcementsColl.countDocuments({});
    const totalNewListings = await newListingsColl.countDocuments({});

    const cursor = announcementsColl.find({});

    const stats = {
      totalAnnouncementsCount: totalAnnouncements,
      totalNewListingsCount: totalNewListings,

      processed: 0,
      foundMatches: 0,
      noMatchableData: 0,
      couldNotMatch: 0,
      alreadyHasBlockchainAndContract: 0,

      matchedRecords: [],
      unmatchedRecords: [],
      noDataRecords: [],
      alreadyCompleteRecords: [],
    };

    console.log(`Starting matching analysis for ${totalAnnouncements} announcements...`);

    for await (const doc of cursor) {
      stats.processed += 1;

      if (stats.processed % 100 === 0) {
        console.log(`Processed ${stats.processed}/${totalAnnouncements} records...`);
      }

      try {
        // Skip if already has blockchain and contract
        if (hasBlockchainAndContract(doc)) {
          stats.alreadyHasBlockchainAndContract += 1;
          stats.alreadyCompleteRecords.push({
            _id: doc._id,
            blockchain: pickBlockchain(doc),
            reason: 'already_has_blockchain_and_contract',
          });
          continue;
        }

        // Extract token info for matching
        const baseToken = extractBaseToken(doc);
        const nameCandidates = pickNameCandidates(doc);

        // Check if we have data to match on
        if (!baseToken || !nameCandidates.length) {
          stats.noMatchableData += 1;
          stats.noDataRecords.push({
            _id: doc._id,
            baseToken: baseToken || null,
            nameCandidates: nameCandidates || [],
            reason: 'missing_symbol_or_name',
          });
          continue;
        }

        // Try to find match in new_listings
        const newListingDoc = await findNewListingMatch(db, baseToken, nameCandidates);

        if (newListingDoc) {
          stats.foundMatches += 1;
          stats.matchedRecords.push({
            announcementId: doc._id,
            newListingId: newListingDoc._id,
            symbol: baseToken,
            names: nameCandidates,
            matchedSymbol:
              newListingDoc.symbol ||
              newListingDoc.Symbol ||
              newListingDoc.Ticker ||
              newListingDoc.dexapi_baseTokenSymbol,
            matchedName:
              newListingDoc.name ||
              newListingDoc.Name ||
              newListingDoc.project_name ||
              newListingDoc.Project_name,
          });
        } else {
          stats.couldNotMatch += 1;
          stats.unmatchedRecords.push({
            _id: doc._id,
            symbol: baseToken,
            names: nameCandidates,
            reason: 'no_match_found_in_new_listings',
          });
        }
      } catch (error) {
        console.error(`Error processing announcement ${doc._id}:`, error);
        stats.couldNotMatch += 1;
        stats.unmatchedRecords.push({
          _id: doc._id,
          reason: 'processing_error',
          error: error.message,
        });
      }
    }

    // Calculate percentages
    const matchPercentage =
      stats.processed > 0 ? ((stats.foundMatches / stats.processed) * 100).toFixed(2) : 0;

    const matchableRecords =
      stats.processed - stats.alreadyHasBlockchainAndContract - stats.noMatchableData;
    const matchablePercentage =
      matchableRecords > 0
        ? ((stats.foundMatches / matchableRecords) * 100).toFixed(2)
        : 0;

    const response = {
      ok: true,
      summary: {
        totalAnnouncementsAnalyzed: stats.processed,
        totalNewListingsAvailable: totalNewListings,

        results: {
          foundMatches: stats.foundMatches,
          couldNotMatch: stats.couldNotMatch,
          noMatchableData: stats.noMatchableData,
          alreadyComplete: stats.alreadyHasBlockchainAndContract,
        },

        percentages: {
          overallMatchRate: `${matchPercentage}%`,
          matchableRecordsMatchRate: `${matchablePercentage}%`,
        },

        breakdown: {
          totalProcessed: stats.processed,
          matchableRecords: matchableRecords,
          alreadyCompleteRecords: stats.alreadyHasBlockchainAndContract,
          recordsWithoutMatchableData: stats.noMatchableData,
        },
      },

      detailedStats: {
        matchedRecords: stats.matchedRecords,
        unmatchedRecords: stats.unmatchedRecords,
        noDataRecords: stats.noDataRecords,
        alreadyCompleteRecords: stats.alreadyCompleteRecords,
      },
    };

    console.log('\n=== MATCHING ANALYSIS SUMMARY ===');
    console.log(`Total announcements analyzed: ${stats.processed}`);
    console.log(`Total new_listings available: ${totalNewListings}`);
    console.log(`Found matches: ${stats.foundMatches}`);
    console.log(`Overall match rate: ${matchPercentage}%`);
    console.log(`Matchable records match rate: ${matchablePercentage}%`);
    console.log(`Already complete records: ${stats.alreadyHasBlockchainAndContract}`);
    console.log(`Records without matchable data: ${stats.noMatchableData}`);
    console.log('=====================================\n');

    return res.json(response);
  } catch (err) {
    console.error('Matching analysis endpoint error:', err);
    return res.status(500).json({
      ok: false,
      error: String(err?.message || err),
    });
  }
});

/**
 * Debug Failed Matches endpoint:
 * Analyzes test_announcement records with no_match status to identify logical errors
 * in the matching and filtering functions. Also fixes records that should have matched
 * with the improved case-insensitive and whitespace-trimmed logic.
 *
 * Request:  GET /debug/failed-matches?fix=true (optional fix parameter)
 * Response: { ok: true, analysis: { ... }, fixes: { ... } }
 */
app.get('/debug/failed-matches', async (req, res) => {
  try {
    const db = mongoose.connection.db;
    const testColl = db.collection('test_announcement');
    const shouldFix = req.query.fix === 'true';

    // Find records with specific failed statuses
    const targetStatuses = ['no_exact_baseToken_match', 'thresholds_not_met_or_no_fdv'];

    const failedRecords = await testColl
      .find({
        'dexscreener.status': 'no_match',
        'dexscreener.reason': { $in: targetStatuses },
      })
      .toArray();

    console.log(`Found ${failedRecords.length} failed records to analyze`);
    console.log(`Fix mode: ${shouldFix ? 'ENABLED' : 'DISABLED'}`);

    const analysis = {
      totalAnalyzed: failedRecords.length,
      byReason: {},
      detectedIssues: [],
      sampleProblems: [],
    };

    const fixes = {
      enabled: shouldFix,
      totalFixed: 0,
      byReason: {},
      fixedRecords: [],
      errors: [],
    };

    // Initialize counters
    targetStatuses.forEach((reason) => {
      analysis.byReason[reason] = {
        count: 0,
        shouldHaveMatched: 0,
        shouldHavePassedThresholds: 0,
        logicalErrors: [],
      };
      fixes.byReason[reason] = {
        attempted: 0,
        successful: 0,
        failed: 0,
      };
    });

    for (const record of failedRecords) {
      const reason = record.dexscreener.reason;
      const symbol = record.symbol;
      const pairs = record.dexscreener.raw?.pairs || [];

      analysis.byReason[reason].count++;

      console.log(`\n--- Analyzing record ${record._id} (${reason}) ---`);
      console.log(`Symbol: "${symbol}"`);
      console.log(`Pairs found: ${pairs.length}`);


      if (reason === 'no_exact_baseToken_match') {
        // Check if there ARE actually exact matches that were missed
        const actualExactMatches = pairs.filter((p) => isExactBaseMatch(p, symbol));

        if (actualExactMatches.length > 0) {
          analysis.byReason[reason].shouldHaveMatched++;

          const issue = {
            recordId: record._id,
            symbol: symbol,
            issue: 'Found exact matches that should have been detected',
            matches: actualExactMatches.map((p) => ({
              symbol: p.baseToken.symbol,
              name: p.baseToken.name,
              address: p.baseToken.address,
              chainId: p.chainId,
            })),
          };

          analysis.byReason[reason].logicalErrors.push(issue);

          // Check for potential string issues
          const symbolIssues = [];
          actualExactMatches.forEach((p) => {
            if (p.baseToken.symbol !== symbol) {
              // Check for whitespace or hidden characters
              const symbolBytes = [...p.baseToken.symbol].map((c) => c.charCodeAt(0));
              const searchBytes = [...symbol].map((c) => c.charCodeAt(0));

              if (p.baseToken.symbol.trim() === symbol.trim()) {
                symbolIssues.push(
                  `Whitespace issue: "${p.baseToken.symbol}" vs "${symbol}"`,
                );
              } else {
                symbolIssues.push(
                  `Character encoding issue: [${symbolBytes}] vs [${searchBytes}]`,
                );
              }
            }

            if (p.baseToken.name !== symbol && p.baseToken.name === symbol) {
              symbolIssues.push(`Name match issue with "${p.baseToken.name}"`);
            }
          });

          if (symbolIssues.length > 0) {
            issue.stringIssues = symbolIssues;
          }
        }

        // Also check for case-insensitive matches that were missed
        const caseInsensitiveMatches = pairs.filter((p) => {
          if (!p?.baseToken) return false;
          const symbolMatch = p.baseToken.symbol?.toLowerCase() === symbol.toLowerCase();
          const nameMatch = p.baseToken.name?.toLowerCase() === symbol.toLowerCase();
          return (symbolMatch || nameMatch) && !actualExactMatches.includes(p);
        });

        if (caseInsensitiveMatches.length > 0) {
          analysis.byReason[reason].logicalErrors.push({
            recordId: record._id,
            symbol: symbol,
            issue: 'Case-insensitive matches found (current logic is case-sensitive)',
            matches: caseInsensitiveMatches.map((p) => ({
              symbol: p.baseToken.symbol,
              name: p.baseToken.name,
              address: p.baseToken.address,
              chainId: p.chainId,
            })),
          });

          // Apply fix for case-insensitive matches if enabled
          if (shouldFix) {
            fixes.byReason[reason].attempted++;

            try {
              // Re-run the improved matching logic to find the best pair
              const { top, vol, liq } = selectTopExactPair(record.dexscreener.raw, symbol);

              if (top && vol > VOLUME_MIN_USD && liq > LIQ_MIN_USD) {
                const fixUpdate = {
                  $set: {
                    'dexscreener.status': 'ok_fixed',
                    'dexscreener.reason': null,
                    'dexscreener.fixedAt': new Date(),
                    'dexscreener.fixedFrom': reason,
                    // Preserve original error information for audit trail
                    'dexscreener.originalError': {
                      status: record.dexscreener.status,
                      reason: record.dexscreener.reason,
                      checkedAt: record.dexscreener.checkedAt,
                      note: 'This record was originally missed due to case-sensitivity/whitespace issues but has been corrected'
                    },
                    // Current correct data
                    'dexscreener.chainId': top.chainId,
                    'dexscreener.contractAddress': top.baseToken?.address || null,
                    'dexscreener.pairAddress': top.pairAddress || null,
                    'dexscreener.pairUrl': top.url || null,
                    'dexscreener.baseSymbol': top.baseToken?.symbol || null,
                    'dexscreener.baseName': top.baseToken?.name || null,
                    'dexscreener.quoteSymbol': top.quoteToken?.symbol || null,
                    'dexscreener.quoteName': top.quoteToken?.name || null,
                    'dexscreener.priceUsd': top.priceUsd ?? null,
                    'dexscreener.priceNative': top.priceNative ?? null,
                    'dexscreener.fdv': typeof top.fdv === 'number' ? top.fdv : null,
                    'dexscreener.marketCap': typeof top.marketCap === 'number' ? top.marketCap : null,
                    'dexscreener.volumeUsd': vol,
                    'dexscreener.liquidityUsd': liq,
                    'dexscreener.selectedPair': top,
                  }
                };

                await testColl.updateOne({ _id: record._id }, fixUpdate);

                fixes.byReason[reason].successful++;
                fixes.totalFixed++;
                fixes.fixedRecords.push({
                  recordId: record._id,
                  symbol: symbol,
                  reason: reason,
                  selectedPair: {
                    symbol: top.baseToken?.symbol,
                    name: top.baseToken?.name,
                    address: top.baseToken?.address,
                    chainId: top.chainId,
                    volume: vol,
                    liquidity: liq,
                    fdv: top.fdv
                  }
                });

                console.log(`✓ Fixed record ${record._id}: ${symbol} -> ${top.baseToken?.symbol} (${top.chainId})`);
              } else {
                // Check if this was originally no_exact_baseToken_match but we found exact matches
                // If so, reclassify to thresholds_not_met_or_no_fdv
                if (reason === 'no_exact_baseToken_match') {
                  const exactMatches = pairs.filter((p) => isExactBaseMatch(p, symbol));

                  if (exactMatches.length > 0) {
                    // Found exact matches but they failed thresholds - reclassify
                    const reclassifyUpdate = {
                      $set: {
                        'dexscreener.status': 'no_match',
                        'dexscreener.reason': 'thresholds_not_met_or_no_fdv',
                        'dexscreener.reclassifiedAt': new Date(),
                        'dexscreener.reclassifiedFrom': reason,
                        'dexscreener.originalError': {
                          status: record.dexscreener.status,
                          reason: record.dexscreener.reason,
                          checkedAt: record.dexscreener.checkedAt,
                          note: 'Record had exact matches but they failed volume/liquidity thresholds, reason reclassified from no_exact_baseToken_match to thresholds_not_met_or_no_fdv'
                        },
                        'dexscreener.checkedAt': new Date()
                      }
                    };

                    await testColl.updateOne({ _id: record._id }, reclassifyUpdate);

                    fixes.byReason[reason].successful++;
                    fixes.fixedRecords.push({
                      recordId: record._id,
                      symbol: symbol,
                      originalReason: reason,
                      newReason: 'thresholds_not_met_or_no_fdv',
                      action: 'reclassified',
                      exactMatchesFound: exactMatches.length
                    });

                    console.log(`↻ Reclassified record ${record._id}: ${symbol} (${reason} → thresholds_not_met_or_no_fdv)`);
                  } else {
                    fixes.byReason[reason].failed++;
                    fixes.errors.push({
                      recordId: record._id,
                      symbol: symbol,
                      reason: reason,
                      error: 'No exact matches found with improved logic'
                    });
                  }
                } else {
                  fixes.byReason[reason].failed++;
                  fixes.errors.push({
                    recordId: record._id,
                    symbol: symbol,
                    reason: reason,
                    error: 'Improved matching found pairs but they failed volume/liquidity thresholds'
                  });
                }
              }
            } catch (fixError) {
              fixes.byReason[reason].failed++;
              fixes.errors.push({
                recordId: record._id,
                symbol: symbol,
                reason: reason,
                error: fixError.message
              });
              console.error(`✗ Failed to fix record ${record._id}:`, fixError.message);
            }
          }
        }
      } else if (reason === 'thresholds_not_met_or_no_fdv') {
        // Re-run the exact matching logic to see what passed initial filters
        let exactMatches = pairs.filter((p) => isExactBaseMatch(p, symbol));

        console.log(
          `  Found ${exactMatches.length} exact matches for threshold analysis`,
        );

        if (exactMatches.length > 0) {
          // Apply the same logic as selectTopExactPair
          const withMetrics = exactMatches.map((p) => {
            const vol = getVolumeUsd(p.volume);
            const liq = getLiquidityUsd(p.liquidity);
            const fdv =
              typeof p.fdv === 'number' && Number.isFinite(p.fdv) ? p.fdv : -Infinity;

            // console.log(
            //   `    Pair ${p.baseToken.symbol}: vol=${vol}, liq=${liq}, fdv=${fdv}`,
            // );
            // console.log(
            //   `      Volume threshold: ${vol} > ${VOLUME_MIN_USD} = ${
            //     vol > VOLUME_MIN_USD
            //   }`,
            // );
            // console.log(
            //   `      Liquidity threshold: ${liq} > ${LIQ_MIN_USD} = ${liq > LIQ_MIN_USD}`,
            // );

            return { p, vol, liq, fdv };
          });

          const passedThresholds = withMetrics.filter(
            (x) => x.vol > VOLUME_MIN_USD && x.liq > LIQ_MIN_USD,
          );

          if (passedThresholds.length > 0) {
            analysis.byReason[reason].shouldHavePassedThresholds++;

            const topPair = passedThresholds.sort((a, b) => b.fdv - a.fdv)[0];

            analysis.byReason[reason].logicalErrors.push({
              recordId: record._id,
              symbol: symbol,
              issue: 'Found pairs that should have passed thresholds',
              details: {
                totalExactMatches: exactMatches.length,
                passedThresholds: passedThresholds.length,
                volumeThreshold: VOLUME_MIN_USD,
                liquidityThreshold: LIQ_MIN_USD,
                pairs: passedThresholds.map((x) => ({
                  symbol: x.p.baseToken.symbol,
                  name: x.p.baseToken.name,
                  volume: x.vol,
                  liquidity: x.liq,
                  fdv: x.fdv,
                  chainId: x.p.chainId,
                  address: x.p.baseToken.address,
                })),
              },
            });

            // Apply fix if enabled
            if (shouldFix) {
              fixes.byReason[reason].attempted++;

              try {
                const fixUpdate = {
                  $set: {
                    'dexscreener.status': 'ok_fixed',
                    'dexscreener.reason': null,
                    'dexscreener.fixedAt': new Date(),
                    'dexscreener.fixedFrom': reason,
                    // Preserve original error information for audit trail
                    'dexscreener.originalError': {
                      status: record.dexscreener.status,
                      reason: record.dexscreener.reason,
                      checkedAt: record.dexscreener.checkedAt,
                      note: 'This record was originally missed due to case-sensitivity/whitespace issues but has been corrected'
                    },
                    // Current correct data
                    'dexscreener.chainId': topPair.p.chainId,
                    'dexscreener.contractAddress': topPair.p.baseToken?.address || null,
                    'dexscreener.pairAddress': topPair.p.pairAddress || null,
                    'dexscreener.pairUrl': topPair.p.url || null,
                    'dexscreener.baseSymbol': topPair.p.baseToken?.symbol || null,
                    'dexscreener.baseName': topPair.p.baseToken?.name || null,
                    'dexscreener.quoteSymbol': topPair.p.quoteToken?.symbol || null,
                    'dexscreener.quoteName': topPair.p.quoteToken?.name || null,
                    'dexscreener.priceUsd': topPair.p.priceUsd ?? null,
                    'dexscreener.priceNative': topPair.p.priceNative ?? null,
                    'dexscreener.fdv': topPair.fdv !== -Infinity ? topPair.fdv : null,
                    'dexscreener.marketCap': typeof topPair.p.marketCap === 'number' ? topPair.p.marketCap : null,
                    'dexscreener.volumeUsd': topPair.vol,
                    'dexscreener.liquidityUsd': topPair.liq,
                    'dexscreener.selectedPair': topPair.p,
                  }
                };

                await testColl.updateOne({ _id: record._id }, fixUpdate);

                fixes.byReason[reason].successful++;
                fixes.totalFixed++;
                fixes.fixedRecords.push({
                  recordId: record._id,
                  symbol: symbol,
                  reason: reason,
                  selectedPair: {
                    symbol: topPair.p.baseToken?.symbol,
                    name: topPair.p.baseToken?.name,
                    address: topPair.p.baseToken?.address,
                    chainId: topPair.p.chainId,
                    volume: topPair.vol,
                    liquidity: topPair.liq,
                    fdv: topPair.fdv
                  }
                });

                console.log(`✓ Fixed record ${record._id}: ${symbol} -> ${topPair.p.baseToken?.symbol} (${topPair.p.chainId})`);
              } catch (fixError) {
                fixes.byReason[reason].failed++;
                fixes.errors.push({
                  recordId: record._id,
                  symbol: symbol,
                  reason: reason,
                  error: fixError.message
                });
                console.error(`✗ Failed to fix record ${record._id}:`, fixError.message);
              }
            }
          } else {
            // Check what specifically failed
            const thresholdAnalysis = withMetrics.map((x) => ({
              symbol: x.p.baseToken.symbol,
              volume: x.vol,
              liquidity: x.liq,
              fdv: x.fdv,
              volumePass: x.vol > VOLUME_MIN_USD,
              liquidityPass: x.liq > LIQ_MIN_USD,
              fdvValid: x.fdv !== -Infinity,
            }));

            console.log(`    All pairs failed thresholds:`, thresholdAnalysis);
          }
        }
      }

      // Sample first few problems for detailed analysis
      if (analysis.sampleProblems.length < 5) {
        analysis.sampleProblems.push({
          recordId: record._id,
          symbol: symbol,
          reason: reason,
          rawPairs: pairs.map((p) => ({
            baseToken: p.baseToken,
            volume: p.volume,
            liquidity: p.liquidity,
            fdv: p.fdv,
            chainId: p.chainId,
          })),
        });
      }
    }

    // Generate summary of potential issues
    analysis.detectedIssues = [];

    Object.entries(analysis.byReason).forEach(([reason, data]) => {
      if (data.shouldHaveMatched > 0) {
        analysis.detectedIssues.push({
          issue: `Case-sensitive exact matching too strict`,
          reason: reason,
          affectedRecords: data.shouldHaveMatched,
          description: `${data.shouldHaveMatched} records had exact matches that weren't detected, possibly due to case sensitivity or string encoding issues`,
        });
      }

      if (data.shouldHavePassedThresholds > 0) {
        analysis.detectedIssues.push({
          issue: `Threshold filtering logic error`,
          reason: reason,
          affectedRecords: data.shouldHavePassedThresholds,
          description: `${data.shouldHavePassedThresholds} records had pairs that should have passed volume/liquidity thresholds`,
        });
      }
    });

    const response = {
      ok: true,
      summary: {
        totalRecordsAnalyzed: analysis.totalAnalyzed,
        potentialIssuesFound: analysis.detectedIssues.length,
        fixMode: shouldFix,
        totalFixed: fixes.totalFixed,
        thresholds: {
          volumeMinUsd: VOLUME_MIN_USD,
          liquidityMinUsd: LIQ_MIN_USD,
        },
      },
      analysis: analysis,
      fixes: fixes,
    };

    console.log('\n=== FAILED MATCHES ANALYSIS SUMMARY ===');
    console.log(`Total failed records analyzed: ${analysis.totalAnalyzed}`);
    console.log(`Potential logical issues found: ${analysis.detectedIssues.length}`);
    analysis.detectedIssues.forEach((issue) => {
      console.log(`  - ${issue.issue}: ${issue.affectedRecords} records`);
    });

    if (shouldFix) {
      console.log('\n=== FIXES APPLIED ===');
      console.log(`Total records fixed: ${fixes.totalFixed}`);
      console.log(`Fix success rate: ${analysis.totalAnalyzed > 0 ? ((fixes.totalFixed / analysis.totalAnalyzed) * 100).toFixed(2) : 0}%`);
      Object.entries(fixes.byReason).forEach(([reason, stats]) => {
        if (stats.attempted > 0) {
          console.log(`  ${reason}: ${stats.successful}/${stats.attempted} successful (${stats.failed} failed)`);
        }
      });
      if (fixes.errors.length > 0) {
        console.log(`  Errors encountered: ${fixes.errors.length}`);
      }
    } else {
      console.log('\n=== FIX MODE DISABLED ===');
      console.log('Add ?fix=true to the URL to enable automatic fixing of detected issues');
    }
    console.log('==========================================\n');

    return res.json(response);
  } catch (err) {
    console.error('Debug failed matches endpoint error:', err);
    return res.status(500).json({
      ok: false,
      error: String(err?.message || err),
    });
  }
});

/**
 * Backfill endpoint:
 * Reads ALL docs from "announcements", applies the same processing pipeline,
 * and writes results into "test_announcement" (upserting by source _id).
 *
 * Request:  POST /backfill/announcements
 * Response: { ok: true, stats: { scanned, ok, no_match, skipped_existing_fields, error } }
 */
// Backfill endpoint with new_listing pre-match
app.get('/backfill/announcements', async (req, res) => {
  // --- local helpers (scoped to this route) ---
  const escRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  const pickNameCandidates = (d) => {
    const vals = [d?.name, d?.Project_name, d?.project_name, d?.title].filter(
      (x) => typeof x === 'string' && x.trim(),
    );
    return [...new Set(vals.map((v) => v.trim()))];
  };

  // looser contract/chain pickers to cover mixed schemas (includes "token", "Blockchain")
  const pickContractLoose = (d) =>
    (typeof d?.contract_address === 'string' && d.contract_address.trim()) ||
    (typeof d?.contractAddress === 'string' && d.contractAddress.trim()) ||
    (typeof d?.token_address === 'string' && d.token_address.trim()) ||
    (typeof d?.token === 'string' && d.token.trim()) || // e.g., Solana mint
    (typeof d?.baseToken?.address === 'string' && d.baseToken.address.trim()) ||
    '';

  const pickChainLoose = (d) =>
    (typeof d?.blockchain === 'string' && d.blockchain.trim()) ||
    (typeof d?.chainId === 'string' && d.chainId.trim()) ||
    (typeof d?.chain === 'string' && d.chain.trim()) ||
    (typeof d?.network === 'string' && d.network.trim()) ||
    (typeof d?.Blockchain === 'string' && d.Blockchain.trim()) ||
    '';

  // choose a pair from Dexscreener by contract (and optional chain), prefer highest liquidity, then FDV, then volume
  const selectPairByContract = (
    data,
    { symbol, names = [], contract = '', preferredChain = '' },
  ) => {
    const pairs = Array.isArray(data?.pairs) ? data.pairs : [];
    if (!pairs.length) return { pair: null, reason: 'no_pairs' };

    const ciEq = (a, b) =>
      String(a ?? '').toLowerCase() === String(b ?? '').toLowerCase();
    const chainLC = String(preferredChain || '').toLowerCase();

    // --- Step 3: Match Project Name AND Symbol with Dexscreener output ---
    if (symbol) {
      let candidates = pairs.filter((p) => {
        const symOk = ciEq(p?.baseToken?.symbol, symbol);
        if (!symOk) return false;
        if (!names?.length) return true;
        const nameOk = names.some((n) => ciEq(p?.baseToken?.name, n));
        return nameOk;
      });

      if (chainLC) {
        const onChain = candidates.filter((p) => ciEq(p?.chainId, preferredChain));
        if (onChain.length) candidates = onChain;
      }

      // --- Step 5: thresholds then FDV desc (vol/liquidity > 10k) ---
      const ranked = candidates
        .map((p) => ({
          p,
          vol: getVolumeUsd(p.volume),
          liq: getLiquidityUsd(p.liquidity),
          fdv: typeof p.fdv === 'number' && Number.isFinite(p.fdv) ? p.fdv : -Infinity,
        }))
        .filter((x) => x.vol > VOLUME_MIN_USD && x.liq > LIQ_MIN_USD)
        .sort((a, b) => b.fdv - a.fdv);

      if (ranked.length) {
        const top = ranked[0];
        return { pair: top.p, vol: top.vol, liq: top.liq, source: 'name_symbol' };
      }
    }

    // --- Step 4 (+5): exact baseToken match using existing pipeline ---
    if (symbol) {
      const { top, vol, liq, reason } = selectTopExactPair(data, symbol, preferredChain);
      if (top) return { pair: top, vol, liq, source: 'exact_base' };
    }

    // --- Fallback: previous behavior (by CONTRACT + optional chain) ---
    if (contract) {
      let candidates = pairs.filter((p) => ciEq(p?.baseToken?.address, contract));
      if (!candidates.length) return { pair: null, reason: 'no_pairs_for_contract' };

      if (chainLC) {
        const onChain = candidates.filter((p) => ciEq(p?.chainId, preferredChain));
        if (onChain.length) candidates = onChain;
      }

      // Rank by liquidity desc, then FDV desc, then volume desc
      const ranked = candidates
        .map((p) => ({
          p,
          liq: getLiquidityUsd(p.liquidity),
          fdv: typeof p.fdv === 'number' && Number.isFinite(p.fdv) ? p.fdv : -Infinity,
          vol: getVolumeUsd(p.volume),
        }))
        .sort((a, b) => b.liq - a.liq || b.fdv - a.fdv || b.vol - a.vol);

      if (ranked.length) {
        const top = ranked[0];
        return { pair: top.p, vol: top.vol, liq: top.liq, source: 'contract' };
      }
      return { pair: null, reason: 'no_ranked_candidates_for_contract' };
    }

    return { pair: null, reason: 'no_match_after_name_symbol_and_exact' };
  };

  // find a matching record in new_listing using (symbol + project name) and requiring contract + chain to exist
  const findNewListingMatch = async (db, symbol, names) => {
    if (!symbol || !names?.length) return null;
    const coll = db.collection('new_listings');

    const symbolOr = [
      { symbol: symbol },
      { Symbol: symbol },
      { Ticker: symbol },
      { dexapi_baseTokenSymbol: symbol },
    ];

    const nameOr = names.flatMap((n) => {
      try {
        const escaped = escRe(n);
        return [
          { name: new RegExp(`^${escaped}$`, 'i') },
          { Name: new RegExp(`^${escaped}$`, 'i') },
          { project_name: new RegExp(`^${escaped}$`, 'i') },
          { Project_name: new RegExp(`^${escaped}$`, 'i') },
        ];
      } catch (error) {
        console.warn(`Failed to create regex for name "${n}":`, error.message);
        return [];
      }
    });

    const contractExistsOr = [
      { contract_address: { $type: 'string', $ne: '' } },
      { contractAddress: { $type: 'string', $ne: '' } },
      { token_address: { $type: 'string', $ne: '' } },
      { token: { $type: 'string', $ne: '' } }, // solana mint
      { 'baseToken.address': { $type: 'string', $ne: '' } },
    ];

    const chainExistsOr = [
      { blockchain: { $type: 'string', $ne: '' } },
      { chainId: { $type: 'string', $ne: '' } },
      { chain: { $type: 'string', $ne: '' } },
      { network: { $type: 'string', $ne: '' } },
      { Blockchain: { $type: 'string', $ne: '' } },
    ];

    const filter = {
      $and: [
        { $or: symbolOr },
        { $or: nameOr },
        // { $or: contractExistsOr },
        // { $or: chainExistsOr },
      ],
    };
    return await coll.findOne(filter);
  };

  try {
    const db = mongoose.connection.db;
    const src = db.collection('announcements');
    const dst = db.collection('test_announcement');

    // Get total counts for both collections
    const totalAnnouncements = await src.countDocuments({});
    const totalNewListings = await db.collection('new_listings').countDocuments({});

    const cursor = src.find({});

    const stats = {
      // Collection totals
      totalAnnouncementsCount: totalAnnouncements,
      totalNewListingsCount: totalNewListings,

      // Processing stats
      scanned: 0,
      ok: 0,
      ok_from_new_listing_match: 0,
      no_match: 0,
      skipped_existing_fields: 0,
      error: 0,
      no_pair_for_new_listing_contract: 0,
      new_listing_no_match: 0,

      // NEW: Matching statistics between announcements and new_listings
      matching: {
        foundNewListingMatch: 0, // announcements that found a match in new_listings
        noMatchableData: 0, // announcements without symbol/name to match
        matchedButMissingContract: 0, // matched by name/symbol but new_listing record missing contract
        successfulMatches: 0, // complete matches that led to successful processing
        matchedRecordIds: [], // IDs of announcements that matched with new_listings
        unmatchedRecordIds: [], // IDs of announcements that couldn't match with new_listings
      },
    };

    const writeResult = async (originalDoc, symbol, payload) => {
      const sourceId = originalDoc?._id;
      await dst.updateOne(
        { _id: sourceId },
        {
          $set: {
            sourceCollection: 'announcements',
            symbol: symbol || null,
            blockchain: pickBlockchain(originalDoc) || null,
            dexscreener: { ...payload, checkedAt: new Date() },
          },
        },
        { upsert: true },
      );
    };

    for await (const doc of cursor) {
      stats.scanned += 1;

      console.log('-- current doc under processing', doc._id);

      try {
        // 0) Already has both? keep existing "skip" behavior
        if (hasBlockchainAndContract(doc)) {
          await writeResult(doc, extractBaseToken(doc), {
            status: 'skipped_existing_fields',
            reason: 'document_already_has_blockchain_and_contract',
            blockchain: pickBlockchain(doc),
          });
          stats.skipped_existing_fields += 1;
          stats.matching.unmatchedRecordIds.push(doc._id); // didn't attempt matching
          continue;
        }

        // 1) Try to match against new_listing (requires existing contract + chain there)
        const baseToken = extractBaseToken(doc);
        const nameCandidates = pickNameCandidates(doc);
        let newListingDoc = null;

        // Check if we have data to match on
        if (!baseToken || !nameCandidates.length) {
          stats.matching.noMatchableData += 1;
          stats.matching.unmatchedRecordIds.push(doc._id);
        } else {
          // Attempt to find match in new_listings
          newListingDoc = await findNewListingMatch(db, baseToken, nameCandidates);

          if (newListingDoc) {
            stats.matching.foundNewListingMatch += 1;
            stats.matching.matchedRecordIds.push(doc._id);
            console.log(
              `✓ Found new_listings match for announcement ${doc._id} -> new_listing ${newListingDoc._id}`,
            );
          } else {
            stats.matching.unmatchedRecordIds.push(doc._id);
            console.log(`✗ No new_listings match found for announcement ${doc._id}`);
          }
        }

        if (newListingDoc) {
          const nlContract = pickContractLoose(newListingDoc);
          const nlChain = pickChainLoose(newListingDoc);

          if (nlContract) {
            // Query Dexscreener (rate-limited) by symbol, then locate the pair for nlContract (+ optional chain)
            const data = await fetchDexscreenerWithGap(baseToken);
            const {
              pair,
              vol,
              liq,
              source,
              reason: selectReason,
            } = selectPairByContract(data, {
              symbol: baseToken,
              names: nameCandidates,
              contract: nlContract,
              preferredChain: nlChain,
            });

            if (pair) {
              stats.matching.successfulMatches += 1;

              const projectName =
                pair?.baseToken?.name ||
                nameCandidates[0] ||
                pair?.baseToken?.symbol ||
                null;
              const vol = getVolumeUsd(pair.volume);
              const liq = getLiquidityUsd(pair.liquidity);

              await writeResult(doc, baseToken, {
                status:
                  source === 'name_symbol'
                    ? 'ok_name_symbol'
                    : source === 'exact_base'
                    ? 'ok_exact_base'
                    : 'ok_from_new_listing_match', // 'contract' fallback path
                projectName,
                chainId: pair.chainId || nlChain || null,
                contractAddress: pair.baseToken?.address || nlContract || null,
                pairAddress: pair.pairAddress || null,
                pairUrl: pair.url || null,
                baseSymbol: pair.baseToken?.symbol || baseToken || null,
                baseName: pair.baseToken?.name || null,
                quoteSymbol: pair.quoteToken?.symbol || null,
                quoteName: pair.quoteToken?.name || null,
                priceUsd: pair.priceUsd ?? null,
                priceNative: pair.priceNative ?? null,
                fdv: typeof pair.fdv === 'number' ? pair.fdv : null,
                marketCap: typeof pair.marketCap === 'number' ? pair.marketCap : null,
                volumeUsd: typeof vol === 'number' ? vol : getVolumeUsd(pair.volume),
                liquidityUsd:
                  typeof liq === 'number' ? liq : getLiquidityUsd(pair.liquidity),
                selectedPair: pair,
                raw: data,
                matchedFrom: source, // 'name_symbol' | 'exact_base' | 'contract'
                newListingMatchId: newListingDoc._id, // Track which new_listing record was matched
              });
              stats.ok_from_new_listing_match += 1;
              continue; // done with this doc
            } else {
              await writeResult(doc, baseToken, {
                status: 'no_match_for_new_listing_contract',
                reason: 'dexscreener_no_pair_for_contract',
                matchedContract: nlContract,
                preferredChain: nlChain || null,
                raw: data,
                newListingMatchId: newListingDoc._id,
              });
              stats.no_pair_for_new_listing_contract += 1;
              continue; // don't fall back, we tried the explicit contract
            }
          } else {
            stats.matching.matchedButMissingContract += 1;
            console.log(
              `⚠ Found new_listings match for ${doc._id} but missing contract in new_listing record ${newListingDoc._id}`,
            );
          }
        }

        // Mark as no match if we didn't already increment stats.matching counters above
        if (!newListingDoc && baseToken && nameCandidates.length) {
          stats.new_listing_no_match += 1;
        }

        // 2) Fallback to original pipeline (symbol → Dexscreener → exact + thresholds + FDV)
        if (!baseToken) {
          await writeResult(doc, baseToken, {
            status: 'no_match',
            reason: 'no_base_token_extracted',
            raw: null,
          });
          stats.no_match += 1;
          continue;
        }

        const preferredChain = pickBlockchain(doc);
        const data = await fetchDexscreenerWithGap(baseToken);
        const { top, vol, liq, reason } = selectTopExactPair(
          data,
          baseToken,
          preferredChain,
        );

        if (!top) {
          await writeResult(doc, baseToken, { status: 'no_match', reason, raw: data });
          stats.no_match += 1;
          continue;
        }

        const projectName =
          top?.baseToken?.name || top?.baseToken?.symbol || nameCandidates[0] || null;

        await writeResult(doc, baseToken, {
          status: 'ok',
          projectName,
          chainId: top.chainId,
          contractAddress: top.baseToken?.address || null,
          pairAddress: top.pairAddress || null,
          pairUrl: top.url || null,
          baseSymbol: top.baseToken?.symbol || null,
          baseName: top.baseToken?.name || null,
          quoteSymbol: top.quoteToken?.symbol || null,
          quoteName: top.quoteToken?.name || null,
          priceUsd: top.priceUsd ?? null,
          priceNative: top.priceNative ?? null,
          fdv: typeof top?.fdv === 'number' ? top.fdv : null,
          marketCap: typeof top?.marketCap === 'number' ? top.marketCap : null,
          volumeUsd: vol,
          liquidityUsd: liq,
          selectedPair: top,
          raw: data,
        });
        stats.ok += 1;
      } catch (e) {
        console.error('Backfill item error:', e);
        stats.error += 1;
        stats.matching.unmatchedRecordIds.push(doc._id); // error means no successful matching
        try {
          await writeResult(doc, extractBaseToken(doc), {
            status: 'error',
            error: String(e?.message || e),
          });
        } catch {
          /* ignore secondary failure */
        }
      }
    }

    // Calculate match percentage
    const matchPercentage =
      stats.scanned > 0
        ? ((stats.matching.foundNewListingMatch / stats.scanned) * 100).toFixed(2)
        : 0;

    // Enhanced response with detailed matching statistics
    const response = {
      ok: true,
      stats,
      matchingSummary: {
        totalAnnouncementsProcessed: stats.scanned,
        totalNewListingsAvailable: totalNewListings,
        announcementsMatchedWithNewListings: stats.matching.foundNewListingMatch,
        matchPercentage: `${matchPercentage}%`,
        successfullyProcessedFromMatches: stats.matching.successfulMatches,
        breakdown: {
          foundMatch: stats.matching.foundNewListingMatch,
          noMatchableData: stats.matching.noMatchableData,
          matchedButMissingContract: stats.matching.matchedButMissingContract,
          couldNotMatch:
            stats.matching.unmatchedRecordIds.length - stats.matching.noMatchableData,
        },
      },
    };

    console.log('\n=== MATCHING SUMMARY ===');
    console.log(`Total announcements processed: ${stats.scanned}`);
    console.log(`Total new_listings available: ${totalNewListings}`);
    console.log(
      `Announcements matched with new_listings: ${stats.matching.foundNewListingMatch}`,
    );
    console.log(`Match percentage: ${matchPercentage}%`);
    console.log(
      `Successfully processed from matches: ${stats.matching.successfulMatches}`,
    );
    console.log('========================\n');

    return res.json(response);
  } catch (err) {
    console.error('Backfill endpoint error:', err);
    return res.status(500).json({ ok: false, error: String(err?.message || err) });
  }
});

// ---- bootstrap ----
(async () => {
  if (!MONGODB_URI) {
    console.error('Missing DATABASE_URL env var');
    process.exit(1);
  }

  console.log('Connecting to MongoDB…');
  await mongoose.connect(MONGODB_URI, { dbName: DB_NAME });
  console.log('Connected. Starting change stream on:', TARGET_COLLECTIONS);

  await startChangeStream();

  app.listen(PORT, () => console.log(`Webhook service listening on :${PORT}`));
})();

// utils.js
import mongoose from 'mongoose';

// 1) Match Project Name and Symbol with new_listings WITH an existing contract address and blockchain, if there is a match, then retrieve the information
// 2) Query DEXScreener using Symbol
// 3) Match Project Name and Symbol with JSON
// 4) For non-matched records, check if baseToken is an exact match
// 5) if yes, then sort response by payload in descending order by FDV IF volume is > $10,000 and liquidity is > $10,000
// 6) retrieve the contract address, blockchain name, and all financials for the highest ranked result

/** -----------------------------
 * Thresholds (overridable via env)
 * ----------------------------- */
export const VOLUME_MIN_USD = Number(process.env.VOLUME_MIN_USD ?? 10_000);
export const LIQ_MIN_USD = Number(process.env.LIQ_MIN_USD ?? 10_000);

/** -----------------------------
 * Generic helpers
 * ----------------------------- */

/** Sleep for ms */
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/**
 * Extract a base token "symbol-ish" from an inserted doc.
 * Accepts:
 *   - baseToken: "SYMBOL"
 *   - baseToken: { symbol, name }
 * Returns trimmed string to ensure consistent whitespace handling
 */
export function extractBaseToken(doc) {
  const norm = (v) => (typeof v === 'string' ? v.trim() : '');

  // 1) Announcements structure
  const fromSymbol = norm(doc?.symbol);
  if (fromSymbol) return fromSymbol;

  // 2) Alpha-hunter structures
  const fromDexapi = norm(doc?.dexapi_baseTokenSymbol);
  if (fromDexapi) return fromDexapi;

  // 3) Backward compatibility with previous formats
  const bt = doc?.baseToken;
  if (typeof bt === 'string' && bt.trim()) return bt.trim();
  if (bt && typeof bt === 'object') {
    const fromBT = norm(bt.symbol) || norm(bt.name);
    if (fromBT) return fromBT;
  }

  // 4) Permissive fallbacks (optional, helpful for odd feeds)
  const loose =
    norm(doc?.Symbol) || // sometimes capitalized
    norm(doc?.gatekept?.symbol) || // some feeds tuck it under gatekept
    norm(doc?.trench_bot?.Ticker); // another occasional source
  if (loose) return loose;

  return '';
}

/** Volume in USD from Dexscreener payload with preferred keys */
export function getVolumeUsd(volObj) {
  if (!volObj || typeof volObj !== 'object') return 0;
  const pref = ['h24', 'h6', 'h1'];
  for (const k of pref) {
    const v = volObj[k];
    if (typeof v === 'number' && Number.isFinite(v)) return v;
  }
  for (const v of Object.values(volObj)) {
    if (typeof v === 'number' && Number.isFinite(v)) return v;
  }
  return 0;
}

/** Liquidity in USD from Dexscreener payload */
export function getLiquidityUsd(liqObj) {
  const v = liqObj?.usd;
  return typeof v === 'number' && Number.isFinite(v) ? v : 0;
}

/**
 * Fetch Dexscreener search results for a base token string.
 * Timeouts after 10s.
 */
export async function fetchDexscreener(baseToken) {
  const url = `https://api.dexscreener.com/latest/dex/search?q=${encodeURIComponent(
    baseToken,
  )}`;

  const controller = new AbortController();
  const to = setTimeout(() => controller.abort(), 10_000);

  try {
    const resp = await fetch(url, {
      method: 'GET',
      headers: { Accept: '*/*' },
      signal: controller.signal,
    });
    if (!resp.ok) throw new Error(`Dexscreener HTTP ${resp.status}`);
    return await resp.json();
  } finally {
    clearTimeout(to);
  }
}

/**
 * (Legacy) Rank pairs using exact match + thresholds + FDV desc
 * Returns { exact, filtered, top, vol, liq }
 * - exact: all exact base matches
 * - filtered: exact matches that pass thresholds, sorted by FDV desc
 * - top: best pair (or undefined)
 */
export function rankPairs(data, baseToken) {
  const pairs = Array.isArray(data?.pairs) ? data.pairs : [];

  // 1) exact match (case-insensitive with whitespace trimming)
  const exact = pairs.filter((p) => isExactBaseMatch(p, baseToken));

  // 2) thresholds + sort by FDV desc
  const filtered = exact
    .map((p) => ({ p, vol: getVolumeUsd(p.volume), liq: getLiquidityUsd(p.liquidity) }))
    .filter((x) => x.vol > VOLUME_MIN_USD && x.liq > LIQ_MIN_USD)
    .sort((a, b) => (b.p.fdv ?? -Infinity) - (a.p.fdv ?? -Infinity));

  return {
    exact,
    filtered,
    top: filtered[0]?.p,
    vol: filtered[0]?.vol,
    liq: filtered[0]?.liq,
  };
}

/** -----------------------------
 * New matching/selection helpers
 * ----------------------------- */

/** Common field names for blockchain/chain id */
export function pickBlockchain(doc) {
  return (
    (typeof doc?.blockchain === 'string' && doc.blockchain.trim()) ||
    (typeof doc?.chainId === 'string' && doc.chainId.trim()) ||
    (typeof doc?.chain === 'string' && doc.chain.trim()) ||
    (typeof doc?.network === 'string' && doc.network.trim()) ||
    ''
  );
}

/** Common field names for token contract address (falling back to baseToken.address) */
export function pickContractAddress(doc) {
  return (
    (typeof doc?.contract_address === 'string' && doc.contract_address.trim()) ||
    (typeof doc?.contractAddress === 'string' && doc.contractAddress.trim()) ||
    (typeof doc?.token_address === 'string' && doc.token_address.trim()) ||
    (typeof doc?.baseToken?.address === 'string' && doc.baseToken.address.trim()) ||
    ''
  );
}

/** True if doc already has both a chain and a plausible contract address */
export function hasBlockchainAndContract(doc) {
  const chain = pickBlockchain(doc);
  const contract = pickContractAddress(doc);
  const evmLike = /^0x[a-fA-F0-9]{40}$/.test(contract); // EVM quick sanity
  return Boolean(chain && (evmLike || contract.length > 0));
}

/** Case-insensitive exact match on baseToken.symbol or baseToken.name with whitespace trimming */
export function isExactBaseMatch(p, base) {
  if (!p?.baseToken) return false;

  const normalizeString = (str) => {
    if (typeof str !== 'string') return '';
    return str.trim().toLowerCase();
  };

  const normalizedBase = normalizeString(base);
  const normalizedSymbol = normalizeString(p.baseToken.symbol);
  const normalizedName = normalizeString(p.baseToken.name);

  return normalizedSymbol === normalizedBase || normalizedName === normalizedBase;
}

/** If a preferred chain is provided, keep only pairs on that chain; otherwise keep all */
export function filterByPreferredChain(pairs, preferredChain) {
  if (!preferredChain) return pairs;
  const lc = String(preferredChain).toLowerCase();
  const onPreferred = pairs.filter((p) => String(p?.chainId ?? '').toLowerCase() === lc);
  return onPreferred.length ? onPreferred : pairs;
}

/**
 * Exact-match pipeline:
 *  1) keep only exact baseToken matches (case-sensitive)
 *  2) optionally prefer a provided chain
 *  3) filter by volume/liquidity thresholds
 *  4) sort by FDV desc
 * Returns { top, vol, liq, reason }
 */
export function selectTopExactPair(data, baseToken, preferredChain = '') {
  const pairs = Array.isArray(data?.pairs) ? data.pairs : [];
  if (!pairs.length) return { top: null, reason: 'no_pairs' };

  // 1) exact matches only
  let exact = pairs.filter((p) => isExactBaseMatch(p, baseToken));
  if (!exact.length) return { top: null, reason: 'no_exact_baseToken_match' };

  // Prefer chain if caller provided one; else use all exact
  exact = filterByPreferredChain(exact, preferredChain);

  // 2) compute metrics + filter by thresholds
  const ranked = exact
    .map((p) => ({
      p,
      vol: getVolumeUsd(p.volume),
      liq: getLiquidityUsd(p.liquidity),
      fdv: typeof p.fdv === 'number' && Number.isFinite(p.fdv) ? p.fdv : -Infinity,
    }))
    .filter((x) => x.vol > VOLUME_MIN_USD && x.liq > LIQ_MIN_USD)
    // 3) sort by FDV desc
    .sort((a, b) => b.fdv - a.fdv);

  if (!ranked.length) return { top: null, reason: 'thresholds_not_met_or_no_fdv' };

  const { p: top, vol, liq } = ranked[0];
  return { top, vol, liq, reason: null };
}

/** -----------------------------
 * Persistence helper
 * ----------------------------- */

/**
 * Update the inserted Mongo doc with a "dexscreener" subdocument.
 * Expected shape: updateInsertedDoc(change, { ...payloadFields })
 */
export async function updateInsertedDoc(change, payload) {
  // Use native driver via mongoose.connection.db
  const collName = change?.ns?.coll;
  const _id = change?.fullDocument?._id;
  if (!collName || !_id) {
    // Nothing to do; avoid throwing so caller error handler isn't double-fired
    console.warn('updateInsertedDoc: missing ns.coll or _id in change event');
    return;
  }

  console.log('========== update doc call', { change, payload });

  //   const coll = mongoose.connection.db.collection(collName);
  //   await coll.updateOne(
  //     { _id },
  //     {
  //       $set: {
  //         dexscreener: {
  //           ...payload,
  //           checkedAt: new Date(),
  //         },
  //       },
  //     }
  //   );
}

const selectPairByContract = (data, contract, preferredChain = '') => {
  const pairs = Array.isArray(data?.pairs) ? data.pairs : [];
  if (!pairs.length) return null;

  const addrLC = String(contract).toLowerCase();
  const chainLC = String(preferredChain || '').toLowerCase();

  let candidates = pairs.filter(
    (p) => String(p?.baseToken?.address || '').toLowerCase() === addrLC,
  );
  if (!candidates.length) return null;

  if (chainLC) {
    const onChain = candidates.filter(
      (p) => String(p?.chainId || '').toLowerCase() === chainLC,
    );
    if (onChain.length) candidates = onChain;
  }

  // rank: liquidity.usd desc, then fdv desc, then 24h volume desc
  const ranked = candidates
    .map((p) => ({
      p,
      liq: getLiquidityUsd(p.liquidity),
      fdv: typeof p.fdv === 'number' && Number.isFinite(p.fdv) ? p.fdv : -Infinity,
      vol: getVolumeUsd(p.volume),
    }))
    .sort((a, b) => b.liq - a.liq || b.fdv - a.fdv || b.vol - a.vol);

  return ranked[0]?.p || null;
};
